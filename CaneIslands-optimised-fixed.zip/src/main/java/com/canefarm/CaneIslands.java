package com.canefarm;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.scoreboard.Team;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.ChunkSnapshot;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.block.Container;
import org.bukkit.block.Hopper;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockGrowEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.block.BlockDispenseEvent;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.BoundingBox;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;

public class CaneIslands extends JavaPlugin implements Listener {

    // ------------------------------------------------------------------ constants
    static final String WORLD_NAME = "cane_islands";
    static final int MIN_Y = 60, MAX_Y = 80;           // vertical scan range for farms
    static final int MAX_CANE_HEIGHT = 2;               // sugar cane never grows taller than this (planted cane = 1)
    static final long GLOBAL_TICKS = 60L;               // THE global tick: every 3 s the whole server is processed once and each player gets their own result
    static final List<int[]> ORDER = new ArrayList<>(); // order extra chunks are added around the start chunk
    // playtime rank tiers (hours played, LuckPerms group, tab/chat tag, scoreboard name)
    static final int[] RANK_HOURS = {1, 3, 5, 7, 10, 13, 16, 19, 22, 24};
    static final int TOKEN_START_DAY = 35; // first day that earns a Cane Token
    static final int TOKEN_REBIRTH_EVERY = 1000; // every this many rebirths earns 1 Cane Token too
    static final int[] RANK_WEIGHTS = {50, 100, 150, 200, 250, 300, 350, 400, 450, 500};
    static final String[] RANK_GROUPS = {"farmer", "farmer-red", "farmer-purple", "farmer-plus", "farmer-gold",
            "farmer-aqua", "farmer-tycoon", "farmer-emperor", "farmer-god", "farmer-legend"};
    static final String[] RANK_PREFIXES = {
            "&8[&a\u2618 Farmer&8] ",
            "&8[&c\u2740 Harvester&8] ",
            "&8[&5\u2726 &5&lCultivator&8] ",
            "&8[&d&l\u2605 &5&lCane Baron &d&l\u2605&8] ",
            "&8[&6\u2692 &6&lReaper&8] ",
            "&8[&b\u2748 &b&lPlantation Lord&8] ",
            "&8[&e\u272A &e&lSugar Tycoon&8] ",
            "&8[&c&l\u265B &4&lCane Emperor &c&l\u265B&8] ",
            "&8[&b&l\u2600 &f&lHarvest God &b&l\u2600&8] ",
            "&8[&6&l\u2605 &e&lCane Legend &6&l\u2605&8] "
    };
    static final String[] RANK_NAMES = {"&aFarmer", "&cHarvester", "&5Cultivator", "&d&lCane Baron", "&6Reaper",
            "&bPlantation Lord", "&eSugar Tycoon", "&c&lCane Emperor", "&b&lHarvest God", "&6&lCane Legend"};
    // token shop rank (LuckPerms group, added on top of the playtime rank; high weight so its tag wins)
    static final String FEMBOY_GROUP = "femboy";
    static final String FEMBOY_PREFIX = "&8[&d&l\u2665 Femboy&8] ";

    static {
        for (int r = 1; r <= 2; r++)
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    if (Math.max(Math.abs(dx), Math.abs(dz)) == r) ORDER.add(new int[]{dx, dz});
    }

    // ------------------------------------------------------------------ data classes
    static class PD {
        final UUID id;
        String name = "Unknown";
        int slot, extra, day = 1, bestDay = 0, timeLeft = 1800, rewardGrowth, rewardTime;
        final Map<String, Integer> priceBase = new HashMap<>(); // per shop item: levels that rebirths already made cheaper - the price is the base price multiplied once for every level above this
        int runBest = 1;            // highest day reached since the last rebirth / reset (used for rebirth eligibility)
        int rewardDrop, rewardSell; // free Bonus Drops / Coin Boost levels earned from daily bonuses
        int rankTier;               // highest rank tier given so far (0 = none, else index + 1 in tiers)
        long playMs;                // total time played in ms (playtime ranks)
        int tokens;                 // Cane Tokens: 1 for every new day from Day 35 on (and every 1000 rebirths), spent in /tokenshop
        final Set<String> owned = new HashSet<>(); // token shop items bought
        String activeTag = ""; // equipped chat tag (token shop id)
        String activeName = "", activeSellFx = ""; // equipped name color / sell effect cosmetics (token shop ids)
        long submitted, totalCane;
        int rebirths;
        long lastRebirth;           // ms timestamp of the last rebirth (0 = never)
        int fastStreak;             // rebirths in a row that came faster than the fast-rebirth limit
        boolean completed, flyOwned, flyOn, autoDayOn, autoRebirth;
        boolean breakerGiven; // the free Line Breaker has been handed out once
        // Copy & Paste Wand settings (per player, saved)
        int wandDepth = 128, wandLeft = 15, wandRight = 15, wandLayers = 2, wandGap = 1;
        boolean wandPreview = true, wandRotate = true;
        int timeMode; // 0 = normal cycle, 1 = always day, 2 = always night
        boolean hasSpawn;           // custom island spawn set with /is setspawn
        double spawnX, spawnY, spawnZ;
        float spawnYaw, spawnPitch;
        final Set<String> off = new HashSet<>(); // options the player switched OFF
        final Set<UUID> trusted = new HashSet<>(); // players allowed to build on this island
        double coins;
        long lastSim;               // ms timestamp of the last Auto Sell settle (0 = no Cane Core placed)
        double carry;               // fractional cane the simulation has earned but not paid out yet
        final Map<String, Integer> bought = new HashMap<>();
        final List<Integer> pending = new ArrayList<>();

        PD(UUID id) {
            this.id = id;
        }

        boolean on(String k) {
            return !off.contains(k);
        }

        int lvl(String k) {
            return bought.getOrDefault(k, 0);
        }
    }

    static class Special {
        final String type;
        final int x, y, z;
        final UUID owner;

        Special(String type, int x, int y, int z, UUID owner) {
            this.type = type;
            this.x = x;
            this.y = y;
            this.z = z;
            this.owner = owner;
        }

        String key() {
            return x + "," + y + "," + z;
        }

        String ser() {
            return type + "|" + x + "|" + y + "|" + z + "|" + owner;
        }

        static Special parse(String s) {
            String[] p = s.split("\\|");
            if (p.length < 5) return null;
            try {
                return new Special(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), UUID.fromString(p[4]));
            } catch (Exception e) {
                return null;
            }
        }
    }

    static class Tier {
        final int hours, weight;
        final String group, prefix, name;

        Tier(int hours, String group, String prefix, int weight, String name) {
            this.hours = hours;
            this.group = group;
            this.prefix = prefix;
            this.weight = weight;
            this.name = name;
        }
    }

    static class ShopItem {
        final String id, name;
        final Material icon;
        final double price;
        final int max;
        final String[] desc;
        final boolean glow;
        final BiPredicate<Player, PD> apply;

        ShopItem(String id, Material icon, String name, double price, int max, String[] desc, boolean glow, BiPredicate<Player, PD> apply) {
            this.id = id;
            this.icon = icon;
            this.name = name;
            this.price = price;
            this.max = max;
            this.desc = desc;
            this.glow = glow;
            this.apply = apply;
        }
    }

    static class ShopHolder implements InventoryHolder {
        final int page;
        Inventory inv;

        ShopHolder(int page) {
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class Opt {
        final String id, name, desc;
        final Material icon;
        final boolean defOff; // starts switched OFF (the saved set then holds the players who turned it ON)
        final boolean action; // a one-click button instead of an on/off toggle

        Opt(String id, String name, Material icon, String desc) {
            this(id, name, icon, desc, false, false);
        }

        Opt(String id, String name, Material icon, String desc, boolean defOff) {
            this(id, name, icon, desc, defOff, false);
        }

        Opt(String id, String name, Material icon, String desc, boolean defOff, boolean action) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.desc = desc;
            this.defOff = defOff;
            this.action = action;
        }
    }

    static class ChunksHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class CommandsHolder implements InventoryHolder {
        final List<String> names = new ArrayList<>(); // command name for each slot
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class OptionsHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class Rw {
        final String desc;
        final BiConsumer<Player, PD> act;

        Rw(String desc, BiConsumer<Player, PD> act) {
            this.desc = desc;
            this.act = act;
        }
    }

    static class VoidGen extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World w, Random r) {
            return new Location(w, 8.5, 65, 8.5);
        }
    }

    static class PlainsBiomes extends BiomeProvider {
        @Override
        public Biome getBiome(WorldInfo wi, int x, int y, int z) {
            return Biome.PLAINS;
        }

        @Override
        public List<Biome> getBiomes(WorldInfo wi) {
            return List.of(Biome.PLAINS);
        }
    }

    // ------------------------------------------------------------------ fields
    World world;
    final Map<UUID, PD> players = new HashMap<>();
    final Map<Long, UUID> chunkOwners = new HashMap<>();
    /** Cane Core count per owner. Only TrackedSpecials writes to it (main thread only). */
    private final Map<UUID, Integer> collectorCounts = new HashMap<>();
    /** Everyone who has at least one Cane Core ("sellcollector") placed. Kept up to date by `specials` itself on every put / remove / removeIf / clear / load. Read-only view: do not add to it. */
    final Set<UUID> collectorOwners = java.util.Collections.unmodifiableSet(collectorCounts.keySet());

    /** specials map that maintains collectorOwners incrementally, so no call site has to remember to. */
    final class TrackedSpecials extends LinkedHashMap<String, Special> {
        private void track(Special sp) {
            if (sp != null && sp.owner != null && sp.type.equals("sellcollector")) collectorCounts.merge(sp.owner, 1, Integer::sum);
        }

        private void untrack(Object o) {
            if (o instanceof Special sp && sp.owner != null && sp.type.equals("sellcollector")) collectorCounts.computeIfPresent(sp.owner, (k, n) -> n <= 1 ? null : n - 1);
        }

        @Override
        public Special put(String k, Special v) {
            Special old = super.put(k, v);
            untrack(old);
            track(v);
            return old;
        }

        @Override
        public void putAll(Map<? extends String, ? extends Special> m) {
            for (Map.Entry<? extends String, ? extends Special> en : m.entrySet()) put(en.getKey(), en.getValue());
        }

        @Override
        public Special remove(Object k) {
            Special old = super.remove(k);
            untrack(old);
            return old;
        }

        @Override
        public void clear() {
            super.clear();
            collectorCounts.clear();
        }

        /** values() is used with removeIf(...) (reset / island reset): removals through its iterator are tracked too. */
        @Override
        public java.util.Collection<Special> values() {
            final java.util.Collection<Special> base = super.values();
            return new java.util.AbstractCollection<>() {
                @Override
                public java.util.Iterator<Special> iterator() {
                    final java.util.Iterator<Special> it = base.iterator();
                    return new java.util.Iterator<>() {
                        Special last;

                        public boolean hasNext() {
                            return it.hasNext();
                        }

                        public Special next() {
                            return last = it.next();
                        }

                        public void remove() {
                            it.remove();
                            untrack(last);
                        }
                    };
                }

                @Override
                public int size() {
                    return base.size();
                }
            };
        }

        // Anything below would change the map without going through put/remove above: fail loudly instead of silently desyncing collectorOwners.
        @Override
        public java.util.Set<String> keySet() {
            return java.util.Collections.unmodifiableSet(super.keySet());
        }

        @Override
        public java.util.Set<Map.Entry<String, Special>> entrySet() {
            return java.util.Collections.unmodifiableSet(super.entrySet());
        }

        @Override
        public Special putIfAbsent(String k, Special v) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Special computeIfAbsent(String k, java.util.function.Function<? super String, ? extends Special> f) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Special computeIfPresent(String k, java.util.function.BiFunction<? super String, ? super Special, ? extends Special> f) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Special compute(String k, java.util.function.BiFunction<? super String, ? super Special, ? extends Special> f) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Special merge(String k, Special v, java.util.function.BiFunction<? super Special, ? super Special, ? extends Special> f) {
            throw new UnsupportedOperationException();
        }

        @Override
        public Special replace(String k, Special v) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean remove(Object k, Object v) {
            throw new UnsupportedOperationException();
        }
    }

    final TrackedSpecials specials = new TrackedSpecials();

    // --- persistence / timer accounting state
    /** Playtime changed since the last save. It no longer marks `dirty` by itself. */
    boolean playDirty;
    /** A player quit with unsaved playtime: save soon (debounced). */
    boolean quitSaveDue;
    long playSaveAccumMs, lastSaveMs;
    static final long PLAY_SAVE_MS = 300_000L;      // playtime-only saves: every 5 minutes
    static final long QUIT_SAVE_MIN_GAP_MS = 10_000L; // never build the YAML for quits more often than this
    /** Set by the async writer when a write failed, so the next 60 s check retries. */
    volatile boolean saveFailed;
    private long saveSeq, writtenSeq;
    private final Object saveLock = new Object();
    private final java.util.concurrent.ExecutorService saveExec = java.util.concurrent.Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "CaneIslands-save");
        t.setDaemon(true);
        return t;
    });
    /** Last action-bar text sent to each player (only resent when it changes). */
    final Map<UUID, String> lastBar = new HashMap<>();
    private Component discordAdvertMsg;
    private String discordAdvertLink;
    final List<ShopItem> shop = new ArrayList<>();
    final Map<String, PotionEffectType> effects = new LinkedHashMap<>();
    final Random rng = new Random();
    final List<Opt> options = new ArrayList<>();
    final Map<UUID, Long> boundaryWarned = new HashMap<>();
    final Map<UUID, UUID> visiting = new HashMap<>(); // visitor -> island owner
    final Map<UUID, Long> resetConfirm = new HashMap<>();
    final Map<UUID, Long> islandResetConfirm = new HashMap<>();
    final Set<UUID> chunkBorders = new HashSet<>(); // players who currently have the chunk border particles switched on
    final Set<UUID> islandResetting = new HashSet<>();
    final Map<UUID, Long> rebirthConfirm = new HashMap<>();
    NamespacedKey KEY_INF, KEY_SPECIAL, KEY_POUCH, KEY_CPOUCH, KEY_WPOUCH, KEY_GPOUCH, KEY_BREAKER, KEY_WAND;
    static final int POUCH_CAP = 2304;          // max a pouch can hold (36 stacks)
    static final long POUCH_COOLDOWN_MS = 120;  // min time between two pouch placements
    final Map<UUID, Long> pouchCooldown = new HashMap<>();
    // token shop
    final List<TItem> tokenItems = new ArrayList<>();
    final Map<String, TItem> tokenById = new HashMap<>();
    final Map<UUID, String> tokenPendingId = new HashMap<>();
    final Map<UUID, Long> tokenPendingAt = new HashMap<>();
    long lastPlayMs = 0;
    final Map<UUID, Clip> clipboards = new HashMap<>(); // Copy & Paste Wand clipboards (memory only)
    static final long AUTOSUBMIT_NOTIFY_MS = 5 * 60 * 1000L;
    final Map<UUID, double[]> autoSubWindow = new HashMap<>(); // owner -> {window start ms, cane, coins}
    // cached cane plant count per island chunk, so unloaded chunks still count for the Auto Sell simulation
    final Map<Long, Integer> chunkStalks = new HashMap<>();

    /** Safety net: every indexed chunk is re-read from a fresh snapshot (off the main thread) at most this often, to catch blocks changed without an event (wand paste, /undo, island rebuild). */
    static final long CANE_REFRESH_MS = 30_000L;
    /**
     * false = scan every Y level that holds blocks (same counts as before - the plugin has no build-height cap and counts cane at ANY Y).
     * true  = only MIN_Y..MAX_Y: a little faster, but cane outside that band stops counting and growing.
     */
    static final boolean CANE_CLAMP_TO_FARM_Y = false;

    /** Per-chunk cane index. Main thread only (the async refresh only ever touches its own local copies). */
    static final class CaneChunk {
        /** Every cane base (cane with no cane below), water or not, packed as ((y - minY) << 8) | (lx << 4) | lz - sorted order == the old scan order (y, then x, then z). */
        java.util.TreeSet<Integer> bases = new java.util.TreeSet<>();
        /** The bases that count (have water beside their soil), as {x, y, z} in scan order. This is what Auto Sell, the scoreboard and /caneinfo end up counting. */
        List<int[]> live = new ArrayList<>();
        /** Blocks placed since the last recompute (candidate new bases). */
        final List<int[]> touched = new ArrayList<>();
        boolean dirty;     // something changed in / next to this chunk: re-derive bases + water before the next growth pass
        boolean scanning;  // an async refresh is in flight
        long scannedAt;    // last full scan / applied refresh (ms)
        int seq;           // bumped by every change; an async result is only applied if it still matches
    }

    final Map<Long, CaneChunk> caneIndex = new HashMap<>();
    double simMaxOfflineHours = 8;
    File dataFile;
    boolean dirty;
    int nextSlot = 0;

    double baseChance, perLevel, maxChance, coinsPerCane, priceMult, reqMult;
    int timerMinutes, dailyDrop, dailySell, rebirthInterval = 23;
    double rebirthBonus = 0.1;
    final List<Tier> tiers = new ArrayList<>(); // rank tiers, sorted by day
    long capReq;
    boolean rankChat = true, rankTab = true;
    String serverIp = "CaneFarming.minehut.gg";
    static final String DEFAULT_DISCORD = "https://discord.gg/8FVDVK8bzq";
    String discordLink = DEFAULT_DISCORD;
    int discordSeconds = 120;
    boolean scoreboardOn = true;
    int fastPrestigeSeconds = 30, fastPrestigeStreak = 3, fastPrestigeMult = 3;
    final Map<UUID, Board> boards = new HashMap<>();
    PD leaderCache;                       // /canetop #1 for the sidebar, refreshed every 5 s for everybody
    Map<UUID, Integer> rankCache;         // everyone's /canetop position, same refresh
    long rankAt = 0;
    final Map<UUID, long[]> stalkCache = new HashMap<>(); // player -> {last refresh ms, cane plants placed}
    static final int BOARD_LINES = 15;

    // ---- perf caches (perkTick / tab / time / sidebar). Main thread only. ----
    static final int EFFECT_REFRESH_BELOW_TICKS = 300; // perk effects are granted for 600 ticks; re-add when < 15 s are left (client blink starts at 10 s)
    static final long TIME_RESYNC_MS = 60_000L;        // safety net: re-send player time at most this often even when unchanged
    static final long PREFIX_TTL_MS = 30_000L;         // periodic tab refresh re-reads the LuckPerms prefix at most this often

    /** Per-player cache. Tied to the Player object, so a re-join starts clean. */
    static final class PerkState {
        Player player;
        int timeState = -1;          // what we last sent: 0 = normal, 1 = day, 2 = night
        long timeAt;
        String prefix;               // cached LuckPerms prefix ("" = none)
        long prefixAt;
        boolean tabSeen, tabHasData; // list-name inputs below are valid
        String tabPrefix, tabTag, tabName;
        int tabRebirths;
        int tabVersion = -1;         // last header/footer version sent to this player
    }

    final Map<UUID, PerkState> perkState = new HashMap<>();
    Component tabHeader;             // built once
    Component tabFooter;             // rebuilt only when the online count or server-ip changes
    String tabFooterIp;
    int tabFooterOnline = -1;
    int tabVersion = 0;              // bumped every time tabFooter is rebuilt

    PerkState perkOf(Player p) {
        UUID id = p.getUniqueId();
        PerkState s = perkState.get(id);
        if (s == null || s.player != p) {
            s = new PerkState();
            s.player = p;
            perkState.put(id, s);
        }
        return s;
    }

    // ---- sidebar line cache ----
    static final class SbCache {
        Board board;                                   // lines belong to this board; a new board = start clean
        final String[] L = new String[BOARD_LINES];    // last built text per line (same String object while unchanged)
        boolean l1Done;
        int l1Day, l1Left;
        long l1Sub, l1Req;
        String l1Head;                                 // line 1 up to the timer, so only the timer text is rebuilt each tick
        int rebirths, tokens, growthLvl, topRank;
        double coins, perSell, growthCh, perMin, multi;
        String rank;
        long stalks;
    }

    final Map<UUID, SbCache> sbCache = new HashMap<>();
    PD sbLeader;                                       // shared "#1" line, built once per change for everybody
    long sbLeaderCane;
    String sbLeaderName, sbLeaderLine;
    String sbIpSrc, sbIpLine;
    static final String SB_TOP_LINE = "&6&l\u2605 CaneTop #1";

    static boolean sameD(double a, double b) {
        return Double.doubleToLongBits(a) == Double.doubleToLongBits(b);
    }
    static final String[] BOARD_ENTRIES = new String[15];

    static {
        for (int i = 0; i < BOARD_ENTRIES.length; i++) BOARD_ENTRIES[i] = "\u00a7" + Integer.toHexString(i) + "\u00a7r";
    }

    /** One player's own sidebar scoreboard. */
    static class Board {
        Scoreboard sb;
        Objective obj;
        final Team[] teams = new Team[BOARD_LINES];
        final String[] last = new String[BOARD_LINES];
    }
    boolean lagEnabled = true;
    int lagThreshold = 20, lagTicks = 100, lagMinAge = 100;

    /** Owners whose island may need a lag-remover scan: an item spawned on it, entities loaded on it, or they just came online. */
    final Set<UUID> lagHot = new HashSet<>();
    /** Owners that were online at the previous lag run (so a login marks the island hot once). */
    final Set<UUID> lagSeen = new HashSet<>();
    /** entityTick is called every global tick (3 s); the residual sweep only runs every Nth call. */
    static final int ENTITY_SWEEP_EVERY = 5; // 5 x 3 s = 15 s
    int entitySweepSkip = 0;
    /** Chunk Hopper -> the block it points at. Weak keys: entries vanish when a Special is removed anywhere in the plugin. */
    final Map<Special, Block> hopperRoute = new java.util.WeakHashMap<>();

    // ------------------------------------------------------------------ lifecycle
    @Override
    public void onEnable() {
        if (!Credit.valid(this)) {
            getLogger().severe("The ownership credit was removed or changed - disabling. Original plugin: " + Credit.LINE);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getLogger().info(Credit.LINE);
        getConfig().addDefault("growth.base-chance", 0.03);
        getConfig().addDefault("growth.per-level", 0.015);
        getConfig().addDefault("growth.max-chance", 0.5);
        getConfig().addDefault("timer.minutes", 30);
        getConfig().addDefault("coins-per-cane", 0.5);
        getConfig().addDefault("shop.price-multiplier", 2.0);
        getConfig().addDefault("quota.multiplier", 2.0);
        getConfig().addDefault("quota.cap", 0);
        getConfig().addDefault("sim.max-offline-hours", 8.0);
        getConfig().addDefault("rebirth.interval-days", 23);
        getConfig().addDefault("rebirth.bonus-per-rebirth", 0.1);
        getConfig().addDefault("lightblock.min-y", 65);
        getConfig().addDefault("lightblock.max-y", 100);
        getConfig().addDefault("lag-remover.enabled", true);
        getConfig().addDefault("lag-remover.entity-threshold", 100);
        getConfig().addDefault("lag-remover.interval-seconds", 15);
        getConfig().addDefault("lag-remover.item-age-seconds", 15);
        getConfig().addDefault("daily-bonus.drop-levels", 1);
        getConfig().addDefault("daily-bonus.sell-levels", 1);
        // rank tiers (LuckPerms groups). Prefix/weight here are only used when a group is first created -
        // after that you edit the groups in LuckPerms and the plugin never overwrites them.
        // show the LuckPerms prefix in chat / tab. Turn these off if another plugin (EssentialsChat, TAB, ...) already does it.
        getConfig().addDefault("ranks.show-in-chat", true);
        getConfig().addDefault("ranks.show-in-tab", true);
        getConfig().addDefault("server-ip", "CaneFarming.minehut.gg");
        getConfig().addDefault("scoreboard.enabled", true);
        getConfig().addDefault("discord.link", "https://discord.gg/8FVDVK8bzq");
        getConfig().addDefault("discord.interval-seconds", 120);
        getConfig().addDefault("ranks.style-version", 0);
        for (int i = 0; i < RANK_HOURS.length; i++) {
            String k = "ranks.tier" + (i + 1) + ".";
            getConfig().addDefault(k + "hours", RANK_HOURS[i]);
            getConfig().addDefault(k + "group", RANK_GROUPS[i]);
            getConfig().addDefault(k + "prefix", RANK_PREFIXES[i]);
            getConfig().addDefault(k + "name", RANK_NAMES[i]);
            getConfig().addDefault(k + "weight", RANK_WEIGHTS[i]);
        }
        getConfig().options().copyDefaults(true);
        // one-time restyle: old configs keep the plain "[Farmer]" prefixes, so overwrite them with the fancy ones once
        boolean restyle = getConfig().getInt("ranks.style-version", 0) < 2;
        if (restyle) {
            for (int i = 0; i < RANK_HOURS.length; i++) {
                String k = "ranks.tier" + (i + 1) + ".";
                getConfig().set(k + "prefix", RANK_PREFIXES[i]);
                getConfig().set(k + "name", RANK_NAMES[i]);
            }
            getConfig().set("ranks.style-version", 2);
        }
        saveConfig();
        loadSettings();

        KEY_INF = new NamespacedKey(this, "infinite");
        KEY_SPECIAL = new NamespacedKey(this, "special");
        KEY_POUCH = new NamespacedKey(this, "dirtpouch");
        KEY_CPOUCH = new NamespacedKey(this, "canepouch");
        KEY_WPOUCH = new NamespacedKey(this, "waterpouch");
        KEY_GPOUCH = new NamespacedKey(this, "gratepouch");
        KEY_BREAKER = new NamespacedKey(this, "linebreaker");
        KEY_WAND = new NamespacedKey(this, "copywand");
        buildPouches();
        buildTokenShop();
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "data.yml");

        WorldCreator wc = new WorldCreator(WORLD_NAME);
        wc.generator(new VoidGen());
        wc.biomeProvider(new PlainsBiomes());
        wc.environment(World.Environment.NORMAL);
        wc.generateStructures(false);
        world = wc.createWorld();
        if (world == null) {
            getLogger().severe("Could not create island world! Disabling.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        world.setSpawnLocation(8, 65, 8);

        buildShop();
        buildOptions();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        String[] cmds = {"start", "canehome", "sell", "caneday", "caneinfo", "canerewards", "canetop", "caneshop", "isfly", "caneadmin", "options", "autocaneday", "daytoggle", "is", "reset", "rebirth", "autorebirth", "commands", "lightblock", "removesponge", "drain", "chunkmanagement", "pay", "discord", "tokenshop", "tags", "cosmetic", "playtimerewards", "undo", "wandsettings"};
        for (String c : cmds) {
            if (getCommand(c) != null) getCommand(c).setExecutor((CommandExecutor) this::onCommand);
        }

        if (lpAvailable()) {
            // create the rank groups up front so you can edit their permissions in LuckPerms right away
            getServer().getScheduler().runTask(this, () -> {
                for (Tier t : tiers) {
                    try {
                        LuckPermsHook.ensureGroup(t.group, t.prefix, t.weight, getLogger(), restyle);
                    } catch (Throwable ex) {
                        getLogger().warning("Could not create LuckPerms group " + t.group + ": " + ex);
                    }
                }
            });
        }

        var sch = getServer().getScheduler();
        sch.runTaskTimer(this, this::globalTick, GLOBAL_TICKS, GLOBAL_TICKS); // the ONE timer of the plugin: everything runs in it, only for online players and their chunks
        migrateCores(); // old Auto Sell Chunk Collector chests -> Cane Core beacons right now
        startSandPurge(); // sand was removed: wipe every placed sand block from the islands
    }

    /** (Re)reads everything from config.yml. Used on startup. */
    void loadSettings() {
        baseChance = getConfig().getDouble("growth.base-chance");
        perLevel = getConfig().getDouble("growth.per-level");
        maxChance = getConfig().getDouble("growth.max-chance");
        timerMinutes = getConfig().getInt("timer.minutes");
        coinsPerCane = getConfig().getDouble("coins-per-cane");
        priceMult = getConfig().getDouble("shop.price-multiplier");
        reqMult = getConfig().getDouble("quota.multiplier");
        capReq = getConfig().getLong("quota.cap");
        simMaxOfflineHours = Math.max(0.1, getConfig().getDouble("sim.max-offline-hours"));
        rankChat = getConfig().getBoolean("ranks.show-in-chat");
        rankTab = getConfig().getBoolean("ranks.show-in-tab");
        serverIp = getConfig().getString("server-ip", "CaneFarming.minehut.gg");
        scoreboardOn = getConfig().getBoolean("scoreboard.enabled", true);
        discordLink = getConfig().getString("discord.link", DEFAULT_DISCORD);
        if (discordLink == null || discordLink.isBlank()) discordLink = DEFAULT_DISCORD;
        discordSeconds = Math.max(10, getConfig().getInt("discord.interval-seconds", 120));
        lagEnabled = getConfig().getBoolean("lag-remover.enabled");
        lagThreshold = Math.max(1, getConfig().getInt("lag-remover.entity-threshold"));
        lagTicks = Math.max(3, getConfig().getInt("lag-remover.interval-seconds")) * 20; // the global tick is 3 s, faster is pointless
        lagMinAge = Math.max(0, getConfig().getInt("lag-remover.item-age-seconds")) * 20;
        dailyDrop = Math.max(0, getConfig().getInt("daily-bonus.drop-levels"));
        dailySell = Math.max(0, getConfig().getInt("daily-bonus.sell-levels"));
        rebirthInterval = Math.max(1, getConfig().getInt("rebirth.interval-days"));
        rebirthBonus = getConfig().getDouble("rebirth.bonus-per-rebirth");
        tiers.clear();
        ConfigurationSection rs = getConfig().getConfigurationSection("ranks");
        if (rs != null) {
            for (String key : rs.getKeys(false)) {
                ConfigurationSection t = rs.getConfigurationSection(key);
                if (t == null) continue;
                String g = t.getString("group", "");
                int hrs = t.getInt("hours", -1);
                if (g.isBlank() || hrs < 1) continue;
                tiers.add(new Tier(hrs, g, t.getString("prefix", ""), t.getInt("weight", 0), t.getString("name", g)));
            }
            tiers.sort(java.util.Comparator.comparingInt(t -> t.hours));
        }
    }

    @Override
    public void onDisable() {
        if (world != null) saveDataSync(); // synchronous: the server is stopping, the file must be on disk before we return
        saveExec.shutdown();
    }

    // ------------------------------------------------------------------ helpers
    static Component txt(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    void msg(CommandSender s, String m) {
        s.sendMessage(txt("&6[Cane] &f" + m));
    }

    /** True unless the player turned the master "All Notifications" option off in /options. */
    boolean notif(PD d) {
        return d == null || d.on("notifications");
    }

    /** The "Day N complete!" chat message: off by default, switched on in /options (and still follows the master notification switch). */
    boolean dayMsgOn(PD d) {
        return d != null && d.off.contains("daymsg") && notif(d);
    }

    /** True when the master switch AND this one notification (its own option in /options) are on. */
    boolean notif(PD d, String key) {
        return notif(d) && (d == null || d.on(key));
    }

    /** An automatic notification (not a command reply): only shown while the master switch and its own option are on. */
    void note(Player p, PD d, String key, String m) {
        if (p != null && notif(d, key)) msg(p, m);
    }

    /** A server-wide notification, sent only to the players who have that notification on (and the console). */
    void broadcastNote(String key, String legacy) {
        Component c = txt(legacy);
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (notif(players.get(o.getUniqueId()), key)) o.sendMessage(c);
        }
        Bukkit.getConsoleSender().sendMessage(c);
    }

    /** Island options (/options): both start OFF; the saved set holds the players who switched them ON. */
    boolean waterStopped(PD d) {
        return d != null && d.off.contains("stopwater");
    }

    boolean caneStopped(PD d) {
        return d != null && d.off.contains("stopcane");
    }

    void snd(Player p, PD d, Sound s, float v, float pitch) {
        if (d == null || d.on("sounds")) p.playSound(p.getLocation(), s, v, pitch);
    }

    static String fmt(double v) {
        if (Math.abs(v - Math.rint(v)) < 0.0001) return String.format(Locale.US, "%,.0f", v);
        return String.format(Locale.US, "%,.1f", v);
    }

    static String fmt(long v) {
        return String.format(Locale.US, "%,d", v);
    }

    static String mmss(int s) {
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    static String nice(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String part : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    static long chunkKey(int cx, int cz) {
        return ((long) cx << 32) | (cz & 0xffffffffL);
    }

    static String keyOf(Block b) {
        return b.getX() + "," + b.getY() + "," + b.getZ();
    }

    void give(Player p, ItemStack it) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(it);
        for (ItemStack l : left.values()) p.getWorld().dropItemNaturally(p.getLocation(), l);
    }

    ItemStack named(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(txt(s));
        im.lore(l);
        it.setItemMeta(im);
        return it;
    }

    // ------------------------------------------------------------------ island geometry
    int baseX(PD d) {
        return (d.slot % 64) * 8 + 3;
    }

    int baseZ(PD d) {
        return (d.slot / 64) * 8 + 3;
    }

    Location home(PD d) {
        if (d.hasSpawn) {
            Location c = new Location(world, d.spawnX, d.spawnY, d.spawnZ, d.spawnYaw, d.spawnPitch);
            if (d.id.equals(chunkOwners.get(chunkKey(c.getBlockX() >> 4, c.getBlockZ() >> 4)))) return c;
            d.hasSpawn = false; // chunk no longer owned (e.g. after a chunk reset) - fall back to the default
        }
        return new Location(world, baseX(d) * 16 + 8.5, 65, baseZ(d) * 16 + 8.5, 0f, 0f);
    }

    List<int[]> chunksOf(PD d) {
        List<int[]> l = new ArrayList<>();
        l.add(new int[]{baseX(d), baseZ(d)});
        for (int i = 0; i < d.extra && i < ORDER.size(); i++) {
            int[] o = ORDER.get(i);
            l.add(new int[]{baseX(d) + o[0], baseZ(d) + o[1]});
        }
        return l;
    }

    void indexChunks(PD d) {
        for (int[] c : chunksOf(d)) chunkOwners.put(chunkKey(c[0], c[1]), d.id);
    }

    static boolean isWaterCol(int lx) {
        return (lx % 3 == 1 && lx <= 13) || lx == 15;
    }

    void buildChunk(int cx, int cz, boolean plant) {
        world.getChunkAt(cx, cz);
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = cx * 16 + lx, z = cz * 16 + lz;
                world.getBlockAt(x, 63, z).setType(Material.DIRT, false);
                boolean water = isWaterCol(lx);
                world.getBlockAt(x, 64, z).setType(water ? Material.WATER : Material.DIRT, false);
                if (plant && !water && lz == 7) world.getBlockAt(x, 65, z).setType(Material.SUGAR_CANE, false);
            }
        }
    }

    /** Starter island: a single bedrock block and nothing else. */
    void buildStarter(int cx, int cz) {
        world.getChunkAt(cx, cz);
        world.getBlockAt(cx * 16 + 8, 64, cz * 16 + 8).setType(Material.BEDROCK, false);
    }

    /** Used by /reset: the whole home chunk gets a solid bedrock layer to stand on. */
    void buildBedrockLayer(int cx, int cz) {
        world.getChunkAt(cx, cz);
        for (int lx = 0; lx < 16; lx++)
            for (int lz = 0; lz < 16; lz++)
                world.getBlockAt(cx * 16 + lx, 64, cz * 16 + lz).setType(Material.BEDROCK, false);
    }

    /** Starting items (new island and /reset): Infinite Dirt, 64 sugar cane, Infinite Water Bucket, a Cane Core and the Line Breaker. */
    void giveStarterKit(Player p) {
        give(p, infinite(Material.DIRT));
        give(p, new ItemStack(Material.SUGAR_CANE, 64));
        give(p, infinite(Material.WATER_BUCKET));
        give(p, specialItem("sellcollector"));
        give(p, lineBreaker());
    }

    /** Every chunk a player's island can ever cover: the home chunk plus all chunks /caneshop "New Chunk" can add. */
    List<int[]> fullArea(PD d) {
        List<int[]> l = new ArrayList<>();
        l.add(new int[]{baseX(d), baseZ(d)});
        for (int[] o : ORDER) l.add(new int[]{baseX(d) + o[0], baseZ(d) + o[1]});
        return l;
    }

    boolean addChunk(PD d) {
        if (d.extra >= ORDER.size()) return false;
        int[] o = ORDER.get(d.extra);
        d.extra++;
        int cx = baseX(d) + o[0], cz = baseZ(d) + o[1];
        chunkOwners.put(chunkKey(cx, cz), d.id);
        if (d.on("chunkblocks")) buildChunk(cx, cz, false); // toggle in /chunkmanagement: off = unlocked but empty
        dirty = true;
        return true;
    }

    boolean canBuild(Player p, Location l) {
        if (!l.getWorld().equals(world)) return true;
        if (p.hasPermission("caneislands.admin")) return true;
        UUID o = chunkOwners.get(chunkKey(l.getBlockX() >> 4, l.getBlockZ() >> 4));
        if (o == null) return false;
        if (o.equals(p.getUniqueId())) return true;
        PD od = players.get(o);
        return od != null && od.trusted.contains(p.getUniqueId());
    }

    /** Pouches only ever place inside chunks the player has unlocked (or that a friend trusted them on) - ops/admins get no bypass. */
    boolean canPouch(Player p, Location l) {
        if (!l.getWorld().equals(world)) return false;
        UUID o = chunkOwners.get(chunkKey(l.getBlockX() >> 4, l.getBlockZ() >> 4));
        if (o == null) return false;
        if (o.equals(p.getUniqueId())) return true;
        PD od = players.get(o);
        return od != null && od.trusted.contains(p.getUniqueId());
    }

    void deny(Player p) {
        p.sendActionBar(txt("&cYou can't build here! Only the owner (or players they /is trust) can."));
    }

    // ------------------------------------------------------------------ quota / days
    long required(int day) {
        double v = Math.pow(reqMult, day - 1);
        if (v > 4.0e18) v = 4.0e18;
        long r = (long) v;
        if (r < 1) r = 1;
        if (capReq > 0 && r > capReq) r = capReq;
        return r;
    }

    int timeFor(PD d) {
        return timerMinutes * 60 + 300 * (d.lvl("timeext") + d.rewardTime);
    }

    static final int GROWTH_MAX = 500; // Growth Boost shop upgrade limit (free reward levels count toward the same cap)

    int growthLevel(PD d) {
        return Math.min(GROWTH_MAX, d.rewardGrowth + d.lvl("growth"));
    }

    double dropChance(PD d) {
        return 0.2 * (d.lvl("doubledrop") + d.rewardDrop) + (hasMidas(d) ? MIDAS_DROPS : 0.0);
    }

    // Midas Touch: late game one-time shop item
    static final double MIDAS_PRICE = 25_000_000;  // coins
    static final int MIDAS_REBIRTHS = 5;           // rebirths needed before it can be bought
    static final double MIDAS_COINS = 1.5;         // x coins from every submit and from Auto Sell
    static final double MIDAS_DROPS = 1.0;         // extra Bonus Drops chance (same as 5 Bonus Drops levels)

    boolean hasMidas(PD d) {
        return d.lvl("midas") > 0;
    }

    double midasMult(PD d) {
        return hasMidas(d) ? MIDAS_COINS : 1.0;
    }

    /** Cane Multi: grows exactly like the per-sell multiplier (Coin Boost levels + free daily levels, x Rebirth multiplier),
     *  but it only scales the cane that counts toward the day's quota - never coins, /canetop or anything else. */
    double caneMulti(PD d) {
        return (1.0 + 0.10 * (d.lvl("coinboost") + d.rewardSell)) * rebirthMult(d);
    }

    /** How much of a submit counts toward the day's quota once the Cane Multi is applied. */
    long countedCane(PD d, long amt) {
        double v = amt * caneMulti(d);
        return v >= Long.MAX_VALUE / 4 ? Long.MAX_VALUE / 4 : Math.max(amt, Math.round(v));
    }

    void submit(PD d, long amt) {
        if (amt <= 0) return;
        double rm = rebirthMult(d);
        d.totalCane += Math.round(amt * rm);
        d.coins += amt * coinsPerCane * (1.0 + 0.10 * (d.lvl("coinboost") + d.rewardSell)) * rm * midasMult(d);
        dirty = true;
        if (d.completed) return;
        d.submitted += countedCane(d, amt); // Cane Multi: only the quota progress is multiplied
        if (d.submitted < required(d.day)) return;
        if (!(d.autoDayOn && d.lvl("autoday") > 0)) {
            completeDay(d);
            return;
        }
        // Auto Day: leftover cane carries straight into the next days, so one big sell can pass many days at once.
        // With /autorebirth on, the chain also keeps going THROUGH rebirths (leftover cane carries into the new run),
        // so as much cane as it takes to reach Day 23 again = one rebirth, repeated as often as the cane allows.
        Player p = Bukkit.getPlayer(d.id);
        int startDay = d.day, passed = 0, guard = 0;
        final int maxSteps = d.autoRebirth ? 20000 : 1000;
        chainRebirths = 0;
        chaining = true;
        try {
            while (d.submitted >= required(d.day) && !d.completed && guard++ < maxSteps) {
                long left = d.submitted - required(d.day);
                int before = d.day;
                int rbBefore = d.rebirths;
                completeDay(d);
                passed++;
                boolean rebirthed = d.rebirths != rbBefore;
                if (rebirthed && !d.autoRebirth) break; // (cannot happen: only /autorebirth rebirths inside a chain)
                if (!rebirthed && d.day == before) break; // could not move on
                d.submitted = left;
            }
        } finally {
            chaining = false;
        }
        int chained = chainRebirths;
        chainRebirths = 0;
        if (p != null) {
            if (chained > 0) {
                if (notif(d, "rebirthmsg"))
                    msg(p, "&d&lAUTO REBIRTH! &fYou rebirthed &e" + chained + " &ftime" + (chained == 1 ? "" : "s") + " in a row &7(total: &e" + d.rebirths + "&7, now x" + String.format(Locale.ROOT, "%.2f", rebirthMult(d)) + " cane + coins&7). You're on &eDay " + d.day + "&7.");
                if (notif(d)) snd(p, d, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                refreshTab(p);
            } else if (passed > 0) {
                String what = passed == 1 ? "Day " + startDay : "Days " + startDay + "-" + (startDay + passed - 1);
                if (dayMsgOn(d)) msg(p, "&a&l" + what + " complete!");
                snd(p, d, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            }
        }
    }

    int chainRebirths = 0; // rebirths /autorebirth did inside the current submit() chain (reported once at the end)
    boolean chaining = false; // true while submit() passes several days in a row (their messages are merged into one)

    void completeDay(PD d) {
        d.completed = true;
        Player p = Bukkit.getPlayer(d.id);
        boolean first = d.day > d.bestDay;
        int rewardDay = d.day <= 100 ? d.day : 1 + rng.nextInt(100);
        if (first) {
            d.bestDay = d.day;
            if (p != null) applyReward(p, d, rewardDay, d.day > 100);
            else d.pending.add(rewardDay);
            // daily bonus: every NEW day passed gives permanent free Bonus Drops + Coin Boost levels
            d.rewardDrop += dailyDrop;
            d.rewardSell += dailySell;
            if (p != null && (dailyDrop > 0 || dailySell > 0))
                note(p, d, "dailybonus", "&6Daily bonus: &f+" + dailyDrop + " Bonus Drop level &7and &f+" + dailySell + " Coin Boost level &7(permanent)");
            if (d.day >= TOKEN_START_DAY) { // every new day from Day 35 on is worth 1 Cane Token
                d.tokens++;
                if (p != null) note(p, d, "tokens", "&6+1 Cane Token &7(Day " + d.day + ") - spend them in &e/tokenshop &7(you have &6" + d.tokens + "&7)");
            }
        }
        checkRank(d, p);
        boolean auto = d.autoDayOn && d.lvl("autoday") > 0;
        if (p != null && !chaining) {
            if (dayMsgOn(d)) msg(p, "&a&lDay " + d.day + " complete!" + (auto ? "" : " &7/caneday"));
            snd(p, d, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        if (auto) nextDay(d, p);
        dirty = true;
    }

    boolean lpAvailable() {
        return getServer().getPluginManager().isPluginEnabled("LuckPerms");
    }

    List<String> tierGroups() {
        List<String> l = new ArrayList<>();
        for (Tier t : tiers) l.add(t.group);
        return l;
    }

    /** Gives the highest playtime rank the player qualifies for (via LuckPerms), replacing the lower tiers. */
    void checkRank(PD d, Player p) {
        int idx = 0;
        for (int i = 0; i < tiers.size(); i++) if (d.playMs >= tiers.get(i).hours * 3_600_000L) idx = i + 1;
        if (idx <= d.rankTier) return;
        d.rankTier = idx;
        dirty = true;
        Tier t = tiers.get(idx - 1);
        if (lpAvailable()) {
            try {
                LuckPermsHook.grant(d.id, tierGroups(), t.group, t.prefix, t.weight, getLogger())
                        .thenRun(() -> getServer().getScheduler().runTask(this, () -> {
                            Player on = Bukkit.getPlayer(d.id);
                            if (on != null) refreshTab(on);
                        }));
            } catch (Throwable ex) {
                getLogger().warning("Could not give the LuckPerms rank: " + ex);
            }
        } else {
            getLogger().warning("LuckPerms is not enabled - " + d.name + " earned group '" + t.group + "' but it could not be applied.");
        }
        String shown = t.prefix.trim();
        if (p != null) {
            note(p, d, "rankmsg", "&a&lYou played &e&l" + t.hours + "h &a&land earned the " + shown + " &a&lrank!");
            snd(p, d, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        broadcastNote("broadcasts", "&6[Cane] &e" + d.name + " &fplayed &e" + t.hours + "h &fand earned the " + shown + " &frank!");
    }

    /** Re-applies the rank group (join / startup) in case it was lost, e.g. LuckPerms wasn't ready when it was earned. */
    void syncRank(PD d) {
        if (d.rankTier <= 0 || d.rankTier > tiers.size() || !lpAvailable()) return;
        Tier t = tiers.get(d.rankTier - 1);
        try {
            LuckPermsHook.grant(d.id, tierGroups(), t.group, t.prefix, t.weight, getLogger())
                    .thenRun(() -> getServer().getScheduler().runTask(this, () -> {
                        Player on = Bukkit.getPlayer(d.id);
                        if (on != null) refreshTab(on);
                    }));
        } catch (Throwable ex) {
            getLogger().warning("Could not re-apply the LuckPerms rank for " + d.name + ": " + ex);
        }
    }

    static String lpColor(String s) {
        return s == null ? "" : s.replace('\u00a7', '&');
    }

    /** The player's LuckPerms prefix ("" if none / no LuckPerms). */
    String rankPrefix(Player p) {
        if (!lpAvailable()) return "";
        try {
            return lpColor(LuckPermsHook.prefixOf(p));
        } catch (Throwable t) {
            return "";
        }
    }

    /** Event-driven refresh (join, rebirth, tag change, rank granted...): always re-reads the prefix. */
    void refreshTab(Player p) {
        tabUpdate(p, true);
    }

    /** The cached LuckPerms prefix; re-read when forced, missing, or older than PREFIX_TTL_MS (catches /lp changes made elsewhere). */
    String cachedPrefix(Player p, PerkState s, long now, boolean fresh) {
        if (fresh || s.prefix == null || now - s.prefixAt >= PREFIX_TTL_MS) {
            s.prefix = rankPrefix(p);
            s.prefixAt = now;
        }
        return s.prefix;
    }

    void tabUpdate(Player p, boolean eventDriven) {
        PD d = players.get(p.getUniqueId());
        PerkState s = perkOf(p);
        long now = System.currentTimeMillis();
        if (rankTab) {
            String prefix = cachedPrefix(p, s, now, eventDriven);
            boolean has = d != null;
            String tag = has ? d.activeTag : "";
            String name = has ? d.activeName : "";
            int rb = has ? d.rebirths : 0;
            boolean same = !eventDriven && s.tabSeen && s.tabHasData == has && s.tabRebirths == rb
                    && Objects.equals(prefix, s.tabPrefix) && Objects.equals(tag, s.tabTag) && Objects.equals(name, s.tabName);
            if (!same) {
                String line = prefix + (has ? tagText(d) : "") + nameStyled(d, p.getName());
                if (has) line += " &8[&dRebirth &f" + d.rebirths + "&8]";
                Component want = txt(line);
                if (!want.equals(p.playerListName())) p.playerListName(want);
                s.tabSeen = true;
                s.tabHasData = has;
                s.tabPrefix = prefix;
                s.tabTag = tag;
                s.tabName = name;
                s.tabRebirths = rb;
            }
        }
        if (tabHeader == null)
            tabHeader = txt("&8&m        &r &a&l\u2756 CANE FARMING \u2756 &8&m        ")
                    .append(Component.newline()).append(txt("&7Farm \u2022 Sell \u2022 Rebirth"));
        int online = Bukkit.getOnlinePlayers().size();
        if (tabFooter == null || tabFooterOnline != online || !serverIp.equals(tabFooterIp)) {
            tabFooter = txt("&7Server IP: &e" + serverIp)
                    .append(Component.newline()).append(txt("&7Online: &a" + online));
            tabFooterOnline = online;
            tabFooterIp = serverIp;
            tabVersion++;
        }
        if (s.tabVersion != tabVersion) { // header/footer packet only when this player has not seen the current one
            p.sendPlayerListHeaderAndFooter(tabHeader, tabFooter);
            s.tabVersion = tabVersion;
        }
    }

    /** Chat: [rank tag] Name: message - the tag is the only decoration, the name and message are plain white. */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onChat(io.papermc.paper.event.player.AsyncChatEvent e) {
        if (!rankChat) return;
        PD cd = players.get(e.getPlayer().getUniqueId());
        final String prefix = rankPrefix(e.getPlayer()) + (cd == null ? "" : tagText(cd));
        final Component pre = prefix.isEmpty() ? Component.empty() : txt(prefix);
        final boolean colored = cd != null && tokenById.containsKey(cd.activeName);
        e.renderer(io.papermc.paper.chat.ChatRenderer.viewerUnaware((source, display, message) ->
                pre.append(colored
                                ? txt(nameStyled(cd, net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(display)))
                                : display.color(NamedTextColor.WHITE))
                        .append(Component.text(": ", NamedTextColor.WHITE))
                        .append(message.color(NamedTextColor.WHITE))));
    }

    // ------------------------------------------------------------------ sidebar scoreboard
    static String shortNum(double v) {
        String[] suf = {"", "K", "M", "B", "T", "Qa", "Qi"};
        int i = 0;
        double a = Math.abs(v);
        while (a >= 1000 && i < suf.length - 1) {
            a /= 1000.0;
            i++;
        }
        if (i == 0) return fmt(v);
        return String.format(Locale.US, "%.2f", Math.signum(v) * a).replaceAll("\\.?0+$", "") + suf[i];
    }

    /** A number for the sidebar: full with commas (1,500) until it gets huge, then shortened (2.5B). */
    static String qty(long v) {
        return v >= 1_000_000_000L ? shortNum(v) : fmt(v);
    }

    /** What the sidebar shows as the player's rank: the token-shop Femboy rank if they own and wear it, else their playtime rank. */
    String rankLabel(PD d) {
        if (d.owned.contains("rank_femboy") && d.on("femboy")) return "&d&l\u2665 Femboy";
        return d.rankTier > 0 && d.rankTier <= tiers.size() ? tiers.get(d.rankTier - 1).name : "&7None";
    }

    static String fmtPlay(long ms) {
        long m = ms / 60000L;
        return (m / 60) + "h " + (m % 60) + "m";
    }

    /** " (next rank: X at 3h)" for /caneinfo. */
    String nextRankText(PD d) {
        for (Tier t : tiers) if (d.playMs < t.hours * 3_600_000L) return " &7(next rank: " + t.name + " &7at " + t.hours + "h)";
        return " &7(all playtime ranks earned!)";
    }

    /** Per-minute rate for the sidebar: one decimal while small (12.5), whole and shortened when big (1.2K). */
    static String rateStr(double v) {
        if (v >= 100) return shortNum(Math.round(v));
        return String.format(Locale.US, "%.1f", v).replaceAll("\\.0$", "");
    }

    /** Coins one cane is worth for this player (Coin Boost, daily bonus and rebirth multiplier included). */
    double coinsPerCaneOf(PD d) {
        return coinsPerCane * (1.0 + 0.10 * (d.lvl("coinboost") + d.rewardSell)) * rebirthMult(d) * midasMult(d);
    }

    void removeBoard(Player p) {
        if (boards.remove(p.getUniqueId()) == null) return;
        ScoreboardManager sm = Bukkit.getScoreboardManager();
        if (sm != null) p.setScoreboard(sm.getMainScoreboard());
    }

    Board createBoard(Player p) {
        ScoreboardManager sm = Bukkit.getScoreboardManager();
        if (sm == null) return null;
        Board b = new Board();
        b.sb = sm.getNewScoreboard();
        b.obj = b.sb.registerNewObjective("cane", Criteria.DUMMY, txt("&a&l\u2756 &f&lCANE FARMING &a&l\u2756"));
        b.obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        b.obj.numberFormat(NumberFormat.blank()); // hide the red score numbers
        for (int i = 0; i < BOARD_LINES; i++) {
            Team t = b.sb.registerNewTeam("l" + i);
            t.addEntry(BOARD_ENTRIES[i]);
            b.teams[i] = t;
            b.obj.getScore(BOARD_ENTRIES[i]).setScore(BOARD_LINES - i);
        }
        p.setScoreboard(b.sb);
        return b;
    }

    /** Once a second: refreshes every online player's sidebar. The /canetop order is sorted once for everybody. */
    void scoreboardTick() {
        if (!scoreboardOn) {
            for (Player p : Bukkit.getOnlinePlayers()) removeBoard(p);
            return;
        }
        long now = System.currentTimeMillis();
        if (rankCache == null || now - rankAt >= 5000) { // one sort for the whole server every 5 s, not every second
            List<PD> top = new ArrayList<>(players.values());
            top.sort((x, y) -> Long.compare(y.totalCane, x.totalCane));
            leaderCache = top.isEmpty() ? null : top.get(0);
            Map<UUID, Integer> rk = new HashMap<>();
            for (int i = 0; i < top.size(); i++) rk.put(top.get(i).id, i + 1);
            rankCache = rk;
            rankAt = now;
        }
        PD leader = leaderCache;
        Map<UUID, Integer> ranks = rankCache;
        Set<UUID> collectorOwners = new HashSet<>(); // who has a Cane Core placed (found once for everybody)
        for (Special sp : specials.values())
            if (sp.type.equals("sellcollector") && sp.owner != null) collectorOwners.add(sp.owner);

        // lines that are the same for every player: built once, only when their inputs change
        String leaderLine;
        if (leader == null) {
            leaderLine = "  &7-";
        } else {
            if (sbLeaderLine == null || leader != sbLeader || leader.totalCane != sbLeaderCane || !Objects.equals(leader.name, sbLeaderName)) {
                sbLeaderLine = "  &f" + leader.name + " &7(" + shortNum(leader.totalCane) + ")";
                sbLeader = leader;
                sbLeaderCane = leader.totalCane;
                sbLeaderName = leader.name;
            }
            leaderLine = sbLeaderLine;
        }
        if (sbIpLine == null || !serverIp.equals(sbIpSrc)) {
            sbIpSrc = serverIp;
            sbIpLine = "&e&l" + serverIp;
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            if (!d.on("scoreboard")) {
                removeBoard(p);
                continue;
            }
            Board b = boards.get(p.getUniqueId());
            if (b == null) {
                b = createBoard(p);
                if (b == null) return;
                boards.put(p.getUniqueId(), b);
            } else if (p.getScoreboard() != b.sb) {
                p.setScoreboard(b.sb); // something else took the scoreboard away
            }
            long[] sc = stalkCache.get(d.id);
            if (sc == null || now - sc[0] >= 5000) {
                sc = new long[]{now, stalksOf(d)};
                stalkCache.put(d.id, sc);
            }
            SbCache c = sbCache.get(d.id);
            if (c == null || c.board != b) { // first time, or the board was recreated: all lines are rebuilt
                c = new SbCache();
                c.board = b;
                sbCache.put(d.id, c);
            }
            final String[] L = c.L;

            if (L[0] == null) L[0] = "&a\u00BB &f&lPlayer &a" + p.getName();

            if (d.completed) {
                if (L[1] == null || !c.l1Done || c.l1Day != d.day) {
                    L[1] = "&a\u00BB &f&lDay &e" + d.day + " &a\u2714 Done &7(/caneday)";
                    c.l1Done = true;
                    c.l1Day = d.day;
                }
            } else {
                long req = required(d.day);
                boolean headSame = c.l1Head != null && !c.l1Done && c.l1Day == d.day && c.l1Sub == d.submitted && c.l1Req == req;
                if (!headSame) {
                    c.l1Head = "&a\u00BB &f&lDay &e" + d.day + " &7(&f" + qty(d.submitted) + "&7/&f" + qty(req) + "&7) &c";
                    c.l1Done = false;
                    c.l1Day = d.day;
                    c.l1Sub = d.submitted;
                    c.l1Req = req;
                }
                int left = Math.max(0, d.timeLeft);
                if (!headSame || L[1] == null || c.l1Left != left) {
                    L[1] = c.l1Head + mmss(left);
                    c.l1Left = left;
                }
            }

            if (L[2] == null || c.rebirths != d.rebirths) {
                L[2] = "&a\u00BB &f&lRebirth &d" + d.rebirths;
                c.rebirths = d.rebirths;
            }
            if (L[3] == null || !sameD(c.coins, d.coins)) {
                L[3] = "&a\u00BB &f&lBalance &6" + shortNum(d.coins);
                c.coins = d.coins;
            }
            if (L[4] == null || c.tokens != d.tokens) {
                L[4] = "&a\u00BB &f&lTokens &b" + d.tokens;
                c.tokens = d.tokens;
            }
            String rank = rankLabel(d);
            if (L[5] == null || !rank.equals(c.rank)) {
                L[5] = "&a\u00BB &f&lRank " + rank;
                c.rank = rank;
            }
            if (L[6] == null || c.stalks != sc[1]) {
                L[6] = "&a\u00BB &f&lCane Placed &a" + fmt(sc[1]);
                c.stalks = sc[1];
            }
            double perSell = coinsPerCaneOf(d);
            if (L[7] == null || !sameD(c.perSell, perSell)) {
                L[7] = "&a\u00BB &f&lPer Sell &e" + String.format(Locale.US, "%.2f", perSell) + " &7/cane";
                c.perSell = perSell;
            }
            // growth: Growth Boost level (shop + daily rewards) and the chance each cane has to grow a block every 2 seconds
            int gLvl = growthLevel(d);
            double gCh = growthChance(d);
            if (L[8] == null || c.growthLvl != gLvl || !sameD(c.growthCh, gCh)) {
                L[8] = "&a\u00BB &f&lGrowth &aLv " + gLvl + " &7(" + String.format(Locale.US, "%.1f", gCh * 100.0) + "%)";
                c.growthLvl = gLvl;
                c.growthCh = gCh;
            }
            // selling: cane per minute the Cane Core sells (0 without one). Every Growth Boost level raises it.
            double perMin = collectorOwners.contains(d.id) ? simRate(d, (int) sc[1]) * 60.0 : 0.0;
            if (L[9] == null || !sameD(c.perMin, perMin)) {
                L[9] = "&a\u00BB &f&lSelling &e" + rateStr(perMin) + " &7cane/min";
                c.perMin = perMin;
            }
            double multi = caneMulti(d);
            if (L[10] == null || !sameD(c.multi, multi)) {
                L[10] = "&a\u00BB &f&lCane Multi &bx" + String.format(Locale.US, "%.2f", multi);
                c.multi = multi;
            }
            L[11] = SB_TOP_LINE;
            L[12] = leaderLine;
            int myRank = ranks.getOrDefault(d.id, 0);
            if (L[13] == null || c.topRank != myRank) {
                L[13] = "&6&l\u2605 Your CaneTop &f#" + myRank;
                c.topRank = myRank;
            }
            L[14] = sbIpLine;

            for (int i = 0; i < BOARD_LINES; i++) {
                if (L[i].equals(b.last[i])) continue;
                b.last[i] = L[i];
                b.teams[i].prefix(txt(L[i]));
            }
        }
        sbCache.keySet().removeIf(id -> !boards.containsKey(id)); // players whose board is gone
    }

    // ------------------------------------------------------------------ rebirth
    double rebirthMult(PD d) {
        return 1.0 + rebirthBonus * d.rebirths;
    }

    /** Day the player must reach for their next rebirth. */
    static final int REBIRTH_DAY = 23; // Rebirth is always available from this day on

    int rebirthDay(PD d) {
        return REBIRTH_DAY;
    }

    /** True after N rebirths in a row that each came less than X seconds after the one before: the next one costs more. */
    boolean penaltyActive(PD d) {
        return false; // no fast-rebirth penalty any more: Rebirth is always available at Day 23
    }

    boolean rebirthReady(PD d) {
        return d.runBest >= rebirthDay(d);
    }

    void doRebirth(PD d, Player p) {
        long nowMs = System.currentTimeMillis();
        boolean paidPenalty = penaltyActive(d);
        if (paidPenalty) d.fastStreak = 0; // paid the higher price, start counting again
        else if (d.lastRebirth > 0 && nowMs - d.lastRebirth < fastPrestigeSeconds * 1000L) d.fastStreak++;
        else d.fastStreak = 0;
        d.lastRebirth = nowMs;
        d.rebirths++;
        if (d.rebirths % TOKEN_REBIRTH_EVERY == 0) { // every 1000th rebirth is worth 1 Cane Token
            d.tokens++;
            if (p != null) note(p, d, "tokens", "&6+1 Cane Token &7(" + d.rebirths + " rebirths) - spend them in &e/tokenshop &7(you have &6" + d.tokens + "&7)");
        }
        d.totalCane = 0; // resets the /canetop count
        // back to the very start: Day 1 with a fresh quota + timer. bestDay is kept, so days you already
        // reached never give their reward (or daily bonus) again until you pass your best day.
        d.day = 1;
        d.runBest = 1;
        d.submitted = 0;
        d.completed = false;
        d.timeLeft = timeFor(d);
        // every shop price you have raised gets one step (x/multiplier) cheaper; items still at their base price stay there.
        // The next purchase of any item always multiplies its price again.
        for (Map.Entry<String, Integer> en : d.bought.entrySet()) {
            int base = d.priceBase.getOrDefault(en.getKey(), 0);
            if (en.getValue() - base > 0) d.priceBase.put(en.getKey(), base + 1);
        }
        dirty = true;
        final boolean quiet = chaining && autoRebirthing; // inside a multi-rebirth chain: submit() sends one summary
        if (quiet) chainRebirths++;
        if (p != null && !quiet) {
            rmsg(p, d, "&d&lREBIRTH! &fYou have rebirthed &e" + d.rebirths + " &ftime(s). You're back on &eDay 1&f, your /canetop count was reset and all cane + coins from submits are now &ex" + String.format(Locale.ROOT, "%.2f", rebirthMult(d)) + "&f.");
            rmsg(p, d, "&7Shop prices dropped by &ex" + fmt(priceMult) + " &7(one purchase step) for everything you bought. Every new purchase still multiplies the price again.");
            rmsg(p, d, "&7No rewards for days you already reached - new rewards start again at Day " + (d.bestDay + 1) + ". Next rebirth at Day " + rebirthDay(d) + ".");
            if (penaltyActive(d))
                rmsg(p, d, "&c&lToo fast! &cYou rebirthed " + fastPrestigeStreak + " times in a row in under " + fastPrestigeSeconds + "s, so your next rebirth costs &ex" + fastPrestigeMult + " &c- it needs &eDay " + rebirthDay(d) + "&c.");
            else if (paidPenalty)
                rmsg(p, d, "&aThe fast-rebirth penalty is gone - your next rebirth is back to Day " + rebirthDay(d) + ".");
            if (!autoRebirthing || notif(d)) snd(p, d, Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
            refreshTab(p);
        }
    }

    /** Rebirth message: always shown for a manual /rebirth, but follows the notification option when /autorebirth did it. */
    void rmsg(Player p, PD d, String m) {
        if (!autoRebirthing || notif(d, "rebirthmsg")) msg(p, m);
    }

    boolean autoRebirthing = false; // true while /autorebirth does the rebirth (its messages follow the notification option)

    /** Tells the player they can rebirth, or does it for them when /autorebirth is on. */
    void checkRebirthReady(PD d, Player p) {
        if (!rebirthReady(d)) return;
        if (d.autoRebirth) {
            autoRebirthing = true;
            try {
                doRebirth(d, p);
            } finally {
                autoRebirthing = false;
            }
        } else if (p != null && d.day == rebirthDay(d)) {
            note(p, d, "rebirthready", "&d&lYou can rebirth! &7Type &e/rebirth &7(or turn on &e/autorebirth&7).");
        }
    }

    void cmdRebirth(Player p, PD d, String[] a) {
        if (!rebirthReady(d)) {
            msg(p, "&cYou need to reach &eDay " + rebirthDay(d) + " &cto rebirth. &7(You are on Day " + d.day + ", best this run: Day " + d.runBest + ")");
            return;
        }
        long now = System.currentTimeMillis();
        if (a.length > 0 && a[0].equalsIgnoreCase("confirm")) {
            Long t = rebirthConfirm.remove(p.getUniqueId());
            if (t == null || now - t > 30000) {
                msg(p, "&cNothing to confirm. Type &e/rebirth &cfirst.");
                return;
            }
            doRebirth(d, p);
            return;
        }
        rebirthConfirm.put(p.getUniqueId(), now);
        double next = 1.0 + rebirthBonus * (d.rebirths + 1);
        msg(p, "&d&lREBIRTH: &fThis sends you back to &eDay 1 &fand resets your &e/canetop &fcane count (" + fmt(d.totalCane) + ") to 0. Your coins and upgrades are kept.");
        msg(p, "&7You won't earn rewards again for days you already reached (best: Day " + d.bestDay + ").");
        msg(p, "&fAfter rebirthing, cane count and coins from every submit are multiplied by &ex" + String.format(Locale.ROOT, "%.2f", next) + "&f.");
        if (penaltyActive(d))
            msg(p, "&cYou rebirthed too fast, so this rebirth cost &ex" + fastPrestigeMult + " &c(Day " + rebirthDay(d) + " instead of Day " + rebirthInterval + ").");
        msg(p, "&7Type &e/rebirth confirm &7within 30 seconds to continue.");
    }

    void cmdAutoRebirth(Player p, PD d) {
        d.autoRebirth = !d.autoRebirth;
        dirty = true;
        if (d.autoRebirth) {
            msg(p, "&aAuto Rebirth &2enabled&a. &7You'll rebirth automatically whenever you reach Day " + rebirthDay(d) + ".");
            if (rebirthReady(d)) doRebirth(d, p);
        } else {
            msg(p, "&cAuto Rebirth disabled. &7Use &e/rebirth &7manually.");
        }
    }

    void nextDay(PD d, Player p) {
        d.day++;
        if (d.day > d.runBest) d.runBest = d.day;
        d.completed = false;
        d.submitted = 0;
        d.timeLeft = timeFor(d);
        dirty = true;
        checkRank(d, p);
        checkRebirthReady(d, p);
    }

    void failDay(Player p, PD d) {
        int old = d.day;
        d.day = 1;
        d.submitted = 0;
        d.completed = false;
        d.timeLeft = timeFor(d);
        dirty = true;
        note(p, d, "failday", "&c&lYou failed Day " + old + "! &cYou're back to Day 1. Rewards you already earned won't repeat until you pass Day " + (d.bestDay + 1) + ".");
        snd(p, d, Sound.ENTITY_WITHER_DEATH, 0.6f, 1f);
    }

    // ------------------------------------------------------------------ rewards
    Rw reward(int rd) {
        List<String> ds = new ArrayList<>();
        List<BiConsumer<Player, PD>> acts = new ArrayList<>();
        final double coins = rd * 2.0 + 5;
        ds.add("+" + fmt(coins) + " coins");
        acts.add((p, d) -> d.coins += coins);

        if (rd == 1) {
            ds.add("Starter pack: 32 Sugar Cane");
            acts.add((p, d) -> give(p, new ItemStack(Material.SUGAR_CANE, 32)));
        }
        switch (rd % 10) {
            case 1, 4, 6 -> {
                ds.add("Growth Boost +1");
                acts.add((p, d) -> d.rewardGrowth += 1);
            }
            case 2 -> {
                ds.add("Bonus Drops +1");
                acts.add((p, d) -> d.rewardDrop += 1);
            }
            case 3 -> {
                ds.add("Chunk Hopper");
                acts.add((p, d) -> give(p, specialItem("chunkhopper")));
            }
            case 5 -> {
                ds.add("Cane Core");
                acts.add((p, d) -> give(p, specialItem("sellcollector")));
            }
            case 7 -> {
                final int pick = (rd / 10) % 5;
                {
                    Material[] inf = {Material.DIRT, Material.GLASS, Material.COARSE_DIRT};
                    final Material mm = inf[pick % inf.length];
                    ds.add("Infinite " + nice(mm));
                    acts.add((p, d) -> give(p, infinite(mm)));
                }
            }
            case 8 -> {
                final int amt = 32 + rd;
                ds.add(amt + " Sugar Cane");
                acts.add((p, d) -> give(p, new ItemStack(Material.SUGAR_CANE, amt)));
            }
            case 9 -> {
                final double bonus = rd * 10.0;
                ds.add("Coin pouch: +" + fmt(bonus) + " coins");
                acts.add((p, d) -> d.coins += bonus);
            }
            case 0 -> {
                ds.add("Free Chunk (1,000 coins if you own them all) + Growth Boost +2");
                acts.add((p, d) -> {
                    if (!addChunk(d)) d.coins += 1000;
                    d.rewardGrowth += 2;
                });
            }
            default -> {
            }
        }
        if (rd % 25 == 0) {
            ds.add("+5 minutes on your daily timer");
            acts.add((p, d) -> d.rewardTime += 1);
        }
        return new Rw(String.join(", ", ds), (p, d) -> {
            for (BiConsumer<Player, PD> a : acts) a.accept(p, d);
        });
    }

    void applyReward(Player p, PD d, int rd, boolean random) {
        Rw r = reward(rd);
        r.act.accept(p, d);
        String head = random ? "&6Random reward (from Day " + rd + "): " : "&6Day reward: ";
        note(p, d, "rewards", head + "&f" + r.desc);
        snd(p, d, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        dirty = true;
    }

    // ------------------------------------------------------------------ special / infinite items
    ItemStack infinite(Material m) {
        ItemStack it = new ItemStack(m, m.getMaxStackSize());
        ItemMeta im = it.getItemMeta();
        im.displayName(txt("&b\u221E Infinite " + nice(m)));
        im.lore(List.of(txt("&7Never runs out when placed!")));
        im.setEnchantmentGlintOverride(true);
        im.getPersistentDataContainer().set(KEY_INF, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(im);
        return it;
    }

    ItemStack specialItem(String type) {
        Material m;
        String name;
        List<String> lore = new ArrayList<>();
        switch (type) {
            case "sellcollector" -> {
                m = Material.BEACON;
                name = "&6Cane Core";
                lore.add("&7Counts every sugar cane plant on your whole island");
                lore.add("&7(all chunks, all layers) and automatically pays you");
                lore.add("&7the cane it would have grown - with your Growth Boost,");
                lore.add("&7Bonus Drops, Coin Boost and Rebirth multipliers.");
                lore.add("&7Adds to your balance, /canetop and daily quota.");
            }
            case "chunkhopper" -> {
                m = Material.HOPPER;
                name = "&6Chunk Hopper";
                lore.add("&7Collects EVERY dropped item in its chunk.");
                lore.add("&7Items go into the chest it points at.");
                lore.add("&7With nothing to point at it keeps them itself.");
            }
            default -> throw new IllegalArgumentException("Unknown special item: " + type);
        }
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(name));
        List<Component> l = new ArrayList<>();
        for (String s : lore) l.add(txt(s));
        im.lore(l);
        im.setEnchantmentGlintOverride(true);
        im.getPersistentDataContainer().set(KEY_SPECIAL, PersistentDataType.STRING, type);
        it.setItemMeta(im);
        return it;
    }

    // ------------------------------------------------------------------ pouches (dirt + sugar cane)
    /** One kind of pouch: which block it stores, which (inert) item it looks like, and how it behaves. */
    static class PouchType {
        final Material store, item;
        final NamespacedKey key;
        final String name, what;
        final Sound sound;
        final boolean infinite; // an Infinite version of the block exists, so the lore can mention it

        PouchType(Material store, Material item, NamespacedKey key, String name, String what, Sound sound, boolean infinite) {
            this.store = store;
            this.item = item;
            this.key = key;
            this.name = name;
            this.what = what;
            this.sound = sound;
            this.infinite = infinite;
        }
    }

    final Map<Material, PouchType> pouchByStore = new LinkedHashMap<>();
    final Map<Material, PouchType> pouchByItem = new HashMap<>();

    void regPouch(Material store, Material item, NamespacedKey key, String name, String what, Sound sound, boolean infinite) {
        PouchType t = new PouchType(store, item, key, name, what, sound, infinite);
        pouchByStore.put(store, t);
        pouchByItem.put(item, t);
    }

    void buildPouches() {
        // the first three keep their original keys so pouches players already own keep working
        regPouch(Material.DIRT, Material.LEATHER, KEY_POUCH, "Dirt Pouch", "dirt", Sound.BLOCK_GRAVEL_PLACE, true);
        regPouch(Material.SUGAR_CANE, Material.RABBIT_HIDE, KEY_CPOUCH, "Cane Pouch", "sugar cane", Sound.BLOCK_GRASS_PLACE, false);
        regPouch(Material.COPPER_GRATE, Material.COPPER_INGOT, KEY_GPOUCH, "Copper Grate Pouch", "copper grates", Sound.BLOCK_COPPER_PLACE, true);
        regPouch(Material.OAK_LEAVES, Material.PHANTOM_MEMBRANE, new NamespacedKey(this, "pouch_oak_leaves"), "Oak Leaves Pouch", "oak leaves", Sound.BLOCK_GRASS_PLACE, false);
        regPouch(Material.SEA_LANTERN, Material.PRISMARINE_CRYSTALS, new NamespacedKey(this, "pouch_sea_lantern"), "Sea Lantern Pouch", "sea lanterns", Sound.BLOCK_GLASS_PLACE, false);
        regPouch(Material.OCHRE_FROGLIGHT, Material.GOLD_NUGGET, new NamespacedKey(this, "pouch_ochre_froglight"), "Ochre Froglight Pouch", "ochre froglights", Sound.BLOCK_FROGLIGHT_PLACE, false);
        regPouch(Material.VERDANT_FROGLIGHT, Material.SLIME_BALL, new NamespacedKey(this, "pouch_verdant_froglight"), "Verdant Froglight Pouch", "verdant froglights", Sound.BLOCK_FROGLIGHT_PLACE, false);
        regPouch(Material.PEARLESCENT_FROGLIGHT, Material.AMETHYST_SHARD, new NamespacedKey(this, "pouch_pearlescent_froglight"), "Pearlescent Froglight Pouch", "pearlescent froglights", Sound.BLOCK_FROGLIGHT_PLACE, false);
        regPouch(Material.SPONGE, Material.HONEYCOMB, new NamespacedKey(this, "pouch_sponge"), "Sponge Pouch", "sponges", Sound.BLOCK_GRASS_PLACE, false);
    }

    /** Every pouch is unlimited: it never runs out (no need to store anything or carry an Infinite item). */
    boolean unlimited(Material m) {
        return pouchByStore.containsKey(m);
    }

    /** Which block a pouch stores, or null if the item is not a pouch. */
    Material pouchStore(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        PouchType t = pouchByItem.get(it.getType());
        if (t == null) return null;
        return it.getItemMeta().getPersistentDataContainer().has(t.key, PersistentDataType.INTEGER) ? t.store : null;
    }

    NamespacedKey pouchKey(Material store) {
        return pouchByStore.get(store).key;
    }

    String pouchName(Material store) {
        return pouchByStore.get(store).name;
    }

    String pouchWhat(Material store) {
        return pouchByStore.get(store).what;
    }

    ItemStack pouchItem(Material store, int amount) {
        PouchType t = pouchByStore.get(store);
        ItemStack it = new ItemStack(t.item);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt("&6" + t.name));
        im.setMaxStackSize(1); // pouches never stack
        im.setEnchantmentGlintOverride(true);
        im.getPersistentDataContainer().set(t.key, PersistentDataType.INTEGER, Math.max(0, Math.min(amount, POUCH_CAP)));
        it.setItemMeta(im);
        refreshPouchLore(it);
        return it;
    }

    boolean isPouch(ItemStack it) {
        return pouchStore(it) != null;
    }

    int pouchAmount(ItemStack it) {
        Material store = pouchStore(it);
        if (store == null) return 0;
        Integer v = it.getItemMeta().getPersistentDataContainer().get(pouchKey(store), PersistentDataType.INTEGER);
        return v == null ? 0 : Math.max(0, Math.min(v, POUCH_CAP));
    }

    void setPouchAmount(ItemStack it, int amount) {
        Material store = pouchStore(it);
        if (store == null) return;
        final int a = Math.max(0, Math.min(amount, POUCH_CAP));
        it.editMeta(im -> im.getPersistentDataContainer().set(pouchKey(store), PersistentDataType.INTEGER, a));
        refreshPouchLore(it);
    }

    void refreshPouchLore(ItemStack it) {
        final Material store = pouchStore(it);
        if (store == null) return;
        final PouchType t = pouchByStore.get(store);
        final int a = pouchAmount(it);
        final boolean cane = store == Material.SUGAR_CANE;
        List<Component> lore = new ArrayList<>();
        lore.add(txt(cane ? "&7Right-click to plant a line of sugar cane the way you face," : "&7Right-click to place a line of " + t.what + " the way you face,"));
        lore.add(txt(cane ? "&7skipping spots where cane can't grow, until the island edge." : "&7until it hits a block or the edge of your island."));
        if (unlimited(store)) {
            lore.add(txt("&bIt never runs out - unlimited " + t.what + "!"));
            lore.add(txt("&7Only works on islands you can build on."));
        } else {
            lore.add(txt("&7Sneak + right-click to store " + t.what + " from your inventory."));
            if (t.infinite) lore.add(txt("&bCarry an Infinite " + nice(store) + " and it never uses up your stored " + t.what + "."));
            lore.add(txt("&7Only works on islands you can build on."));
            lore.add(txt(" "));
            lore.add(txt("&eStored: &f" + fmt(a) + "&7/" + fmt(POUCH_CAP)));
        }
        it.editMeta(im -> im.lore(lore));
    }

    // ------------------------------------------------------------------ infinite water pouch
    static final int WATER_LINE_MAX = 32; // water sources per click

    ItemStack waterPouchItem() {
        ItemStack it = new ItemStack(Material.NAUTILUS_SHELL);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt("&b\u221E Water Pouch"));
        im.setMaxStackSize(1);
        im.setEnchantmentGlintOverride(true);
        im.lore(List.of(
                txt("&7Right-click to place a line of water the way you face,"),
                txt("&7waterlogging leaves, slabs, stairs, grates etc. on the way,"),
                txt("&7until it hits a block or the edge of your island."),
                txt("&7It never runs out! Use a Sponge to clean up."),
                txt("&7Only works on islands you can build on.")));
        im.getPersistentDataContainer().set(KEY_WPOUCH, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(im);
        return it;
    }

    boolean isWaterPouch(ItemStack it) {
        if (it == null || it.getType() != Material.NAUTILUS_SHELL || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(KEY_WPOUCH, PersistentDataType.BYTE);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onWaterPouchUse(PlayerInteractEvent e) {
        ItemStack item = e.getItem();
        if (!isWaterPouch(item)) return;
        Action act = e.getAction();
        if (act != Action.RIGHT_CLICK_BLOCK && act != Action.RIGHT_CLICK_AIR) return;
        EquipmentSlot hand = e.getHand();
        if (hand == null) return;
        Player p = e.getPlayer();
        Block clicked = e.getClickedBlock();
        if (clicked != null && !p.isSneaking() && clicked.getType().isInteractable()) return;
        if (clicked != null && e.useInteractedBlock() == org.bukkit.event.Event.Result.DENY) {
            e.setCancelled(true);
            return;
        }
        e.setCancelled(true);
        if (!p.getWorld().equals(world)) {
            msg(p, "&cThe Water Pouch only works on the cane islands.");
            return;
        }
        if (clicked == null) return;
        waterPouchPlace(p, hand, clicked, e.getBlockFace());
    }

    /** Right-click: a line of water sources the way the player faces; stops at obstacles / the island edge. Never uses anything up. */
    void waterPouchPlace(Player p, EquipmentSlot hand, Block clicked, BlockFace face) {
        long now = System.currentTimeMillis();
        Long last = pouchCooldown.get(p.getUniqueId());
        if (last != null && now - last < POUCH_COOLDOWN_MS) return;
        pouchCooldown.put(p.getUniqueId(), now);
        ItemStack pouch = p.getInventory().getItem(hand);
        if (!isWaterPouch(pouch)) return;
        Block first = clicked.isReplaceable() || clicked.getBlockData() instanceof org.bukkit.block.data.Waterlogged ? clicked : clicked.getRelative(face);
        BlockFace dir = p.getFacing();
        if (dir == BlockFace.UP || dir == BlockFace.DOWN) return;
        int placed = 0, steps = 0;
        Block cur = first;
        Block against = clicked;
        while (steps < WATER_LINE_MAX) {
            if (!isWaterPouch(p.getInventory().getItem(hand))) break;
            if (!cur.getWorld().equals(world) || cur.getY() < world.getMinHeight() || cur.getY() >= world.getMaxHeight()) break;
            if (steps == 0 && !canPouch(p, clicked.getLocation())) {
                deny(p);
                return;
            }
            if (!canPouch(p, cur.getLocation())) {
                if (steps == 0) deny(p);
                break;
            }
            if (specials.containsKey(keyOf(cur))) break;
            if (cur.getType() == Material.WATER) { // already water: carry on past it
                steps++;
                against = cur;
                cur = cur.getRelative(dir);
                continue;
            }
            // waterloggable blocks (leaves, slabs, stairs, fences, copper grates...) get waterlogged and the line carries on through them
            if (cur.getBlockData() instanceof org.bukkit.block.data.Waterlogged wl) {
                if (!wl.isWaterlogged()) {
                    BlockState old = cur.getState();
                    wl.setWaterlogged(true);
                    cur.setBlockData(wl, true);
                    BlockPlaceEvent wev = new BlockPlaceEvent(cur, old, against, pouch, p, true, hand);
                    getServer().getPluginManager().callEvent(wev);
                    if (wev.isCancelled() || !wev.canBuild()) {
                        old.update(true, false);
                        break;
                    }
                    placed++;
                }
                steps++;
                against = cur;
                cur = cur.getRelative(dir);
                continue;
            }
            boolean free = steps == 0 ? cur.isReplaceable() : airish(cur);
            if (!free || specials.containsKey(keyOf(cur))) break;
            BlockState old = cur.getState();
            cur.setType(Material.WATER, true);
            BlockPlaceEvent ev = new BlockPlaceEvent(cur, old, against, pouch, p, true, hand);
            getServer().getPluginManager().callEvent(ev);
            if (ev.isCancelled() || !ev.canBuild()) {
                old.update(true, false);
                break;
            }
            placed++;
            steps++;
            against = cur;
            cur = cur.getRelative(dir);
        }
        if (placed == 0) return;
        world.playSound(first.getLocation().add(0.5, 0.5, 0.5), Sound.ITEM_BUCKET_EMPTY, 1f, 1f);
        p.sendActionBar(txt("&bPlaced &f" + placed + " &bwater &7- &b\u221E infinite"));
    }

    // ------------------------------------------------------------------ copy & paste wand
    static final int WAND_MAX_DEPTH = 128; // longest area that can be copied in front of the player
    static final int WAND_MAX_SIDE = 15;   // widest each side can be (31 wide in total)
    static final int WAND_MAX_LAYERS = 8;  // most layers that can be copied
    static final int WAND_MAX_GAP = 16;    // furthest the area can start from the player
    static final long WAND_COOLDOWN_MS = 400;

    /** One paste that can be undone: where blocks went, what was there before and what was placed. */
    static class Undo {
        final List<int[]> pos = new ArrayList<>();
        final List<org.bukkit.block.data.BlockData> before = new ArrayList<>();
        final List<org.bukkit.block.data.BlockData> placed = new ArrayList<>();
    }

    static final int UNDO_KEEP = 5; // how many pastes /undo can go back through
    final Map<UUID, java.util.ArrayDeque<Undo>> undoStacks = new HashMap<>();

    /** Copied blocks: stored as {blocks in front (0 = first row of the area), blocks to the right, layers above the clicked one}, plus the size of the copied area. */
    static class Clip {
        int y;
        BlockFace facing = BlockFace.NORTH;
        int depth, left, right, layers; // size of the copied area (the corners of the preview)
        final List<int[]> off = new ArrayList<>();
        final List<org.bukkit.block.data.BlockData> data = new ArrayList<>();
    }

    ItemStack wandItem() {
        ItemStack it = new ItemStack(Material.BLAZE_ROD);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt("&d&lCopy & Paste Wand"));
        im.setMaxStackSize(1);
        im.setEnchantmentGlintOverride(true);
        im.lore(List.of(
                txt("&7Shift + right-click: &fcopy &7the area in front of you."),
                txt("&7Right-click: &fpaste &7it (a block or the air works)."),
                txt("&7Left-click: &fsettings &7- size, layers, preview..."),
                txt("&7Glowstone corners show where it will go."),
                txt("&7Only copies and pastes where you can build.")));
        im.getPersistentDataContainer().set(KEY_WAND, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(im);
        return it;
    }

    boolean isWand(ItemStack it) {
        if (it == null || it.getType() != Material.BLAZE_ROD || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(KEY_WAND, PersistentDataType.BYTE);
    }

    /** The layer a paste/copy uses: the clicked block if it is replaceable, otherwise the block next to it on the clicked face. */
    Block wandAnchor(Block clicked, BlockFace face) {
        return clicked.isReplaceable() ? clicked : clicked.getRelative(face);
    }

    /** Layer Y the wand is aiming at (what the preview shows): the block you look at (up to 6 blocks), else your feet. */
    int wandTargetY(Player p) {
        org.bukkit.util.RayTraceResult rt = p.rayTraceBlocks(6, org.bukkit.FluidCollisionMode.NEVER);
        if (rt != null && rt.getHitBlock() != null && rt.getHitBlockFace() != null) {
            return wandAnchor(rt.getHitBlock(), rt.getHitBlockFace()).getY();
        }
        return p.getLocation().getBlockY();
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onWandUse(PlayerInteractEvent e) {
        if (!isWand(e.getItem())) return;
        Action act = e.getAction();
        if (e.getHand() == null) return;
        Player p = e.getPlayer();
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        if (act == Action.LEFT_CLICK_AIR || act == Action.LEFT_CLICK_BLOCK) {
            e.setCancelled(true);
            if (!p.getWorld().equals(world)) return;
            long now = System.currentTimeMillis();
            Long last = pouchCooldown.get(p.getUniqueId());
            if (last != null && now - last < 250) return;
            pouchCooldown.put(p.getUniqueId(), now);
            openWandSettings(p, d);
            return;
        }
        if (act != Action.RIGHT_CLICK_BLOCK && act != Action.RIGHT_CLICK_AIR) return;
        Block clicked = e.getClickedBlock();
        if (clicked != null && !p.isSneaking() && clicked.getType().isInteractable()) return; // still open chests, doors...
        if (clicked != null && e.useInteractedBlock() == org.bukkit.event.Event.Result.DENY) {
            e.setCancelled(true);
            return;
        }
        e.setCancelled(true);
        if (!p.getWorld().equals(world)) {
            msg(p, "&cThe Copy & Paste Wand only works on the cane islands.");
            return;
        }
        long now = System.currentTimeMillis();
        Long last = pouchCooldown.get(p.getUniqueId());
        if (last != null && now - last < WAND_COOLDOWN_MS) return;
        pouchCooldown.put(p.getUniqueId(), now);
        int y = clicked != null ? wandAnchor(clicked, e.getBlockFace()).getY() : wandTargetY(p);
        if (p.isSneaking()) wandCopy(p, d, y);
        else wandPaste(p, d, y);
    }

    static final BlockFace[] TURNS = {BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST}; // clockwise

    static int turnIndex(BlockFace f) {
        for (int i = 0; i < 4; i++) if (TURNS[i] == f) return i;
        return 0;
    }

    /** Turns a horizontal direction k quarter-turns clockwise (anything else is returned unchanged). */
    static BlockFace turn(BlockFace f, int k) {
        for (int i = 0; i < 4; i++) if (TURNS[i] == f) return TURNS[(i + k) % 4];
        return f;
    }

    /** A copy of the block data turned k quarter-turns clockwise, so stairs, logs etc. still line up when pasted facing another way. */
    static org.bukkit.block.data.BlockData turned(org.bukkit.block.data.BlockData in, int k) {
        org.bukkit.block.data.BlockData out = in.clone();
        if (k % 4 == 0) return out;
        if (out instanceof org.bukkit.block.data.Directional dr) {
            BlockFace nf = turn(dr.getFacing(), k);
            if (nf != dr.getFacing() && dr.getFaces().contains(nf)) dr.setFacing(nf);
        }
        if (k % 2 != 0 && out instanceof org.bukkit.block.data.Orientable ori) {
            if (ori.getAxis() == org.bukkit.Axis.X && ori.getAxes().contains(org.bukkit.Axis.Z)) ori.setAxis(org.bukkit.Axis.Z);
            else if (ori.getAxis() == org.bukkit.Axis.Z && ori.getAxes().contains(org.bukkit.Axis.X)) ori.setAxis(org.bukkit.Axis.X);
        }
        return out;
    }

    /** World x/z of the spot f blocks in front of and s blocks to the right of (px, pz) when facing dir. */
    static int[] wandSpot(int px, int pz, BlockFace dir, int f, int s) {
        int fx = dir.getModX(), fz = dir.getModZ();
        return new int[]{px + f * fx + s * (-fz), pz + f * fz + s * fx};
    }

    /** Shift + right-click: copies the area in front of you (size from your wand settings), starting at layer y. Only blocks you may build on. */
    void wandCopy(Player p, PD d, int baseY) {
        BlockFace dir = p.getFacing();
        if (dir == BlockFace.UP || dir == BlockFace.DOWN) return;
        int px = p.getLocation().getBlockX(), pz = p.getLocation().getBlockZ();
        Clip c = new Clip();
        c.y = baseY;
        c.facing = dir;
        c.depth = d.wandDepth;
        c.left = d.wandLeft;
        c.right = d.wandRight;
        c.layers = d.wandLayers;
        for (int dy = 0; dy < c.layers; dy++) {
            int y = c.y + dy;
            if (y >= world.getMaxHeight() || y < world.getMinHeight()) break;
            for (int f = 0; f < c.depth; f++) {
                for (int s = -c.left; s <= c.right; s++) {
                    int[] w = wandSpot(px, pz, dir, d.wandGap + f, s);
                    if (!world.isChunkLoaded(w[0] >> 4, w[1] >> 4)) continue;
                    Block b = world.getBlockAt(w[0], y, w[1]);
                    Material t = b.getType();
                    if (t.isAir() || t == Material.BEDROCK || isSand(t)) continue; // sand is never copied
                    if (specials.containsKey(keyOf(b)) || !canBuild(p, b.getLocation())) continue;
                    c.off.add(new int[]{f, s, dy});
                    c.data.add(b.getBlockData().clone());
                }
            }
        }
        if (c.off.isEmpty()) {
            msg(p, "&cNothing to copy in the marked area (only blocks on islands you can build on count). &7Left-click the wand to change its size.");
            return;
        }
        clipboards.put(p.getUniqueId(), c);
        msg(p, "&aCopied &e" + fmt((long) c.off.size()) + " &ablocks (&e" + (c.left + c.right + 1) + " wide&a, &e" + c.depth + " long&a, &e" + c.layers + " layer" + (c.layers == 1 ? "" : "s") + "&a, from Y &e" + c.y + "&a). &7Go where you want it and right-click to paste - the glowstone corners show where it lands.");
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.4f);
        clearWandPreview(p); // the preview switches from the copy area to the paste area on the next tick
    }

    /** Right-click: pastes the copied blocks in front of you on layer ay. Only fills empty spots in chunks you may build on. */
    void wandPaste(Player p, PD d, int ay) {
        Clip c = clipboards.get(p.getUniqueId());
        if (c == null || c.off.isEmpty()) {
            msg(p, "&cNothing copied yet. &7Shift + right-click to copy the area in front of you.");
            return;
        }
        if (ay < world.getMinHeight() || ay >= world.getMaxHeight()) return;
        int maxY = world.getMaxHeight();
        BlockFace look = p.getFacing();
        if (look == BlockFace.UP || look == BlockFace.DOWN) return;
        BlockFace dir = d.wandRotate ? look : c.facing;
        int k = d.wandRotate ? (turnIndex(dir) - turnIndex(c.facing) + 4) % 4 : 0; // quarter-turns between where it was copied and where it is pasted
        int px = p.getLocation().getBlockX(), pz = p.getLocation().getBlockZ();
        int placed = 0;
        Undo undo = new Undo();
        clearWandPreview(p); // never leave fake glowstone where real blocks are about to appear
        for (int i = 0; i < c.off.size(); i++) {
            int[] o = c.off.get(i);
            int ty = ay + o[2];
            if (ty >= maxY) continue;
            int[] w = wandSpot(px, pz, dir, d.wandGap + o[0], o[1]);
            Block t = world.getBlockAt(w[0], ty, w[1]);
            if (!canBuild(p, t.getLocation()) || specials.containsKey(keyOf(t))) continue;
            if (!(airish(t) || (t.isReplaceable() && !t.isLiquid()))) continue; // never overwrite existing blocks
            org.bukkit.block.data.BlockData nd = turned(c.data.get(i), k);
            if (isSand(nd.getMaterial())) continue; // sand is never pasted
            undo.pos.add(new int[]{t.getX(), t.getY(), t.getZ()});
            undo.before.add(t.getBlockData());
            undo.placed.add(nd);
            t.setBlockData(nd, false);
            placed++;
        }
        if (placed > 0) {
            java.util.ArrayDeque<Undo> st = undoStacks.computeIfAbsent(p.getUniqueId(), x -> new java.util.ArrayDeque<>());
            st.push(undo);
            while (st.size() > UNDO_KEEP) st.removeLast();
        }
        if (placed == 0) {
            p.sendActionBar(txt("&cNo free spots here to paste. &7Move, turn or pick another layer."));
            return;
        }
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_PLACE, 1f, 1f);
        p.sendActionBar(txt("&dPasted &f" + fmt((long) placed) + " &dblocks &7(Y " + ay + "-" + (ay + c.layers - 1) + ") - /undo to take it back"));
    }

    // ---- paste preview: glowstone on the corners of the area, shown only to the player (fake blocks, nothing is placed)
    final Map<UUID, List<Location>> wandPreviewShown = new HashMap<>();
    /** Last drawn preview state: compared field by field, no String is built. */
    static final class WandKey {
        final World world;
        final int px, pz, y, depth, left, right, layers, gap;
        final BlockFace use;
        final boolean pasting;

        WandKey(World world, int px, int pz, int y, BlockFace use, boolean pasting, int depth, int left, int right, int layers, int gap) {
            this.world = world; this.px = px; this.pz = pz; this.y = y; this.use = use; this.pasting = pasting;
            this.depth = depth; this.left = left; this.right = right; this.layers = layers; this.gap = gap;
        }

        boolean matches(World world, int px, int pz, int y, BlockFace use, boolean pasting, int depth, int left, int right, int layers, int gap) {
            return this.world == world && this.px == px && this.pz == pz && this.y == y && this.use == use && this.pasting == pasting
                    && this.depth == depth && this.left == left && this.right == right && this.layers == layers && this.gap == gap;
        }
    }

    final Map<UUID, WandKey> wandPreviewKey = new HashMap<>();

    /** Puts the real blocks back for the player and forgets the preview. */
    void clearWandPreview(Player p) {
        wandPreviewKey.remove(p.getUniqueId());
        List<Location> old = wandPreviewShown.remove(p.getUniqueId());
        if (old == null) return;
        for (Location l : old) {
            if (l.getWorld() == null || !l.getWorld().isChunkLoaded(l.getBlockX() >> 4, l.getBlockZ() >> 4)) continue;
            p.sendBlockChange(l, l.getBlock().getBlockData());
        }
    }

    /** Runs every few ticks: shows the corners of the paste area (or of the copy area when nothing is copied or you sneak) while the wand is in hand. */
    void wandPreviewTick() {
        for (Player p : getServer().getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            PD d = players.get(id);
            boolean show = d != null && d.wandPreview && p.getWorld().equals(world) && isWand(p.getInventory().getItemInMainHand());
            BlockFace dir = show ? p.getFacing() : null;
            if (!show || dir == BlockFace.UP || dir == BlockFace.DOWN) {
                if (wandPreviewShown.containsKey(id)) clearWandPreview(p);
                continue;
            }
            Clip c = clipboards.get(id);
            boolean pasting = c != null && !c.off.isEmpty() && !p.isSneaking();
            int depth, left, right, layers;
            BlockFace use = dir;
            if (pasting) {
                depth = c.depth; left = c.left; right = c.right; layers = c.layers;
                if (!d.wandRotate) use = c.facing;
            } else {
                depth = d.wandDepth; left = d.wandLeft; right = d.wandRight; layers = d.wandLayers;
            }
            int y = wandTargetY(p);
            Location pl = p.getLocation();
            int px = pl.getBlockX(), pz = pl.getBlockZ();
            WandKey prev = wandPreviewKey.get(id);
            if (prev != null && prev.matches(world, px, pz, y, use, pasting, depth, left, right, layers, d.wandGap)) continue; // nothing moved
            clearWandPreview(p);
            int top = Math.min(y + layers - 1, world.getMaxHeight() - 1);
            if (y < world.getMinHeight()) continue;
            List<Location> shown = new ArrayList<>();
            int[] fs = {d.wandGap, d.wandGap + depth - 1};
            int[] ss = {-left, right};
            int[] ys = top == y ? new int[]{y} : new int[]{y, top};
            org.bukkit.block.data.BlockData glow = Material.GLOWSTONE.createBlockData();
            for (int f : fs) {
                for (int sd : ss) {
                    int[] w = wandSpot(px, pz, use, f, sd);
                    if (!world.isChunkLoaded(w[0] >> 4, w[1] >> 4)) continue;
                    for (int yy : ys) {
                        Location l = new Location(world, w[0], yy, w[1]);
                        boolean dup = false;
                        for (Location o : shown) if (o.equals(l)) dup = true;
                        if (dup) continue;
                        shown.add(l);
                        p.sendBlockChange(l, glow);
                    }
                }
            }
            wandPreviewShown.put(id, shown);
            wandPreviewKey.put(id, new WandKey(world, px, pz, y, use, pasting, depth, left, right, layers, d.wandGap));
        }
    }

    // ---- wand settings menu
    static class WandHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    void openWandSettings(Player p, PD d) {
        WandHolder h = new WandHolder();
        Inventory inv = Bukkit.createInventory(h, 27, txt("&d&lWand Settings"));
        h.inv = inv;
        fillWandSettings(inv, d);
        p.openInventory(inv);
    }

    ItemStack wandNum(Material m, String name, int val, String unit, String... extra) {
        List<String> lore = new ArrayList<>();
        lore.add("&7Now: &e" + val + (unit.isEmpty() ? "" : " " + unit));
        lore.add(" ");
        lore.add("&aLeft-click: &f+1   &cRight-click: &f-1");
        lore.add("&aShift + left: &f+10   &cShift + right: &f-10");
        lore.add(" ");
        for (String x : extra) lore.add("&8" + x);
        return named(m, name, lore.toArray(new String[0]));
    }

    void fillWandSettings(Inventory inv, PD d) {
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        int w = d.wandLeft + d.wandRight + 1;
        inv.setItem(4, named(Material.BLAZE_ROD, "&d&lYour copy area",
                "&7" + w + " wide &8x &7" + d.wandDepth + " long &8x &7" + d.wandLayers + " high",
                "&7Up to &e" + fmt((long) w * d.wandDepth * d.wandLayers) + " &7blocks",
                " ", "&8Shift + right-click copies, right-click pastes.", Credit.LORE));
        inv.setItem(10, wandNum(Material.ARROW, "&bLength &7(forward)", d.wandDepth, "blocks", "How far in front of you.", "Max " + WAND_MAX_DEPTH + "."));
        inv.setItem(11, wandNum(Material.LEAD, "&bLeft width", d.wandLeft, "blocks", "Blocks to your left.", "Max " + WAND_MAX_SIDE + "."));
        inv.setItem(12, wandNum(Material.LEAD, "&bRight width", d.wandRight, "blocks", "Blocks to your right.", "Max " + WAND_MAX_SIDE + "."));
        inv.setItem(13, wandNum(Material.LADDER, "&bLayers &7(height)", d.wandLayers, "", "Layers copied, from the one", "you aim at upwards. Max " + WAND_MAX_LAYERS + "."));
        inv.setItem(14, wandNum(Material.STICK, "&bStart distance", d.wandGap, "blocks", "Gap between you and the area.", "Max " + WAND_MAX_GAP + "."));
        inv.setItem(15, wandToggle(Material.GLOWSTONE, "&eGlowstone preview", d.wandPreview, "Shows the corners of the area", "before you copy or paste."));
        inv.setItem(16, wandToggle(Material.COMPASS, "&eRotate with you", d.wandRotate, "ON: the paste turns to the way you face.", "OFF: always pastes the way it was copied."));
        inv.setItem(22, named(Material.BARRIER, "&cReset to defaults", "&7128 long, 31 wide, 2 layers,", "&7start 1, preview and rotate on."));
        inv.setItem(26, named(Material.RECOVERY_COMPASS, "&aUndo last paste", "&7Same as &e/undo&7."));
    }

    ItemStack wandToggle(Material m, String name, boolean on, String... info) {
        List<String> lore = new ArrayList<>();
        lore.add(on ? "&aEnabled" : "&cDisabled");
        lore.add(" ");
        for (String x : info) lore.add("&7" + x);
        lore.add(" ");
        lore.add("&eClick to toggle");
        ItemStack it = named(on ? m : Material.GRAY_DYE, name, lore.toArray(new String[0]));
        if (on) {
            ItemMeta im = it.getItemMeta();
            im.setEnchantmentGlintOverride(true);
            it.setItemMeta(im);
        }
        return it;
    }

    @EventHandler
    public void onWandSettingsClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof WandHolder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int step = (e.isLeftClick() ? 1 : e.isRightClick() ? -1 : 0) * (e.isShiftClick() ? 10 : 1);
        int slot = e.getRawSlot();
        switch (slot) {
            case 10 -> d.wandDepth = Math.max(1, Math.min(WAND_MAX_DEPTH, d.wandDepth + step));
            case 11 -> d.wandLeft = Math.max(0, Math.min(WAND_MAX_SIDE, d.wandLeft + step));
            case 12 -> d.wandRight = Math.max(0, Math.min(WAND_MAX_SIDE, d.wandRight + step));
            case 13 -> d.wandLayers = Math.max(1, Math.min(WAND_MAX_LAYERS, d.wandLayers + step));
            case 14 -> d.wandGap = Math.max(1, Math.min(WAND_MAX_GAP, d.wandGap + step));
            case 15 -> d.wandPreview = !d.wandPreview;
            case 16 -> d.wandRotate = !d.wandRotate;
            case 22 -> {
                d.wandDepth = 128; d.wandLeft = 15; d.wandRight = 15; d.wandLayers = 2; d.wandGap = 1;
                d.wandPreview = true; d.wandRotate = true;
            }
            case 26 -> {
                p.closeInventory();
                cmdUndo(p);
                return;
            }
            default -> {
                return;
            }
        }
        dirty = true;
        wandPreviewKey.remove(p.getUniqueId()); // redraw the preview with the new size
        fillWandSettings(top, d);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1f);
    }

    /** /undo - takes back your latest Copy & Paste Wand paste (up to the last 5, newest first). Blocks you changed since are left alone. */
    void cmdUndo(Player p) {
        java.util.ArrayDeque<Undo> st = undoStacks.get(p.getUniqueId());
        if (st == null || st.isEmpty()) {
            msg(p, "&cNothing to undo. &7Only pastes from the Copy & Paste Wand can be undone.");
            return;
        }
        Undo u = st.pop();
        int restored = 0;
        for (int i = 0; i < u.pos.size(); i++) {
            int[] c = u.pos.get(i);
            Block b = world.getBlockAt(c[0], c[1], c[2]);
            if (!canBuild(p, b.getLocation())) continue;
            if (!b.getBlockData().equals(u.placed.get(i))) continue; // changed since the paste - don't touch it
            b.setBlockData(u.before.get(i), false);
            restored++;
        }
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_BREAK, 1f, 0.9f);
        msg(p, "&aUndid your last paste &7(" + fmt((long) restored) + " blocks restored" + (st.isEmpty() ? "" : ", " + st.size() + " more paste" + (st.size() == 1 ? "" : "s") + " can be undone") + ").");
    }

    // ------------------------------------------------------------------ line breaker
    ItemStack lineBreaker() {
        ItemStack it = new ItemStack(Material.NETHERITE_PICKAXE);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt("&c&lLine Breaker"));
        im.setUnbreakable(true); // never loses durability, never breaks
        im.addEnchant(Enchantment.EFFICIENCY, 5, true);
        im.setEnchantmentGlintOverride(true);
        im.lore(List.of(
                txt("&7Right-click a block to break a line of"),
                txt("&7blocks the way you face, until the island edge."),
                txt("&7Never breaks. Only works on islands you can build on.")));
        im.getPersistentDataContainer().set(KEY_BREAKER, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(im);
        return it;
    }

    boolean isBreaker(ItemStack it) {
        if (it == null || it.getType() != Material.NETHERITE_PICKAXE || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(KEY_BREAKER, PersistentDataType.BYTE);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreakerUse(PlayerInteractEvent e) {
        ItemStack item = e.getItem();
        if (!isBreaker(item)) return;
        Action act = e.getAction();
        if (act != Action.RIGHT_CLICK_BLOCK && act != Action.RIGHT_CLICK_AIR) return;
        Player p = e.getPlayer();
        EquipmentSlot hand = e.getHand();
        Block clicked = e.getClickedBlock();
        if (hand == null || clicked == null) return;
        if (!p.isSneaking() && clicked.getType().isInteractable()) return; // still open chests, doors... (sneak to break them)
        e.setCancelled(true);
        if (!p.getWorld().equals(world)) {
            msg(p, "&cThe Line Breaker only works on the cane islands.");
            return;
        }
        breakerUse(p, hand, clicked);
    }

    /** Breaks the clicked block and every block after it in the facing direction, stopping at the edge of what the player may build on. */
    void breakerUse(Player p, EquipmentSlot hand, Block clicked) {
        long now = System.currentTimeMillis();
        Long last = pouchCooldown.get(p.getUniqueId());
        if (last != null && now - last < POUCH_COOLDOWN_MS) return;
        pouchCooldown.put(p.getUniqueId(), now);
        ItemStack tool = p.getInventory().getItem(hand);
        if (!isBreaker(tool)) return;
        BlockFace dir = p.getFacing();
        if (dir == BlockFace.UP || dir == BlockFace.DOWN) return;
        int broken = 0, steps = 0;
        Block cur = clicked;
        while (steps < POUCH_MAX_LINE) {
            if (!isBreaker(p.getInventory().getItem(hand))) break;
            if (cur.getY() < world.getMinHeight() || cur.getY() >= world.getMaxHeight()) break;
            if (!canBuild(p, cur.getLocation())) {
                if (steps == 0) deny(p);
                break;
            }
            Material t = cur.getType();
            if (!t.isAir() && !cur.isLiquid() && t != Material.BEDROCK) {
                BlockBreakEvent ev = new BlockBreakEvent(cur, p);
                getServer().getPluginManager().callEvent(ev); // our own onBreak (specials, bonus cane) + other plugins
                if (!ev.isCancelled()) {
                    if (ev.isDropItems()) {
                        cur.breakNaturally(tool);
                    } else {
                        if (cur.getState() instanceof Container c) {
                            for (ItemStack in : c.getInventory().getContents())
                                if (in != null && !in.getType().isAir()) world.dropItemNaturally(cur.getLocation().add(0.5, 0.5, 0.5), in);
                            c.getInventory().clear();
                        }
                        cur.setType(Material.AIR, true);
                    }
                    broken++;
                }
            }
            steps++;
            cur = cur.getRelative(dir);
        }
        if (broken == 0) return;
        p.playSound(p.getLocation(), Sound.BLOCK_STONE_BREAK, 1f, 1f);
        p.sendActionBar(txt("&cBroke &f" + broken + " &cblock(s) &7- tool never wears out"));
    }

    // ------------------------------------------------------------------ /removesponge
    final Set<UUID> spongeJobs = new HashSet<>();

    /** Removes every sponge (dry and wet) on the player's own island (only chunks they own), one chunk per tick. */
    void cmdRemoveSponge(Player p, PD d) {
        final UUID pid = p.getUniqueId();
        if (!spongeJobs.add(pid)) {
            msg(p, "&cAlready removing sponges - give it a moment.");
            return;
        }
        final List<int[]> chunks = chunksOf(d);
        final UUID ownerId = d.id;
        final int[] idx = {0};
        final int[] removed = {0};
        msg(p, "&eRemoving all sponges (wet and dry) from your island...");
        getServer().getScheduler().runTaskTimer(this, task -> {
            try {
                if (idx[0] >= chunks.size()) {
                    task.cancel();
                    spongeJobs.remove(pid);
                    Player on = Bukkit.getPlayer(pid);
                    if (on != null) msg(on, removed[0] == 0 ? "&7No sponges found on your island." : "&aRemoved &e" + fmt((long) removed[0]) + " &asponge(s).");
                    return;
                }
                int[] c = chunks.get(idx[0]++);
                // only ever touch chunks that really belong to this player
                if (!ownerId.equals(chunkOwners.get(chunkKey(c[0], c[1])))) return;
                ChunkSnapshot snap = world.getChunkAt(c[0], c[1]).getChunkSnapshot(false, false, false);
                int minY = world.getMinHeight(), maxY = world.getMaxHeight();
                for (int y = minY; y < maxY; y++) {
                    for (int lx = 0; lx < 16; lx++) {
                        for (int lz = 0; lz < 16; lz++) {
                            Material t = snap.getBlockType(lx, y, lz);
                            if (t != Material.SPONGE && t != Material.WET_SPONGE) continue;
                            world.getBlockAt(c[0] * 16 + lx, y, c[1] * 16 + lz).setType(Material.AIR, false);
                            removed[0]++;
                        }
                    }
                }
            } catch (Throwable ex) {
                task.cancel();
                spongeJobs.remove(pid);
                getLogger().warning("/removesponge failed: " + ex);
            }
        }, 1L, 1L);
    }

    boolean isInf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(KEY_INF, PersistentDataType.BYTE);
    }

    String specialOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(KEY_SPECIAL, PersistentDataType.STRING);
    }

    // ------------------------------------------------------------------ shop definition
    void add(String id, Material icon, String name, double price, int max, boolean glow, String[] desc, BiPredicate<Player, PD> apply) {
        shop.add(new ShopItem(id, icon, name, price, max, desc, glow, apply));
    }

    void inf(String id, Material m, double price) {
        add(id, m, "&b\u221E Infinite " + nice(m), price, 0, true, new String[]{"&7Place it forever - it never runs out!"}, (p, d) -> {
            give(p, infinite(m));
            return true;
        });
    }

    void pack(String id, Material m, int amt, double price) {
        add(id, m, "&e" + amt + "x " + nice(m), price, 0, false, new String[]{"&7A handy stack for your island."}, (p, d) -> {
            give(p, new ItemStack(m, amt));
            return true;
        });
    }

    void perk(String id, Material icon, String name, double price, int max, String... desc) {
        add(id, icon, name, price, max, false, desc, (p, d) -> true);
    }

    void effect(String id, Material icon, String name, double price, int max, PotionEffectType t, String... desc) {
        perk(id, icon, name, price, max, desc);
        effects.put(id, t);
    }

    void buildShop() {
        // requested items
        inf("inf_dirt", Material.DIRT, 20);
        inf("inf_glass", Material.GLASS, 20);
        add("sellcollector", Material.BEACON, "&6Cane Core", 125, 0, true,
                new String[]{"&7Counts every cane plant on your island and", "&7automatically pays you what it would grow,", "&7with all your multipliers. No breaking needed."},
                (p, d) -> {
                    give(p, specialItem("sellcollector"));
                    return true;
                });
        add("chunkhopper", Material.HOPPER, "&6Chunk Hopper", 100, 0, true,
                new String[]{"&7Collects every dropped item in its chunk", "&7into the chest it points at."},
                (p, d) -> {
                    give(p, specialItem("chunkhopper"));
                    return true;
                });
        add("chunk", Material.GRASS_BLOCK, "&aNew Chunk", 2500, ORDER.size(), true,
                new String[]{"&7Expands your island by one more chunk.", "&7Max " + ORDER.size() + " extra chunks."},
                (p, d) -> {
                    if (!addChunk(d)) {
                        msg(p, "&cYou already own every chunk!");
                        return false;
                    }
                    msg(p, "&aA new chunk was added around your island!");
                    return true;
                });
        add("flight", Material.FEATHER, "&bFlight", 1000, 1, true,
                new String[]{"&7Fly forever!", "&eUse /isfly after buying this to be able to fly"},
                (p, d) -> {
                    d.flyOwned = true;
                    return true;
                });
        add("autoday", Material.REPEATER, "&dAuto Day", 500, 1, true,
                new String[]{"&7Unlocks &e/autocaneday&7.", "&7Automatically start the next day as soon", "&7as your quota is submitted. Toggle it on/off."},
                (p, d) -> {
                    msg(p, "&aAuto Day unlocked! Use &e/autocaneday &ato turn it on or off.");
                    return true;
                });
        add("daytoggle", Material.DAYLIGHT_DETECTOR, "&eDay / Night Control", 500, 1, true,
                new String[]{"&7Unlocks &e/daytoggle&7.", "&7Make your island permanently day or night.", "&7Only you see it - nobody else is affected."},
                (p, d) -> {
                    msg(p, "&aDay/Night Control unlocked! Use &e/daytoggle &ato switch (&e/daytoggle reset &ato go back to normal).");
                    return true;
                });

        // more infinite blocks
        inf("inf_coarse", Material.COARSE_DIRT, 20);
        inf("inf_podzol", Material.PODZOL, 25);
        inf("inf_grass", Material.GRASS_BLOCK, 25);
        inf("inf_stonebricks", Material.STONE_BRICKS, 20);
        inf("inf_pane", Material.GLASS_PANE, 15);
        inf("inf_torch", Material.TORCH, 15);
        inf("inf_ladder", Material.LADDER, 15);
        inf("inf_scaffold", Material.SCAFFOLDING, 15);
        inf("inf_barrel", Material.BARREL, 25);
        add("dirtpouch", Material.LEATHER, "&6Dirt Pouch", 150, 0, true,
                new String[]{"&7Never runs out - unlimited dirt!", "&7Right-click: place a line of dirt in the direction you face.", "&7Only works on your island (or ones that trust you)."},
                (p, d) -> {
                    give(p, pouchItem(Material.DIRT, 0));
                    return true;
                });
        add("canepouch", Material.RABBIT_HIDE, "&6Cane Pouch", 150, 0, true,
                new String[]{"&7Never runs out - unlimited sugar cane!", "&7Right-click: plant a line of cane in the direction you face", "&7(skips spots where cane can't grow).", "&7Only works on your island (or ones that trust you)."},
                (p, d) -> {
                    give(p, pouchItem(Material.SUGAR_CANE, 0));
                    return true;
                });
        add("waterpouch", Material.NAUTILUS_SHELL, "&b\u221E Water Pouch", 150, 0, true,
                new String[]{"&7Never runs out of water!", "&7Right-click: place a line of water in the direction you face.", "&7Waterlogs leaves, slabs, stairs, grates etc.", "&7Pair it with an Infinite Sponge to clean up.", "&7Only works on your island (or ones that trust you)."},
                (p, d) -> {
                    give(p, waterPouchItem());
                    return true;
                });
        inf("inf_sponge", Material.SPONGE, 25);
        for (Material pm : new Material[]{Material.OAK_LEAVES, Material.SEA_LANTERN, Material.OCHRE_FROGLIGHT, Material.VERDANT_FROGLIGHT, Material.PEARLESCENT_FROGLIGHT, Material.SPONGE}) {
            final PouchType pt = pouchByStore.get(pm);
            add("pouch_" + pm.name().toLowerCase(Locale.ROOT), pt.item, "&6" + pt.name, 150, 0, true,
                    new String[]{"&7Never runs out - unlimited " + pt.what + "!", "&7Right-click: place a line of " + pt.what + " in the direction you face.", "&7Only works on your island (or ones that trust you)."},
                    (p, d) -> {
                        give(p, pouchItem(pt.store, 0));
                        return true;
                    });
        }
        inf("inf_coppergrate", Material.COPPER_GRATE, 25);
        add("gratepouch", Material.COPPER_INGOT, "&6Copper Grate Pouch", 150, 0, true,
                new String[]{"&7Never runs out - unlimited copper grates!", "&7Right-click: place a line of grates in the direction you face.", "&7Only works on your island (or ones that trust you)."},
                (p, d) -> {
                    give(p, pouchItem(Material.COPPER_GRATE, 0));
                    return true;
                });
        pack("p_dirt", Material.DIRT, 64, 10);
        add("inf_water", Material.WATER_BUCKET, "&b\u221E Infinite Water Bucket", 60, 0, true,
                new String[]{"&7A water bucket that never empties."}, (p, d) -> {
                    give(p, infinite(Material.WATER_BUCKET));
                    return true;
                });

        // growth / economy perks
        perk("growth", Material.BONE_MEAL, "&aGrowth Boost", 50, GROWTH_MAX,
                "&7Your sugar cane grows faster (max 2 blocks).", "&7Also speeds up your Auto Sell income. Max " + GROWTH_MAX + " levels.");
        perk("doubledrop", Material.GOLDEN_HOE, "&6Bonus Drops", 150, 50,
                "&7+20% extra cane per level when you hand-break", "&7cane AND on everything Auto Sell earns.");
        perk("coinboost", Material.GOLD_INGOT, "&eCoin Boost", 250, 50,
                "&7+10% coins from every submit per level", "&7(Auto Sell included).");
        perk("timeext", Material.CLOCK, "&bExtra Time", 200, 6,
                "&7+5 minutes on your daily timer per level.");

        // potion perks
        effect("speed", Material.SUGAR, "&bSpeed", 40, 3, PotionEffectType.SPEED, "&7Permanent Speed. Each level is stronger.");
        effect("jump", Material.RABBIT_FOOT, "&aJump Boost", 40, 3, PotionEffectType.JUMP_BOOST, "&7Permanent Jump Boost.");
        effect("nightvision", Material.GOLDEN_CARROT, "&9Night Vision", 60, 1, PotionEffectType.NIGHT_VISION, "&7See clearly all night.");
        effect("waterbreath", Material.HEART_OF_THE_SEA, "&3Water Breathing", 60, 1, PotionEffectType.WATER_BREATHING, "&7Breathe underwater.");
        effect("saturation", Material.COOKED_BEEF, "&6Never Hungry", 120, 1, PotionEffectType.SATURATION, "&7Your hunger bar stays full.");
        effect("regen", Material.GHAST_TEAR, "&cRegeneration", 150, 2, PotionEffectType.REGENERATION, "&7Heal over time.");
        effect("resist", Material.IRON_CHESTPLATE, "&7Resistance", 200, 2, PotionEffectType.RESISTANCE, "&7Take less damage.");
        effect("slowfall", Material.FEATHER, "&fSlow Falling", 80, 1, PotionEffectType.SLOW_FALLING, "&7Float gently down.");

        // late game
        add("midas", Material.GOLDEN_APPLE, "&6&lMidas Touch", MIDAS_PRICE, 1, true,
                new String[]{"&7The ultimate upgrade. Everything you farm turns to gold.", " ",
                        "&6+50% coins &7from every submit and all Auto Sell income.",
                        "&6+100% Bonus Drops chance &7(like 5 extra levels).", " ",
                        "&cRequires &e" + MIDAS_REBIRTHS + " rebirths&c. One time purchase."},
                (p, d) -> {
                    if (d.rebirths < MIDAS_REBIRTHS) {
                        msg(p, "&cMidas Touch needs &e" + MIDAS_REBIRTHS + " rebirths &c(you have &e" + d.rebirths + "&c). Keep going!");
                        snd(p, d, Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                        return false;
                    }
                    p.getWorld().strikeLightningEffect(p.getLocation());
                    Bukkit.broadcast(txt("&6&lMIDAS! &e" + p.getName() + " &fbought the &6Midas Touch&f!"));
                    return true;
                });
        effect("fireres", Material.MAGMA_CREAM, "&6Fire Resistance", 80, 1, PotionEffectType.FIRE_RESISTANCE, "&7Immune to fire and lava.");
        effect("health", Material.GLISTERING_MELON_SLICE, "&dHealth Boost", 200, 5, PotionEffectType.HEALTH_BOOST, "&7More hearts per level.");

        // packs
        add("caneseeds", Material.SUGAR_CANE, "&e16x Sugar Cane", 10, 0, false, new String[]{"&7Extra cane to plant."}, (p, d) -> {
            give(p, new ItemStack(Material.SUGAR_CANE, 16));
            return true;
        });
        pack("p_bucket", Material.BUCKET, 1, 20);
        pack("p_water", Material.WATER_BUCKET, 1, 30);
        pack("p_composter", Material.COMPOSTER, 4, 20);
        pack("p_bed", Material.RED_BED, 1, 40);
        pack("p_sign", Material.OAK_SIGN, 16, 15);
        pack("p_cake", Material.CAKE, 1, 30);
        pack("p_beef", Material.COOKED_BEEF, 64, 30);
        pack("p_carrot", Material.GOLDEN_CARROT, 32, 40);
        pack("p_rocket", Material.FIREWORK_ROCKET, 64, 25);
        pack("p_lantern", Material.LANTERN, 16, 20);
        pack("p_sealantern", Material.SEA_LANTERN, 32, 40);
        pack("p_glowstone", Material.GLOWSTONE, 32, 30);
        pack("p_quartz", Material.QUARTZ_BLOCK, 64, 40);
        pack("p_bricks", Material.BRICKS, 64, 30);
        pack("p_oak", Material.OAK_PLANKS, 64, 20);
        pack("p_cherry", Material.CHERRY_PLANKS, 64, 25);
        pack("p_shulker", Material.SHULKER_BOX, 1, 150);
        pack("p_enderchest", Material.ENDER_CHEST, 1, 120);
        pack("p_nametag", Material.NAME_TAG, 1, 30);
        pack("p_totem", Material.TOTEM_OF_UNDYING, 1, 400);
        pack("p_elytra", Material.ELYTRA, 1, 500);

        // tools
        add("linebreaker", Material.NETHERITE_PICKAXE, "&c&lLine Breaker", 25, 0, true,
                new String[]{"&7Never breaks. Right-click a block to break a line.", "&7Handy if you lost yours."}, (p, d) -> {
                    give(p, lineBreaker());
                    return true;
                });
        add("copywand", Material.BLAZE_ROD, "&d&lCopy & Paste Wand", 100000, 0, true,
                new String[]{"&7Shift + right-click: copy the area in front of you.", "&7Right-click: paste it. Glowstone corners preview it.", "&7Left-click: customise size, preview and more.", "&7Only copies/pastes where you can build."}, (p, d) -> {
                    give(p, wandItem());
                    return true;
                });
        add("t_axe", Material.NETHERITE_AXE, "&5Cane Axe", 300, 0, true,
                new String[]{"&7Netherite axe, Efficiency V, Unbreaking III."}, (p, d) -> {
                    ItemStack it = new ItemStack(Material.NETHERITE_AXE);
                    it.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                    it.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                    give(p, it);
                    return true;
                });
        add("t_pick", Material.DIAMOND_PICKAXE, "&bCane Pickaxe", 200, 0, true,
                new String[]{"&7Diamond pickaxe, Efficiency V, Unbreaking III."}, (p, d) -> {
                    ItemStack it = new ItemStack(Material.DIAMOND_PICKAXE);
                    it.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                    it.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                    give(p, it);
                    return true;
                });
        add("t_shovel", Material.DIAMOND_SHOVEL, "&bCane Shovel", 150, 0, true,
                new String[]{"&7Diamond shovel, Efficiency V, Unbreaking III."}, (p, d) -> {
                    ItemStack it = new ItemStack(Material.DIAMOND_SHOVEL);
                    it.addUnsafeEnchantment(Enchantment.EFFICIENCY, 5);
                    it.addUnsafeEnchantment(Enchantment.UNBREAKING, 3);
                    give(p, it);
                    return true;
                });
    }

    double priceOf(PD d, ShopItem s) {
        int steps = Math.max(0, d.lvl(s.id) - d.priceBase.getOrDefault(s.id, 0));
        return Math.min(s.price * Math.pow(priceMult, steps), 1.0e15);
    }

    ItemStack iconFor(PD d, ShopItem s) {
        int n = d.lvl(s.id);
        ItemStack it = new ItemStack(s.icon);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(s.name));
        List<Component> lore = new ArrayList<>();
        for (String line : s.desc) lore.add(txt(line.startsWith("&") ? line : "&7" + line));
        lore.add(txt(" "));
        final boolean fxOwned = effects.containsKey(s.id) && n > 0;
        if (fxOwned) {
            lore.add(txt(d.on("fx_" + s.id) ? "&aEffect: Enabled" : "&cEffect: Disabled"));
            lore.add(txt("&eClick to turn it on / off"));
            lore.add(txt(" "));
        }
        if (s.max > 0 && n >= s.max) {
            lore.add(txt("&c&lSOLD OUT &7(" + n + "/" + s.max + ")"));
        } else {
            double price = priceOf(d, s);
            lore.add(txt("&6Price: &f" + fmt(price) + " coins"));
            lore.add(txt(s.max > 0 ? "&7Owned: " + n + "/" + s.max : "&7Bought: " + n));
            lore.add(txt("&8Price doubles every time you buy."));
            if (fxOwned) lore.add(txt(d.coins + 1e-9 >= price ? "&aRight-click to buy the next level!" : "&cNot enough coins"));
            else lore.add(txt(d.coins + 1e-9 >= price ? "&aClick to buy!" : "&cNot enough coins"));
        }
        if (s.glow) im.setEnchantmentGlintOverride(true);
        im.lore(lore);
        it.setItemMeta(im);
        return it;
    }

    void fillShop(Inventory inv, PD d, int page) {
        inv.clear();
        int pages = (shop.size() + 44) / 45;
        for (int i = 0; i < 45; i++) {
            int idx = page * 45 + i;
            if (idx >= shop.size()) break;
            inv.setItem(i, iconFor(d, shop.get(idx)));
        }
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, filler);
        if (page > 0) inv.setItem(45, named(Material.ARROW, "&ePrevious page"));
        if (page < pages - 1) inv.setItem(53, named(Material.ARROW, "&eNext page"));
        inv.setItem(49, named(Material.GOLD_INGOT, "&6Your coins: &f" + fmt(d.coins),
                "&7Earn 0.5 coins for every cane you submit.", "&7Page " + (page + 1) + "/" + pages));
        // quick-access bar
        inv.setItem(46, named(Material.AMETHYST_SHARD, "&6Token Shop", "&7You have &6" + d.tokens + " tokens", "&aClick to open /tokenshop"));
        inv.setItem(47, named(Material.NAME_TAG, "&eTags", "&7Equip or unequip your chat tags.", "&aClick to open /tags"));
        inv.setItem(48, named(Material.FIREWORK_STAR, "&dCosmetics", "&7Name colors and sell effects.", "&aClick to open /cosmetic"));
        inv.setItem(50, named(Material.CLOCK, "&bPlaytime Rewards", "&7Your playtime: &f" + fmtPlay(d.playMs), "&aClick to open /playtimerewards"));
        inv.setItem(51, named(Material.KNOWLEDGE_BOOK, "&aCommands", "&7Every command and what it does.", "&aClick to open /commands"));
    }

    void openShop(Player p, PD d, int page) {
        int pages = (shop.size() + 44) / 45;
        page = Math.max(0, Math.min(page, pages - 1));
        ShopHolder h = new ShopHolder(page);
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lCane Shop"));
        h.inv = inv;
        fillShop(inv, d, page);
        p.openInventory(inv);
    }

    void buy(Player p, PD d, ShopItem s) {
        int n = d.lvl(s.id);
        if (s.max > 0 && n >= s.max) {
            msg(p, "&cYou already have the maximum of this item!");
            return;
        }
        double price = priceOf(d, s);
        if (d.coins + 1e-9 < price) {
            msg(p, "&cYou need &e" + fmt(price) + " &ccoins (you have &e" + fmt(d.coins) + "&c).");
            snd(p, d, Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        if (!s.apply.test(p, d)) return;
        d.coins -= price;
        d.bought.merge(s.id, 1, Integer::sum);
        if (effects.containsKey(s.id)) d.off.remove("fx_" + s.id); // a new level switches the effect back on
        dirty = true;
        applyEffects(p, d);
        if (notif(d, "purchasemsg")) msg(p, "&aBought &f" + s.name.replaceAll("&[0-9a-fk-or]", "") + " &afor &e" + fmt(price) + " &acoins. Next price: &e" + fmt(priceOf(d, s)));
        snd(p, d, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }

    @EventHandler
    public void onShopClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof ShopHolder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int slot = e.getRawSlot();
        final String bar = switch (slot) {
            case 46 -> "tokenshop";
            case 47 -> "tags";
            case 48 -> "cosmetic";
            case 50 -> "playtimerewards";
            case 51 -> "commands";
            default -> null;
        };
        if (bar != null) {
            getServer().getScheduler().runTask(this, () -> {
                p.closeInventory();
                p.performCommand(bar);
            });
            return;
        }
        if (slot == 45 && h.page > 0) {
            int np = h.page - 1;
            getServer().getScheduler().runTask(this, () -> openShop(p, d, np));
        } else if (slot == 53 && h.page < (shop.size() + 44) / 45 - 1) {
            int np = h.page + 1;
            getServer().getScheduler().runTask(this, () -> openShop(p, d, np));
        } else if (slot >= 0 && slot < 45) {
            int idx = h.page * 45 + slot;
            if (idx < shop.size()) {
                ShopItem si = shop.get(idx);
                // owned potion effect: plain click toggles it, right-click buys the next level
                if (effects.containsKey(si.id) && d.lvl(si.id) > 0 && !e.isRightClick()) toggleEffect(p, d, si);
                else buy(p, d, si);
                fillShop(top, d, h.page);
            }
        }
    }

    @EventHandler
    public void onShopDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder(false) instanceof ShopHolder || top.getHolder(false) instanceof OptionsHolder
                || top.getHolder(false) instanceof CommandsHolder
                || top.getHolder(false) instanceof ChunksHolder || top.getHolder(false) instanceof TokenHolder
                || top.getHolder(false) instanceof EquipHolder || top.getHolder(false) instanceof PlayHolder) e.setCancelled(true);
    }


    // ------------------------------------------------------------------ sand removal
    boolean sandPurged; // the full sweep over every island has finished once (the chunk-load guard keeps it clean after that)

    /** One-time jobs that must survive a restart leave an empty marker file in the plugin folder (no data.yml format change). */
    private boolean migrationDone(String id) {
        return new File(getDataFolder(), "migrated-" + id + ".flag").exists();
    }

    private void markMigrationDone(String id) {
        try {
            new File(getDataFolder(), "migrated-" + id + ".flag").createNewFile();
        } catch (IOException ex) {
            getLogger().warning("Could not write migration marker " + id + ": " + ex);
        }
    }

    /** Per-player one-time jobs (inventory / ender chest clean-ups) are remembered on the player itself, so a join costs one tag lookup instead of a scan. */
    private boolean playerMigrated(Player p, String id) {
        return p.getPersistentDataContainer().has(new NamespacedKey(this, "migrated_" + id), PersistentDataType.BYTE);
    }

    private void markPlayerMigrated(Player p, String id) {
        p.getPersistentDataContainer().set(new NamespacedKey(this, "migrated_" + id), PersistentDataType.BYTE, (byte) 1);
    }

    static boolean isSand(Material m) {
        return m == Material.SAND || m == Material.RED_SAND;
    }

    /** Removes every sand / red sand block in a loaded chunk. Sand holding up sugar cane becomes dirt so farms keep working. */
    int sweepSand(org.bukkit.Chunk c) {
        final ChunkSnapshot snap = c.getChunkSnapshot(false, false, false);
        final int minY = world.getMinHeight(), maxY = world.getMaxHeight();
        final int sections = (maxY - minY) >> 4;
        // island chunks only hold blocks in one or two 16-high sections: the empty ones are never read (was 16x16x384 reads per chunk)
        final boolean[] live = new boolean[sections];
        boolean any = false;
        for (int s = 0; s < sections; s++) {
            live[s] = !snap.isSectionEmpty(s);
            any |= live[s];
        }
        if (!any) return 0;
        int removed = 0;
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                for (int s = 0; s < sections; s++) {
                    if (!live[s]) continue;
                    final int y0 = minY + (s << 4), y1 = y0 + 15;
                    for (int y = y0; y <= y1; y++) {
                        if (!isSand(snap.getBlockType(x, y, z))) continue;
                        Block b = c.getBlock(x, y, z);
                        if (!isSand(b.getType())) continue;
                        Material above = y + 1 < maxY ? snap.getBlockType(x, y + 1, z) : Material.AIR;
                        if (above == Material.SUGAR_CANE) b.setType(Material.DIRT, false);
                        else b.setType(Material.AIR, true);
                        removed++;
                    }
                }
            }
        }
        return removed;
    }

    /**
     * ONE-TIME job: sweeps every island chunk of every known player (a few per tick, so the server never lags), then leaves a marker
     * file and never runs again. This replaces the old per-chunk-load sweep, so nothing sand-related runs during normal play any more.
     */
    void startSandPurge() {
        for (Player p : getServer().getOnlinePlayers()) purgeSandItems(p); // per-player flag: free after the first time
        if (migrationDone("sand-all-islands")) {
            sandPurged = true;
            return;
        }
        final java.util.ArrayDeque<long[]> queue = new java.util.ArrayDeque<>();
        final Set<Long> seen = new HashSet<>();
        for (PD d : players.values())  // ALL players, online or not: nothing else sweeps their chunks when they load any more
            for (int[] c : fullArea(d))
                if (seen.add(chunkKey(c[0], c[1]))) queue.add(new long[]{c[0], c[1]});
        final int total = queue.size();
        final int[] removedTotal = {0};
        new BukkitRunnable() {
            int pending = 0;

            @Override
            public void run() {
                for (int i = 0; i < 3 && !queue.isEmpty(); i++) {
                    long[] c = queue.poll();
                    pending++;
                    world.getChunkAtAsync((int) c[0], (int) c[1], false).whenComplete((chunk, ex) -> {
                        Runnable work = () -> {
                            if (chunk != null) removedTotal[0] += sweepSand(chunk);
                            pending--;
                        };
                        if (Bukkit.isPrimaryThread()) work.run();
                        else getServer().getScheduler().runTask(CaneIslands.this, work);
                    });
                }
                if (queue.isEmpty() && pending <= 0) {
                    cancel();
                    sandPurged = true;
                    dirty = true;
                    markMigrationDone("sand-all-islands");
                    getLogger().info("Sand removal finished: " + removedTotal[0] + " sand block(s) removed from " + total + " chunk(s).");
                }
            }
        }.runTaskTimer(this, 20L, 1L);
    }

    /** Deletes Sand Pouches and Infinite Sand / Red Sand items from a player's inventory and ender chest (once per player). */
    void purgeSandItems(Player p) {
        if (playerMigrated(p, "sand_items")) return;
        final NamespacedKey sandPouch = new NamespacedKey(this, "pouch_sand");
        for (Inventory inv : new Inventory[]{p.getInventory(), p.getEnderChest()}) {
            for (int i = 0; i < inv.getSize(); i++) {
                ItemStack it = inv.getItem(i);
                if (it == null || !it.hasItemMeta()) continue;
                final var pdc = it.getItemMeta().getPersistentDataContainer(); // one meta copy per item (was two)
                if (pdc.has(sandPouch, PersistentDataType.INTEGER) || (isSand(it.getType()) && pdc.has(KEY_INF, PersistentDataType.BYTE)))
                    inv.setItem(i, null);
            }
        }
        markPlayerMigrated(p, "sand_items");
    }

    // ------------------------------------------------------------------ playtime + token shop
    /** Every 5 seconds: adds the real time played to every online player and hands out playtime ranks. */
    void playTick() {
        long now = System.currentTimeMillis();
        long dt = lastPlayMs == 0 ? 0 : Math.max(0L, Math.min(now - lastPlayMs, 15000L));
        lastPlayMs = now;
        if (dt <= 0) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            d.playMs += dt;
            checkRank(d, p); // a rank-up sets dirty itself
        }
        playDirty = true; // playtime alone no longer forces the 60 s save: it is saved every 5 min and after a quit
    }

    static class TItem {
        final String id, kind, name, text; // kind: tag | rank | creative; text = the chat tag shown before the name
        final Material icon;
        final int price;
        final Particle particle;

        TItem(String id, String kind, String name, Material icon, int price, String text, Particle particle) {
            this.id = id;
            this.kind = kind;
            this.name = name;
            this.icon = icon;
            this.price = price;
            this.text = text;
            this.particle = particle;
        }
    }

    static class TokenHolder implements InventoryHolder {
        final Map<Integer, TItem> items = new HashMap<>();
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static final int TS_RANK_SLOT = 49;
    static final int TS_CREATIVE_SLOT = 50;
    static final String[] COSMETIC_KINDS = {"tag", "name", "sellfx"};

    /** First slot of a kind's row in the token shop / equip menus; the row's last slot (+8) is its "remove" button. */
    static int kindBase(String kind) {
        return switch (kind) {
            case "tag" -> 9;
            case "name" -> 18;
            default -> 27;
        };
    }

    /** Which kind a "remove" button slot belongs to (null if the slot is not one). */
    static String offKind(int slot) {
        for (String k : COSMETIC_KINDS) if (slot == kindBase(k) + 8) return k;
        return null;
    }

    String activeOf(PD d, String kind) {
        return switch (kind) {
            case "tag" -> d.activeTag;
            case "name" -> d.activeName;
            case "sellfx" -> d.activeSellFx;
            default -> "";
        };
    }

    void setActive(PD d, String kind, String id) {
        switch (kind) {
            case "tag" -> d.activeTag = id;
            case "name" -> d.activeName = id;
            case "sellfx" -> d.activeSellFx = id;
            default -> {
            }
        }
    }

    static String offLabel(String kind) {
        return switch (kind) {
            case "tag" -> "tag";
            case "name" -> "name color";
            default -> "sell effect";
        };
    }

    ItemStack offIcon(String kind) {
        return named(Material.BARRIER, "&cRemove " + offLabel(kind), "&7Click to take your " + offLabel(kind) + " off.");
    }

    void removeActive(Player p, PD d, String kind) {
        setActive(d, kind, "");
        dirty = true;
        msg(p, "&7Your " + offLabel(kind) + " was taken off.");
        refreshTab(p);
    }

    /** Chat/tab name with the equipped name color ("&f" white if none). Rainbow cycles a color per letter. */
    String nameStyled(PD d, String name) {
        String clean = name.replace("&", "");
        TItem t = d == null ? null : tokenById.get(d.activeName);
        if (t == null || !t.kind.equals("name")) return "&f" + clean;
        if (t.text.equals("rainbow")) {
            String[] c = {"&c", "&6", "&e", "&a", "&b", "&9", "&d"};
            StringBuilder sb = new StringBuilder();
            int i = 0;
            for (char ch : clean.toCharArray()) sb.append(c[i++ % c.length]).append(ch);
            return sb.toString();
        }
        return t.text + clean;
    }

    void regToken(TItem t) {
        tokenItems.add(t);
        tokenById.put(t.id, t);
    }

    void buildTokenShop() {
        // chat + tab tags
        regToken(new TItem("tag_sprout", "tag", "&aSprout Tag", Material.NAME_TAG, 10, "&8[&aSprout&8] ", null));
        regToken(new TItem("tag_sweet", "tag", "&eSweet Tooth Tag", Material.NAME_TAG, 15, "&8[&eSweet Tooth&8] ", null));
        regToken(new TItem("tag_rush", "tag", "&6Sugar Rush Tag", Material.NAME_TAG, 25, "&8[&6Sugar Rush&8] ", null));
        regToken(new TItem("tag_grinder", "tag", "&bCane Grinder Tag", Material.NAME_TAG, 30, "&8[&bCane Grinder&8] ", null));
        regToken(new TItem("tag_crusher", "tag", "&cCane Crusher Tag", Material.NAME_TAG, 40, "&8[&cCane Crusher&8] ", null));
        regToken(new TItem("tag_heart", "tag", "&dSweetheart Tag", Material.NAME_TAG, 40, "&8[&d\u2665 Sweetheart&8] ", null));
        regToken(new TItem("tag_king", "tag", "&6&lCane King Tag", Material.NAME_TAG, 60, "&8[&6&l\u265A Cane King&8] ", null));
        regToken(new TItem("tag_legend", "tag", "&f&lLegendary Tag", Material.NAME_TAG, 80, "&8[&f&l\u2726 Legendary&8] ", null));
        // name colors (the color of your name in chat + tab)
        regToken(new TItem("name_gold", "name", "&6Gold Name", Material.ORANGE_DYE, 15, "&6", null));
        regToken(new TItem("name_aqua", "name", "&bAqua Name", Material.CYAN_DYE, 15, "&b", null));
        regToken(new TItem("name_green", "name", "&aGreen Name", Material.LIME_DYE, 15, "&a", null));
        regToken(new TItem("name_pink", "name", "&dPink Name", Material.PINK_DYE, 15, "&d", null));
        regToken(new TItem("name_red", "name", "&cRed Name", Material.RED_DYE, 15, "&c", null));
        regToken(new TItem("name_rainbow", "name", "&c&lR&6&la&e&li&a&ln&b&lb&9&lo&d&lw &f&lName", Material.FIREWORK_STAR, 50, "rainbow", null));
        // sell effects (particles around you every time you /sell)
        regToken(new TItem("sellfx_coins", "sellfx", "&6Coin Burst", Material.GOLD_INGOT, 15, "", Particle.HAPPY_VILLAGER));
        regToken(new TItem("sellfx_hearts", "sellfx", "&dHeart Burst", Material.PINK_DYE, 20, "", Particle.HEART));
        regToken(new TItem("sellfx_notes", "sellfx", "&bMusic Burst", Material.NOTE_BLOCK, 25, "", Particle.NOTE));
        regToken(new TItem("sellfx_firework", "sellfx", "&eFirework Burst", Material.FIREWORK_ROCKET, 35, "", Particle.FIREWORK));
        regToken(new TItem("sellfx_totem", "sellfx", "&aTotem Burst", Material.TOTEM_OF_UNDYING, 45, "", Particle.TOTEM_OF_UNDYING));
        // rank
        // creative mode (one-time unlock, toggle with a click)
        regToken(new TItem("creative_mod", "creative", "&b&lCreative Mod", Material.DIAMOND_BLOCK, 500_000_000, "", null));
        regToken(new TItem("rank_femboy", "rank", "&d&l\u2665 Femboy Rank", Material.PINK_BANNER, 150, FEMBOY_PREFIX, null));
    }

    /** The chat/tab tag the player has equipped ("" if none). */
    String tagText(PD d) {
        if (d.activeTag.isEmpty()) return "";
        TItem t = tokenById.get(d.activeTag);
        return t == null ? "" : t.text;
    }

    /** Re-applies (or removes) the Femboy LuckPerms group to match what the player owns / wears. */
    void syncFemboy(PD d) {
        if (!lpAvailable() || !d.owned.contains("rank_femboy")) return;
        Runnable after = () -> getServer().getScheduler().runTask(this, () -> {
            Player on = Bukkit.getPlayer(d.id);
            if (on != null) refreshTab(on);
        });
        try {
            if (d.on("femboy")) LuckPermsHook.grant(d.id, List.of(), FEMBOY_GROUP, FEMBOY_PREFIX, 1000, getLogger()).thenRun(after);
            else LuckPermsHook.drop(d.id, FEMBOY_GROUP, getLogger()).thenRun(after);
        } catch (Throwable ex) {
            getLogger().warning("Could not update the Femboy rank for " + d.name + ": " + ex);
        }
    }

    void openTokenShop(Player p, PD d) {
        TokenHolder h = new TokenHolder();
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lToken Shop"));
        h.inv = inv;
        fillTokenShop(inv, d, h);
        p.openInventory(inv);
    }

    void fillTokenShop(Inventory inv, PD d, TokenHolder h) {
        h.items.clear();
        ItemStack glass = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);
        inv.setItem(4, named(Material.GOLD_NUGGET, "&6&lYour Tokens: &e" + d.tokens,
                "&7Earn &61 token &7for every new day", "&7you pass from Day 35 on, and", "&7for every 1000 rebirths.",
                "&8Click an item to buy it, click again to confirm.", "&8Click something you own to equip / unequip it."));
        Map<String, Integer> used = new HashMap<>();
        for (TItem t : tokenItems) {
            int n = used.merge(t.kind, 1, Integer::sum) - 1;
            int slot = t.kind.equals("rank") ? TS_RANK_SLOT : t.kind.equals("creative") ? TS_CREATIVE_SLOT : kindBase(t.kind) + n;
            inv.setItem(slot, tokenIcon(d, t));
            h.items.put(slot, t);
        }
        for (String k : COSMETIC_KINDS) inv.setItem(kindBase(k) + 8, offIcon(k));
        inv.setItem(45, named(Material.NAME_TAG, "&eEquip menus", "&7Already bought something? Equip it with", "&e/tags &7and &e/cosmetic&7."));
    }

    ItemStack tokenIcon(PD d, TItem t) {
        return tokenIcon(d, t, true);
    }

    /** shop = true: unowned items show "click to buy"; false (the /tags and /cosmetic menus): they show as locked. */
    ItemStack tokenIcon(PD d, TItem t, boolean shop) {
        boolean owned = d.owned.contains(t.id);
        boolean eq = t.kind.equals("rank") ? owned && d.on("femboy") : t.kind.equals("creative") ? owned && creativeOn(d) : t.id.equals(activeOf(d, t.kind));
        ItemStack it = new ItemStack(t.icon);
        ItemMeta im = it.getItemMeta();
        im.displayName(txt(t.name));
        List<Component> lore = new ArrayList<>();
        switch (t.kind) {
            case "tag" -> {
                lore.add(txt("&8Chat + tab tag"));
                lore.add(txt("&7Preview: " + t.text + "&f" + d.name));
            }
            case "name" -> {
                lore.add(txt("&8Name color"));
                lore.add(txt("&7Colors your name in chat + tab."));
                lore.add(txt("&7Preview: " + nameStyled(tokenOnly(t), d.name)));
            }
            case "sellfx" -> {
                lore.add(txt("&8Sell effect"));
                lore.add(txt("&7Particles burst around you"));
                lore.add(txt("&7every time you &e/sell&7."));
            }
            case "creative" -> {
                lore.add(txt("&8One-time unlock"));
                lore.add(txt("&7Switch to creative mode whenever"));
                lore.add(txt("&7you want: build, fly, free items."));
                lore.add(txt("&7Click it again to go back to survival."));
            }
            default -> {
                lore.add(txt("&8Exclusive rank"));
                lore.add(txt("&7Shown before your name in chat + tab:"));
                lore.add(txt(FEMBOY_PREFIX + "&f" + d.name));
                lore.add(txt("&7(it replaces your playtime rank tag)"));
            }
        }
        lore.add(txt(" "));
        if (owned) {
            lore.add(txt(eq ? "&a&lEQUIPPED &7- click to take it off" : "&aOwned &7- click to equip"));
        } else if (!shop) {
            lore.add(txt("&c&lLOCKED &7- &6" + t.price + " tokens"));
            lore.add(txt("&7Buy it in &e/tokenshop &7first."));
        } else {
            lore.add(txt("&7Price: &6" + t.price + " tokens"));
            lore.add(txt(d.tokens >= t.price ? "&aClick to buy" : "&cYou need " + (t.price - d.tokens) + " more tokens"));
        }
        im.lore(lore);
        if (eq) im.setEnchantmentGlintOverride(true);
        it.setItemMeta(im);
        return it;
    }

    /** A throwaway PD that wears only item t, used for the name color preview. */
    PD tokenOnly(TItem t) {
        PD x = new PD(new UUID(0, 0));
        x.activeName = t.id;
        return x;
    }

    @EventHandler
    public void onTokenShopClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof TokenHolder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int slot = e.getRawSlot();
        String ok = offKind(slot);
        if (ok != null) {
            removeActive(p, d, ok);
        } else {
            TItem t = h.items.get(slot);
            if (t != null) tokenClick(p, d, t);
        }
        fillTokenShop(top, d, h);
    }

    /** Equips an owned item, or takes it off if it is already worn. */
    void toggleEquip(Player p, PD d, TItem t) {
        String plain = t.name.replaceAll("&[0-9a-fk-or]", "");
        if (t.kind.equals("creative")) {
            toggleCreative(p, d);
            return;
        }
        if (t.kind.equals("rank")) {
            boolean nowOn = !d.on("femboy");
            if (nowOn) d.off.remove("femboy");
            else d.off.add("femboy");
            syncFemboy(d);
            msg(p, "&dFemboy rank " + (nowOn ? "&aequipped" : "&ctaken off"));
        } else if (t.id.equals(activeOf(d, t.kind))) {
            setActive(d, t.kind, "");
            msg(p, "&7" + plain + " unequipped.");
        } else {
            setActive(d, t.kind, t.id);
            if (t.kind.equals("tag")) msg(p, "&aTag equipped: " + t.text + "&f" + p.getName());
            else if (t.kind.equals("name")) msg(p, "&aName color equipped: &f" + plain);
            else msg(p, "&aSell effect equipped: &f" + plain + "&a. Try &e/sell&a!");
        }
        dirty = true;
        refreshTab(p);
        snd(p, d, Sound.UI_BUTTON_CLICK, 1f, 1.2f);
    }

    boolean creativeOn(PD d) {
        Player on = Bukkit.getPlayer(d.id);
        return on != null && on.getGameMode() == GameMode.CREATIVE;
    }

    void toggleCreative(Player p, PD d) {
        setCreative(p, d, p.getGameMode() != GameMode.CREATIVE);
    }

    void setCreative(Player p, PD d, boolean on) {
        if (!d.owned.contains("creative_mod")) return;
        p.setGameMode(on ? GameMode.CREATIVE : GameMode.SURVIVAL);
        msg(p, on ? "&bCreative mode &aon&b." : "&7Back to survival mode.");
        snd(p, d, Sound.UI_BUTTON_CLICK, 1f, 1.2f);
    }

    void tokenClick(Player p, PD d, TItem t) {
        String plain = t.name.replaceAll("&[0-9a-fk-or]", "");
        if (d.owned.contains(t.id)) { // already owned: equip / unequip
            toggleEquip(p, d, t);
            return;
        }
        if (d.tokens < t.price) {
            msg(p, "&cYou need &6" + t.price + " tokens &cfor that (you have &6" + d.tokens + "&c). &7You earn 1 token per new day from Day 35 on and 1 per 1000 rebirths.");
            snd(p, d, Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            return;
        }
        long now = System.currentTimeMillis();
        UUID id = p.getUniqueId();
        if (!t.id.equals(tokenPendingId.get(id)) || now - tokenPendingAt.getOrDefault(id, 0L) > 8000L) {
            tokenPendingId.put(id, t.id);
            tokenPendingAt.put(id, now);
            msg(p, "&eClick again to buy &f" + plain + " &efor &6" + t.price + " tokens&e.");
            snd(p, d, Sound.UI_BUTTON_CLICK, 1f, 1f);
            return;
        }
        tokenPendingId.remove(id);
        d.tokens -= t.price;
        d.owned.add(t.id);
        if (t.kind.equals("creative")) {
            broadcastNote("broadcasts", "&6[Cane] &e" + d.name + " &fbought &b&lCreative Mod &fwith Cane Tokens!");
            setCreative(p, d, true);
        } else if (t.kind.equals("rank")) {
            d.off.remove("femboy");
            syncFemboy(d);
            broadcastNote("broadcasts", "&6[Cane] &e" + d.name + " &fbought the " + FEMBOY_PREFIX.trim() + " &frank with Cane Tokens!");
        } else {
            setActive(d, t.kind, t.id);
        }
        dirty = true;
        if (notif(d, "purchasemsg")) msg(p, "&aBought &f" + plain + " &afor &6" + t.price + " tokens&a and unlocked it! &7(" + d.tokens + " tokens left)");
        snd(p, d, Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        refreshTab(p);
    }

    // ------------------------------------------------------------------ /tags, /cosmetic, /playtimerewards
    static class EquipHolder implements InventoryHolder {
        final Map<Integer, TItem> items = new HashMap<>();
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    static class PlayHolder implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    /** /tags (tags + the Femboy rank) and /cosmetic (name colors, sell effects): equip or unequip what you own. */
    void openEquip(Player p, PD d, String title, boolean tags) {
        EquipHolder h = new EquipHolder();
        Inventory inv = Bukkit.createInventory(h, 54, txt(title));
        h.inv = inv;
        fillEquip(inv, d, h, tags);
        p.openInventory(inv);
    }

    void fillEquip(Inventory inv, PD d, EquipHolder h, boolean tags) {
        h.items.clear();
        ItemStack glass = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);
        String[] kinds = tags ? new String[]{"tag"} : new String[]{"name", "sellfx"};
        inv.setItem(4, named(tags ? Material.NAME_TAG : Material.FIREWORK_STAR, tags ? "&6&lYour Tags" : "&6&lYour Cosmetics",
                "&7Click something you own to equip it,", "&7click it again to take it off.", "&8Locked items are bought in /tokenshop."));
        // rows of the kinds shown, one after the other starting at the first row
        Map<String, Integer> used = new HashMap<>();
        for (int r = 0; r < kinds.length; r++) {
            String k = kinds[r];
            int base = 9 * (r + 1);
            inv.setItem(base + 8, offIcon(k));
            h.items.put(base + 8, null);
            for (TItem t : tokenItems) {
                if (!t.kind.equals(k)) continue;
                int slot = base + used.merge(k, 1, Integer::sum) - 1;
                inv.setItem(slot, tokenIcon(d, t, false));
                h.items.put(slot, t);
            }
        }
        if (tags) {
            for (TItem t : tokenItems) {
                if (!t.kind.equals("rank")) continue;
                inv.setItem(22, tokenIcon(d, t, false));
                h.items.put(22, t);
            }
        }
        inv.setItem(49, named(Material.AMETHYST_SHARD, "&6Token Shop", "&7You have &6" + d.tokens + " tokens&7.", "&aClick to open /tokenshop"));
    }

    @EventHandler
    public void onEquipClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof EquipHolder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int slot = e.getRawSlot();
        boolean tags = top.getItem(4) != null && top.getItem(4).getType() == Material.NAME_TAG;
        if (slot == 49) {
            getServer().getScheduler().runTask(this, () -> openTokenShop(p, d));
            return;
        }
        if (h.items.containsKey(slot) && h.items.get(slot) == null) { // a "remove" button
            String[] kinds = tags ? new String[]{"tag"} : new String[]{"name", "sellfx"};
            int r = slot / 9 - 1;
            if (r >= 0 && r < kinds.length) removeActive(p, d, kinds[r]);
        } else {
            TItem t = h.items.get(slot);
            if (t == null) return;
            if (!d.owned.contains(t.id)) {
                msg(p, "&cYou don't own &f" + t.name.replaceAll("&[0-9a-fk-or]", "") + " &cyet. &7It costs &6" + t.price + " tokens &7in &e/tokenshop&7.");
                snd(p, d, Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            toggleEquip(p, d, t);
        }
        fillEquip(top, d, h, tags);
    }

    /** /playtimerewards - every playtime rank reward, whether you earned it, and how long you have played. */
    void openPlaytimeRewards(Player p, PD d) {
        PlayHolder h = new PlayHolder();
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lPlaytime Rewards"));
        h.inv = inv;
        ItemStack glass = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, glass);
        Tier next = null;
        for (Tier t : tiers) {
            if (d.playMs < t.hours * 3_600_000L) {
                next = t;
                break;
            }
        }
        String nextLine = next == null ? "&aYou earned every playtime reward!"
                : "&7Next: " + next.name + " &7in &f" + fmtPlay(next.hours * 3_600_000L - d.playMs);
        inv.setItem(4, named(Material.CLOCK, "&6&lYour playtime: &f" + fmtPlay(d.playMs), nextLine,
                "&8Playtime counts while you are online."));
        for (int i = 0; i < tiers.size() && i < 36; i++) {
            Tier t = tiers.get(i);
            long need = t.hours * 3_600_000L;
            boolean got = d.playMs >= need;
            boolean isNext = !got && t == next;
            ItemStack it = new ItemStack(got ? Material.EMERALD : isNext ? Material.YELLOW_DYE : Material.GRAY_DYE);
            ItemMeta im = it.getItemMeta();
            im.displayName(txt(t.name + (got ? " &a\u2714" : "")));
            List<Component> lore = new ArrayList<>();
            lore.add(txt("&7Reward: rank tag in chat + tab"));
            lore.add(txt("&7Preview: " + t.prefix + "&f" + d.name));
            lore.add(txt("&7Needs: &f" + t.hours + "h &7played"));
            lore.add(txt(" "));
            lore.add(txt(got ? "&a&lEARNED" : "&c" + fmtPlay(need - d.playMs) + " to go"
                    + " &7(" + Math.min(100, (int) (d.playMs * 100L / need)) + "%)"));
            im.lore(lore);
            if (got) im.setEnchantmentGlintOverride(true);
            it.setItemMeta(im);
            inv.setItem(9 + i, it);
        }
        p.openInventory(inv);
    }

    @EventHandler
    public void onPlayRewardsClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof PlayHolder) e.setCancelled(true);
    }

    /** The equipped sell effect bursts around the player when they /sell. */
    void playSellFx(Player p, PD d) {
        if (d.activeSellFx.isEmpty()) return;
        TItem t = tokenById.get(d.activeSellFx);
        if (t == null || t.particle == null) return;
        Location l = p.getLocation().add(0, 1.0, 0);
        l.getWorld().spawnParticle(t.particle, l, 30, 0.6, 0.6, 0.6, 0.05);
    }

    // ------------------------------------------------------------------ perks / flight
    void toggleEffect(Player p, PD d, ShopItem si) {
        String key = "fx_" + si.id;
        boolean nowOn = !d.on(key);
        if (nowOn) d.off.remove(key);
        else d.off.add(key);
        dirty = true;
        String nm = si.name.replaceAll("&[0-9a-fk-or]", "");
        if (nowOn) {
            applyEffects(p, d);
            msg(p, "&f" + nm + " &2enabled&f.");
        } else {
            p.removePotionEffect(effects.get(si.id));
            msg(p, "&f" + nm + " &cdisabled&f.");
        }
        snd(p, d, Sound.UI_BUTTON_CLICK, 0.7f, nowOn ? 1.3f : 0.8f);
    }

    void applyEffects(Player p, PD d) {
        for (Map.Entry<String, PotionEffectType> en : effects.entrySet()) {
            int lvl = d.lvl(en.getKey());
            if (lvl <= 0 || !d.on("fx_" + en.getKey())) continue;
            PotionEffectType type = en.getValue();
            PotionEffect cur = p.getPotionEffect(type);
            // still the right level, same flags and plenty of time left -> nothing to send
            if (cur != null && cur.getAmplifier() == lvl - 1 && cur.getDuration() >= EFFECT_REFRESH_BELOW_TICKS
                    && cur.isAmbient() && !cur.hasParticles() && cur.hasIcon()) continue;
            p.addPotionEffect(new PotionEffect(type, 600, lvl - 1, true, false, true));
        }
    }

    void applyFly(Player p, PD d) {
        if (!d.flyOwned || !d.flyOn) return;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (!p.getAllowFlight()) p.setAllowFlight(true);
    }

    void perkTick() {
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            applyEffects(p, d);
            applyFly(p, d);
            applyTimeIfChanged(p, d, now);
            tabUpdate(p, false);
        }
        perkState.keySet().removeIf(id -> Bukkit.getPlayer(id) == null); // forget players who left
    }

    // ------------------------------------------------------------------ ticking tasks
    long lastGlobalMs = 0;   // when the global tick last ran
    long secAccumMs = 0;     // leftover milliseconds not yet counted as a whole second for the day timers
    long discordAccumMs = 0, creditAccumMs = 0, saveAccumMs = 0; // timers folded into the global tick
    long lagAccumMs = 0;     // time since the lag remover last ran (it keeps its own lag-remover.interval-seconds)

    /**
     * THE one tick of the whole plugin's accounting, every 3 seconds. Everything that used to run on its own timer
     * (cane scan + growth, Auto Sell pay, day timers, playtime, perks, scoreboard, lag remover, chest cleanup) runs
     * once here, for everybody, using the REAL time that passed since the last run - so every rate, timer and payout
     * comes out the same as before, it is just calculated once per 3 s instead of many times per second.
     * (Things that must react instantly - void rescue, island border, Chunk Hoppers, particles - keep their own fast timers.)
     */
    void globalTick() {
        long now = System.currentTimeMillis();
        long dt = lastGlobalMs == 0 ? GLOBAL_TICKS * 50L : Math.max(0L, Math.min(now - lastGlobalMs, 30000L));
        lastGlobalMs = now;
        fastTick();         // void rescue (online players only)
        boundaryTick();     // island border (online players only)
        entityTick();       // no entities allowed on the islands of ONLINE players: everything that is not a player or a dropped item is removed
        chunkHopperTick();  // Chunk Hoppers on online players' islands
        caneScanTick(dt);   // count + grow the cane once for every online island
        simTick();          // forget dead Auto Sell cores
        payTick();          // Auto Sell pays every online owner (by elapsed time)
        playTick();         // playtime + ranks (by elapsed time)
        perkTick();         // effects / fly / time / tab for everyone online
        chunkBorderTick();  // chunk border particles (online players who switched them on)
        wandPreviewTick();  // wand preview corners (online players holding the wand)
        if (lagEnabled) {
            lagAccumMs += dt;
            if (lagAccumMs >= lagTicks * 50L) {
                lagAccumMs = 0;
                lagTick();
            }
        }
        secAccumMs += dt;
        int secs = (int) (secAccumMs / 1000L);
        secAccumMs -= secs * 1000L;
        secondTick(secs);   // day timers, action bar, sleep, Auto Sell notices, scoreboard
        discordAccumMs += dt;
        if (discordAccumMs >= discordSeconds * 1000L) {
            discordAccumMs = 0;
            discordAdvert();
        }
        creditAccumMs += dt;
        if (creditAccumMs >= 300_000L) {
            creditAccumMs = 0;
            if (!Credit.valid(this)) {
                getLogger().severe("The ownership credit was removed or changed - disabling. Original plugin: " + Credit.LINE);
                getServer().getPluginManager().disablePlugin(this);
                return;
            }
        }
        saveAccumMs += dt;
        if (saveAccumMs >= 60_000L) {
            saveAccumMs = 0;
            if (dirty || saveFailed) saveData();
        }
        playSaveAccumMs += dt;
        if (playSaveAccumMs >= PLAY_SAVE_MS) {
            playSaveAccumMs = 0;
            if (playDirty) saveData(); // playtime-only changes: every 5 minutes
        }
        if (quitSaveDue && now - lastSaveMs >= QUIT_SAVE_MIN_GAP_MS) {
            quitSaveDue = false;
            if (playDirty || dirty) saveData(); // someone quit: persist their playtime (debounced to one save per 10 s)
        }
    }

    /** Every chunk of every ONLINE player's island that is loaded (each chunk once). Nothing else is ever processed. */
    List<int[]> onlineChunks() {
        List<int[]> out = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            for (int[] c : chunksOf(d))
                if (world.isChunkLoaded(c[0], c[1]) && seen.add(chunkKey(c[0], c[1]))) out.add(c);
        }
        return out;
    }

    boolean ownerOnline(UUID id) {
        return id != null && Bukkit.getPlayer(id) != null;
    }

    void secondTick(int secs) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            long req = required(d.day);
            if (!d.completed) {
                int oldLeft = d.timeLeft;
                d.timeLeft -= secs;
                if (secs > 0 && d.timeLeft <= 0) {
                    failDay(p, d);
                    req = required(d.day);
                } else if (secs > 0 && notif(d) && d.on("warnings")) {
                    // warnings fire when the timer crosses 5:00 / 1:00 / 0:10 (the timer now moves in steps of the global tick)
                    for (int w : new int[]{300, 60, 10}) {
                        if (oldLeft > w && d.timeLeft <= w) {
                            msg(p, "&c" + mmss(d.timeLeft) + " left to finish Day " + d.day + "! (" + fmt(d.submitted) + "/" + fmt(req) + ")");
                            break;
                        }
                    }
                }
                if (notif(d) && d.on("actionbar")) sendBar(p, "&6Day " + d.day + " &7| &f" + fmt(d.submitted) + "/" + fmt(req) + " cane &7| &c" + mmss(Math.max(d.timeLeft, 0)));
                else lastBar.remove(p.getUniqueId());
            } else {
                if (notif(d) && d.on("actionbar")) sendBar(p, "&aDay " + d.day + " complete! &7Use &e/caneday &7for the next day.");
                else lastBar.remove(p.getUniqueId());
            }
        }
        sleepCheck();
        autoSubmitTick();
        scoreboardTick();
    }

    /** Sends the action bar only when the text differs from what this player last got. */
    void sendBar(Player p, String text) {
        if (!text.equals(lastBar.put(p.getUniqueId(), text))) p.sendActionBar(txt(text));
    }

    /** Every discord.interval-seconds (default 2 minutes): tells everyone online to join the Discord server (click to open). */
    void discordAdvert() {
        if (Bukkit.getOnlinePlayers().isEmpty()) return;
        if (discordAdvertMsg == null || !discordLink.equals(discordAdvertLink)) { // build the component once per link, not every broadcast
            discordAdvertMsg = discordMessage();
            discordAdvertLink = discordLink;
        }
        Bukkit.broadcast(discordAdvertMsg);
    }

    /** The Discord invite message: used by the announcement and by /discord, so both always show the same text and link. */
    Component discordMessage() {
        Component link = txt("&9&n" + discordLink)
                .clickEvent(ClickEvent.openUrl(discordLink))
                .hoverEvent(HoverEvent.showText(txt("&7Click to open the Discord invite")));
        return txt("&6[Cane] &fJoin our &9Discord &fserver for updates, help and giveaways! ").append(link);
    }

    void sleepCheck() {
        boolean sleeping = false;
        for (Player p : world.getPlayers()) {
            if (p.isDeeplySleeping()) {
                sleeping = true;
                break;
            }
        }
        if (!sleeping) return;
        long t = world.getTime();
        if ((t >= 12541 && t <= 23458) || world.hasStorm()) {
            world.setTime(0);
            world.setStorm(false);
            world.setThundering(false);
        }
    }

    /**
     * One pass over the island world's players for BOTH safety nets (it used to be two passes, fastTick + boundaryTick, each
     * copying the player list and reading every location): void rescue first, then the island border.
     */
    void fastTick() {
        final List<Player> list = world.getPlayers();
        if (list.isEmpty()) return;
        for (Player p : list) {
            Location l = p.getLocation();
            if (l.getY() < 20) { // void rescue
                PD rescue = players.get(p.getUniqueId());
                p.setFallDistance(0f);
                p.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
                if (rescue != null) p.teleport(home(rescue));
                else p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
                l = p.getLocation(); // the border pass used to see the player where the rescue put them
                if (!world.equals(l.getWorld()) || l.getY() < 20) continue;
            }
            // island border: the owner of the chunk is looked up ONCE and reused by every check below
            final UUID me = p.getUniqueId();
            final int bx = l.getBlockX(), bz = l.getBlockZ();
            final UUID here = chunkOwners.get(chunkKey(bx >> 4, bz >> 4));
            if (here != null && here.equals(me)) visiting.remove(me); // back on own island
            if (mayBeAt(p, bx, bz, here)) continue;
            PD d = players.get(me);
            p.setFallDistance(0f);
            p.teleport(d != null ? home(d) : Bukkit.getWorlds().get(0).getSpawnLocation());
        }
    }

    /** Cane only grows (and only counts for Auto Sell) while it has water next to its soil block, like vanilla - so nobody can grow cane dry. */
    static final boolean CANE_NEEDS_WATER = true;

    /** Vanilla rule: water (or a waterlogged block / frosted ice) beside the block under the cane base. */
    boolean caneHasWater(int x, int y, int z) {
        final int[][] around = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] o : around) {
            int nx = x + o[0], nz = z + o[1];
            if (!world.isChunkLoaded(nx >> 4, nz >> 4)) continue;
            Block nb = world.getBlockAt(nx, y - 1, nz);
            if (nb.getType() == Material.FROSTED_ICE || holdsWater(nb)) return true;
        }
        return false;
    }

    /** Full scan of one chunk snapshot: every cane base on every Y level that holds blocks. Pure function of the snapshot, so it is safe off the main thread. */
    static java.util.TreeSet<Integer> caneScanBases(ChunkSnapshot snap, int minY, int maxY) {
        java.util.TreeSet<Integer> out = new java.util.TreeSet<>();
        final int lo = CANE_CLAMP_TO_FARM_Y ? Math.max(minY, MIN_Y) : minY;
        final int hi = CANE_CLAMP_TO_FARM_Y ? Math.min(maxY - 1, MAX_Y) : maxY - 1;
        final int secLo = (lo - minY) >> 4, secHi = (hi - minY) >> 4;
        for (int sec = secLo; sec <= secHi; sec++) {
            if (snap.isSectionEmpty(sec)) continue; // empty sections (everything above the islands) cost nothing
            final int y0 = Math.max(lo, minY + (sec << 4)), y1 = Math.min(hi, minY + (sec << 4) + 15);
            for (int y = y0; y <= y1; y++) {
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        if (snap.getBlockType(lx, y, lz) != Material.SUGAR_CANE) continue;
                        if (y > minY && snap.getBlockType(lx, y - 1, lz) == Material.SUGAR_CANE) continue;
                        out.add(((y - minY) << 8) | (lx << 4) | lz);
                    }
                }
            }
        }
        return out;
    }

    /**
     * Water check read from the snapshot (same rule as caneHasWater / holdsWater).
     * 1 = water beside the soil, 0 = none, -1 = undecided: a neighbour column lies in another chunk, so the main thread has to look.
     */
    static int caneWetSnap(ChunkSnapshot snap, int minY, int lx, int y, int lz) {
        if (y - 1 < minY) return 0;
        boolean edge = false;
        final int[][] around = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (int[] o : around) {
            int nx = lx + o[0], nz = lz + o[1];
            if (nx < 0 || nx > 15 || nz < 0 || nz > 15) {
                edge = true;
                continue;
            }
            Material m = snap.getBlockType(nx, y - 1, nz);
            if (m == Material.FROSTED_ICE || m == Material.WATER || m == Material.BUBBLE_COLUMN || m == Material.KELP
                    || m == Material.KELP_PLANT || m == Material.SEAGRASS || m == Material.TALL_SEAGRASS) return 1;
            if (snap.getBlockData(nx, y - 1, nz) instanceof org.bukkit.block.data.Waterlogged wl && wl.isWaterlogged()) return 1;
        }
        return edge ? -1 : 0;
    }

    /** Y of the lowest cane in the column of (x, y, z), walking down from y; Integer.MIN_VALUE when (x, y, z) is not cane. */
    int caneBottomY(int x, int y, int z) {
        final int minY = world.getMinHeight();
        if (y < minY || y >= world.getMaxHeight() || world.getBlockAt(x, y, z).getType() != Material.SUGAR_CANE) return Integer.MIN_VALUE;
        while (y > minY && world.getBlockAt(x, y - 1, z).getType() == Material.SUGAR_CANE) y--;
        return y;
    }

    /** Adds a base found by caneBottomY to a packed set (ignores "not cane"). */
    void caneAdd(java.util.TreeSet<Integer> set, int minY, int x, int y, int z) {
        if (y == Integer.MIN_VALUE) return;
        if (CANE_CLAMP_TO_FARM_Y && (y < MIN_Y || y > MAX_Y)) return;
        set.add(((y - minY) << 8) | ((x & 15) << 4) | (z & 15));
    }

    /**
     * Main thread. Re-derives a chunk's bases and water from the world, but only for the cane that is already indexed plus the blocks
     * that were just placed - no full-height scan. Runs only when something changed in / next to the chunk.
     */
    void caneRecompute(int cx, int cz, CaneChunk cc) {
        final int minY = world.getMinHeight();
        final int bx = cx << 4, bz = cz << 4;
        final java.util.TreeSet<Integer> next = new java.util.TreeSet<>();
        for (int k : cc.bases) {
            final int x = bx + ((k >> 4) & 15), y = minY + (k >> 8), z = bz + (k & 15);
            caneAdd(next, minY, x, caneBottomY(x, y, z), z);     // still a base - or cane was put under it, so the new bottom is the base
            caneAdd(next, minY, x, caneBottomY(x, y + 1, z), z); // cane left floating above a removed base is a base itself now
        }
        for (int[] t : cc.touched) caneAdd(next, minY, t[0], caneBottomY(t[0], t[1], t[2]), t[2]); // freshly placed cane
        cc.touched.clear();
        final List<int[]> live = new ArrayList<>();
        for (int k : next) {
            final int x = bx + ((k >> 4) & 15), y = minY + (k >> 8), z = bz + (k & 15);
            if (CANE_NEEDS_WATER && !caneHasWater(x, y, z)) continue;
            live.add(new int[]{x, y, z});
        }
        cc.bases = next;
        cc.live = live;
        cc.dirty = false;
        chunkStalks.put(chunkKey(cx, cz), live.size());
    }

    /**
     * Safety refresh. Main thread: only copies the snapshot (cheap). Async: finds the bases and reads the water from the snapshot.
     * Main thread again: applies the result if nothing changed in the meantime (otherwise the event-driven index stays and it retries next tick).
     */
    void caneRefreshAsync(int cx, int cz, CaneChunk cc) {
        final long key = chunkKey(cx, cz);
        final ChunkSnapshot snap = world.getChunkAt(cx, cz).getChunkSnapshot(false, false, false);
        final int minY = world.getMinHeight(), maxY = world.getMaxHeight();
        final int bx = cx << 4, bz = cz << 4;
        final int seq = cc.seq;
        cc.scanning = true;
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            final java.util.TreeSet<Integer> found = caneScanBases(snap, minY, maxY);
            final List<int[]> rows = new ArrayList<>(found.size()); // {x, y, z, 1 wet / 0 dry / -1 ask the main thread}
            for (int k : found) {
                final int lx = (k >> 4) & 15, lz = k & 15, y = minY + (k >> 8);
                rows.add(new int[]{bx + lx, y, bz + lz, CANE_NEEDS_WATER ? caneWetSnap(snap, minY, lx, y, lz) : 1});
            }
            if (!isEnabled()) return;
            getServer().getScheduler().runTask(this, () -> {
                cc.scanning = false;
                if (caneIndex.get(key) != cc || cc.seq != seq) return; // chunk unloaded / changed while scanning: keep the event-driven index, retry next tick
                final List<int[]> live = new ArrayList<>(rows.size());
                for (int[] r : rows) {
                    if (r[3] == 1 || (r[3] == -1 && caneHasWater(r[0], r[1], r[2]))) live.add(new int[]{r[0], r[1], r[2]});
                }
                cc.bases = found;
                cc.live = live;
                cc.touched.clear();
                cc.scannedAt = System.currentTimeMillis();
                chunkStalks.put(key, live.size());
            });
        });
    }

    /** A block changed at (x, y, z): the chunk (and a neighbour chunk when it sits on the border, because water is read across it) re-derives its cane before the next growth pass. */
    void caneTouch(int x, int y, int z, boolean placed) {
        final int cx = x >> 4, cz = z >> 4, lx = x & 15, lz = z & 15;
        CaneChunk cc = caneIndex.get(chunkKey(cx, cz));
        if (cc != null) {
            cc.dirty = true;
            cc.seq++;
            if (placed) {
                if (cc.touched.size() < 512) cc.touched.add(new int[]{x, y, z});
                else cc.scannedAt = 0L; // a huge burst: let the safety refresh pick it up
            }
        }
        if (lx == 0) caneDirty(cx - 1, cz);
        else if (lx == 15) caneDirty(cx + 1, cz);
        if (lz == 0) caneDirty(cx, cz - 1);
        else if (lz == 15) caneDirty(cx, cz + 1);
    }

    void caneDirty(int cx, int cz) {
        CaneChunk n = caneIndex.get(chunkKey(cx, cz));
        if (n != null) {
            n.dirty = true;
            n.seq++;
        }
    }

    /**
     * The cane plants that count in a chunk ({x, y, z} of every cane base with water beside its soil, any Y level, old scan order), served from the chunk's index.
     * First load (or after an island reset wiped the cached count): one full scan right here, so the count is right in the same tick like before.
     * After that: no scanning at all unless something changed (re-derive, cheap) or the safety refresh is due (async).
     */
    List<int[]> caneBases(int cx, int cz) {
        final long key = chunkKey(cx, cz);
        CaneChunk cc = caneIndex.get(key);
        if (cc == null || !chunkStalks.containsKey(key)) {
            if (cc == null) {
                cc = new CaneChunk();
                caneIndex.put(key, cc);
            }
            ChunkSnapshot snap = world.getChunkAt(cx, cz).getChunkSnapshot(false, false, false);
            cc.bases = caneScanBases(snap, world.getMinHeight(), world.getMaxHeight());
            cc.touched.clear();
            cc.scannedAt = System.currentTimeMillis();
            cc.seq++;          // an async refresh still in flight is now stale and gets dropped
            cc.dirty = true;   // the recompute below reads the water
        } else if (!cc.scanning && System.currentTimeMillis() - cc.scannedAt >= CANE_REFRESH_MS) {
            caneRefreshAsync(cx, cz, cc);
        }
        if (cc.dirty) caneRecompute(cx, cz, cc);
        return cc.live;
    }

    /**
     * THE one cane pass for the whole server, run once every global tick (3 s, not per player):
     * every loaded island chunk's plant count is stored in chunkStalks (that number is what Auto Sell, the scoreboard and /caneinfo read -
     * nothing else ever scans) and the real cane gets its growth roll. The plants come from the per-chunk index (see caneBases), so a quiet
     * chunk costs a couple of block reads per plant instead of a full-height scan.
     */
    void caneScanTick(long dtMs) {
        for (PD d : players.values()) {
            if (Bukkit.getPlayer(d.id) == null) continue; // offline owners are never scanned (their cached counts are kept)
            if (caneStopped(d)) continue; // "Stop Sugar Cane Growth": no growth, no Auto Sell income, so no scan either
            // growth chance is defined per 2 s; this pass covers dtMs milliseconds, so use the chance of at least one roll in dtMs/2000 of them
            double p = Math.min(1.0, growthChance(d));
            double chance = p >= 1.0 ? 1.0 : 1.0 - Math.pow(1.0 - p, dtMs / 2000.0);
            for (int[] c : chunksOf(d)) {
                if (!world.isChunkLoaded(c[0], c[1])) continue; // unloaded chunks keep their last counted number
                List<int[]> bases = caneBases(c[0], c[1]);
                final long key = chunkKey(c[0], c[1]);
                chunkStalks.put(key, bases.size());
                if (chance <= 0 || bases.isEmpty()) continue;
                boolean stale = false;
                for (int[] bp : bases) {
                    Block b = world.getBlockAt(bp[0], bp[1], bp[2]);
                    if (b.getType() != Material.SUGAR_CANE) { // gone without an event we saw: never grow floating cane, re-derive the chunk next tick
                        stale = true;
                        continue;
                    }
                    // cane only ever grows to MAX_CANE_HEIGHT, so there is no need to walk further than that
                    int h = 1;
                    Block top = b;
                    while (h < MAX_CANE_HEIGHT && top.getRelative(BlockFace.UP).getType() == Material.SUGAR_CANE) {
                        top = top.getRelative(BlockFace.UP);
                        h++;
                    }
                    if (h >= MAX_CANE_HEIGHT) continue; // cane only ever grows to 2 blocks
                    Block above = top.getRelative(BlockFace.UP);
                    if (airish(above) && rng.nextDouble() < chance) {
                        above.setType(Material.SUGAR_CANE, false); // the base does not change, so the index needs no update
                    }
                }
                if (stale) {
                    CaneChunk cc = caneIndex.get(key);
                    if (cc != null) cc.dirty = true;
                }
            }
        }
    }

    /**
     * Residual entity sweep. The real work is event based (onSpawn / onEntitySpawn cancel everything that is not an item
     * or a player on the island world). This only catches what fires no cancellable spawn event (entities saved in the
     * chunk before, some projectiles / vehicles). Runs every ENTITY_SWEEP_EVERY global ticks, ONLY on the loaded island
     * chunks of ONLINE players, and never touches any other world.
     */
    void entityTick() {
        if (++entitySweepSkip < ENTITY_SWEEP_EVERY) return;
        entitySweepSkip = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            for (int[] c : chunksOf(d)) {
                org.bukkit.Chunk ch = world.isChunkLoaded(c[0], c[1]) ? world.getChunkAt(c[0], c[1]) : null; // null = not loaded, never loads a chunk
                if (ch == null) continue;
                for (Entity en : ch.getEntities()) {
                    if (en instanceof Player || en instanceof Item || en.isDead()) continue;
                    en.remove();
                }
            }
        }
    }

    /**
     * Lag remover: if an island holds more than the threshold of entities (anything that isn't a player) at once, the
     * dropped items on that island older than the min age are cleared.
     * Only "hot" islands are scanned (see lagHot): an island's count can only go UP through an item spawn or a chunk's
     * entities loading, so an island that was checked and is under the threshold needs no scan until one of those happens.
     * An island stays hot while it is still over the threshold (e.g. its drops are not old enough yet).
     */
    void lagTick() {
        Set<UUID> online = new HashSet<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            UUID id = p.getUniqueId();
            online.add(id);
            if (players.containsKey(id) && lagSeen.add(id)) lagHot.add(id); // just came online: check once
        }
        lagSeen.retainAll(online);
        if (lagHot.isEmpty()) return;
        var iter = lagHot.iterator();
        while (iter.hasNext()) {
            UUID id = iter.next();
            PD d = players.get(id);
            Player op = online.contains(id) ? Bukkit.getPlayer(id) : null;
            if (d == null || op == null) { // offline owners are never scanned; a login marks them hot again
                iter.remove();
                continue;
            }
            int count = 0;
            List<Item> drops = new ArrayList<>();
            for (int[] c : chunksOf(d)) {
                org.bukkit.Chunk ch = world.isChunkLoaded(c[0], c[1]) ? world.getChunkAt(c[0], c[1]) : null;
                if (ch == null) continue;
                for (Entity en : ch.getEntities()) {
                    if (en instanceof Player) continue;
                    count++;
                    // only items that have been lying around longer than the min age get cleared,
                    // so fresh drops can still be picked up by a Chunk Hopper
                    if (en instanceof Item it && it.getTicksLived() > lagMinAge) drops.add(it);
                }
            }
            if (count <= lagThreshold) { // under the threshold: sleep until the next spawn / load marks it hot
                iter.remove();
                continue;
            }
            if (drops.isEmpty()) continue; // over, but everything is still young: stay hot, look again next run
            for (Item it : drops) it.remove();
            if (count - drops.size() <= lagThreshold) iter.remove();
            if (notif(d) && d.on("lagmsg"))
                msg(op, "&eLag remover: your island had &c" + count + " &eentities, so &c" + drops.size() + " &eold dropped item(s) were cleared.");
        }
    }

    // ------------------------------------------------------------------ Auto Sell simulation
    /** How many cane plants (stalk bases, ANY Y level) are in a chunk: just reads the number caneScanTick counted (never scans, never loads chunks). */
    int stalksIn(int cx, int cz) {
        return chunkStalks.getOrDefault(chunkKey(cx, cz), 0);
    }

    /** Every cane plant on the player's island: all owned chunks, all layers. */
    int stalksOf(PD d) {
        int n = 0;
        for (int[] c : chunksOf(d)) n += stalksIn(c[0], c[1]);
        return n;
    }

    /** Chance that one plant grows a block on one growth roll (a roll every 2 seconds) - the same maths as the real growth. */
    double growthChance(PD d) {
        return baseChance + perLevel * growthLevel(d); // no cap: Growth Boost keeps scaling forever (past 100% it only adds Auto Sell income)
    }

    /** Cane per second the simulation earns: every growth would have been harvested, and Bonus Drops add extra cane on top. */
    double simRate(PD d, int stalks) {
        if (caneStopped(d)) return 0; // no growth, no Auto Sell income
        return stalks * growthChance(d) / 2.0 * (1.0 + dropChance(d));
    }

    /** Cane + coins per minute (after Coin Boost and Rebirth), for /caneinfo. */
    double simCoinsPerMinute(PD d, int stalks) {
        return simRate(d, stalks) * 60.0 * coinsPerCane * (1.0 + 0.10 * (d.lvl("coinboost") + d.rewardSell)) * rebirthMult(d) * midasMult(d);
    }

    boolean hasCollector(UUID owner) {
        for (Special s : specials.values())
            if (s.type.equals("sellcollector") && owner.equals(s.owner)) return true;
        return false;
    }

    static boolean isSpecialType(String t) {
        return t.equals("sellcollector") || t.equals("chunkhopper");
    }

    /** Settles the cane an owner's island "grew" since the last settle and pays it out through the normal submit() path. */
    void simulate(PD d) {
        simulate(d, System.currentTimeMillis());
    }

    void simulate(PD d, long now) {
        if (d.lastSim <= 0) {
            d.lastSim = now;
            return;
        }
        long capMs = (long) (simMaxOfflineHours * 3600_000L);
        long dt = Math.max(0L, Math.min(now - d.lastSim, capMs));
        d.lastSim = now;
        if (dt <= 0) return;
        int stalks = stalksOf(d);
        if (stalks <= 0) return;
        d.carry += simRate(d, stalks) * (dt / 1000.0);
        long whole = (long) Math.floor(d.carry);
        if (whole <= 0) return;
        d.carry -= whole;
        double before = d.coins;
        submit(d, whole); // Coin Boost, daily-bonus levels, Rebirth multiplier, canetop and quota all happen in here
        double[] w = autoSubWindow.computeIfAbsent(d.id, k -> new double[]{now, 0, 0});
        w[1] += whole;
        w[2] += d.coins - before;
    }

    /** Old Auto Sell Chunk Collector chest -> Cane Core beacon, in place. Whatever was inside the chest is dropped, not lost. */
    void convertOldCollector(Block b) {
        if (b.getState() instanceof Chest ch) {
            Location at = b.getLocation().add(0.5, 0.5, 0.5);
            for (ItemStack st : ch.getInventory().getContents())
                if (st != null && !st.getType().isAir()) world.dropItemNaturally(at, st);
            ch.getInventory().clear();
        }
        b.setType(Material.BEACON, false);
    }

    /** On startup (once ever): every already-placed Auto Sell Chunk Collector chest becomes a Cane Core beacon (same spot, same owner), so AFK players keep earning. */
    void migrateCores() {
        if (!migrationDone("cores")) {
            int blocks = 0;
            for (Special s : new ArrayList<>(specials.values())) {
                if (!s.type.equals("sellcollector")) continue;
                Block b = world.getBlockAt(s.x, s.y, s.z); // loads the chunk if needed
                if (b.getType() == Material.CHEST) {
                    convertOldCollector(b);
                    blocks++;
                }
            }
            markMigrationDone("cores"); // simTick still converts any chest that shows up later
            if (blocks > 0) getLogger().info("Converted " + blocks + " Auto Sell Chunk Collector chest(s) into Cane Core beacons.");
        }
        for (Player p : Bukkit.getOnlinePlayers()) migrateCoreItems(p); // per-player flag: free after the first time
    }

    /** Old chest-type collector items in a player's inventory / ender chest become Cane Core items (same amount). Once per player. */
    void migrateCoreItems(Player p) {
        if (playerMigrated(p, "core_items")) return;
        for (Inventory inv : new Inventory[]{p.getInventory(), p.getEnderChest()}) {
            ItemStack[] cont = inv.getContents();
            for (int i = 0; i < cont.length; i++) {
                ItemStack it = cont[i];
                if (it == null || it.getType() != Material.CHEST || !"sellcollector".equals(specialOf(it))) continue;
                ItemStack n = specialItem("sellcollector");
                n.setAmount(it.getAmount());
                inv.setItem(i, n);
            }
        }
        markPlayerMigrated(p, "core_items");
    }

    /** The Cane Core is a beacon: stop its beacon menu from opening. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onCoreOpen(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null || !b.getWorld().equals(world) || b.getType() != Material.BEACON) return;
        Special s = specials.get(keyOf(b));
        if (s == null || !s.type.equals("sellcollector")) return;
        Player p = e.getPlayer();
        if (p.isSneaking() && p.getInventory().getItemInMainHand().getType().isBlock()
                && !p.getInventory().getItemInMainHand().getType().isAir()) return; // sneak + block = place it like normal
        e.setUseInteractedBlock(org.bukkit.event.Event.Result.DENY);
    }

    /** Every few seconds: forget Auto Sell cores whose block is gone. (Paying is done by payTick.) */
    void simTick() {
        List<String> gone = null; // removed after the loop (no defensive copy of the whole map)
        for (Special s : specials.values()) {
            if (!s.type.equals("sellcollector")) continue;
            if (!ownerOnline(s.owner)) continue; // offline owners are never scanned
            if (!world.isChunkLoaded(s.x >> 4, s.z >> 4)) continue;
            Block sb = world.getBlockAt(s.x, s.y, s.z);
            if (sb.getType() == Material.CHEST) {
                convertOldCollector(sb); // safety net: an old chest collector that was missed becomes a Cane Core
                continue;
            }
            if (sb.getType() != Material.BEACON) {
                if (gone == null) gone = new ArrayList<>();
                gone.add(s.key());
            }
        }
        if (gone != null) {
            for (String k : gone) specials.remove(k);
            dirty = true;
        }
    }

    /**
     * Every second, ALL online owners of a Cane Core are paid in the same pass with the same timestamp.
     * Nothing is scanned here: each island's income is just (cached cane plant count) x (growth chance) x multipliers.
     */
    void payTick() {
        final long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            PD d = players.get(p.getUniqueId());
            if (d == null) continue;
            if (collectorOwners.contains(d.id)) simulate(d, now);
            else d.lastSim = 0; // no Cane Core: nothing accrues until one is placed
        }
    }

    // ------------------------------------------------------------------ Chunk Hopper
    /**
     * Chunk Hopper: collects every dropped item in its chunk into the container it points at else keeps it.
     * No list copy (stale hoppers are removed after the loop), live block state (no snapshot), the destination block is
     * cached, the live inventory is only fetched when an item is actually there, and hoppers in the same chunk share one
     * entity array.
     */
    void chunkHopperTick() {
        List<Special> gone = null;
        long lastKey = Long.MIN_VALUE;
        Entity[] lastEnts = null;
        for (Special s : specials.values()) {
            if (!s.type.equals("chunkhopper")) continue;
            int cx = s.x >> 4, cz = s.z >> 4;
            long ck = chunkKey(cx, cz);
            if (!ownerOnline(chunkOwners.get(ck))) continue; // only islands of online players
            org.bukkit.Chunk ch = world.isChunkLoaded(cx, cz) ? world.getChunkAt(cx, cz) : null;
            if (ch == null) continue;
            Block hb = world.getBlockAt(s.x, s.y, s.z);
            if (hb.getType() != Material.HOPPER) {
                if (gone == null) gone = new ArrayList<>();
                gone.add(s);
                continue;
            }
            if (ck != lastKey) {
                lastEnts = ch.getEntities();
                lastKey = ck;
            }
            Inventory dest = null;
            boolean resolved = false;
            for (Entity en : lastEnts) {
                if (!(en instanceof Item it) || it.isDead() || it.getPickupDelay() >= 32767) continue;
                ItemStack st = it.getItemStack();
                if (st.getType().isAir()) continue;
                if (!resolved) { // only now do we need the container
                    resolved = true;
                    dest = hopperDest(s, hb);
                }
                if (dest == null) break;
                Map<Integer, ItemStack> left = dest.addItem(st.clone());
                if (left.isEmpty()) it.remove();
                else it.setItemStack(left.values().iterator().next());
            }
        }
        if (gone != null) {
            for (Special g : gone) specials.remove(g.key());
            hopperRoute.keySet().removeAll(gone);
            dirty = true;
        }
    }

    /** Where a Chunk Hopper puts its items: the container it points at (unless that is a special), else itself. Live inventory, never cached across ticks. */
    Inventory hopperDest(Special s, Block hb) {
        Block target = hopperRoute.get(s);
        if (target == null) {
            target = hb;
            if (hb.getBlockData() instanceof org.bukkit.block.data.type.Hopper hd) target = hb.getRelative(hd.getFacing());
            hopperRoute.put(s, target);
        }
        if (!target.equals(hb) && !specials.containsKey(keyOf(target)) && target.getState(false) instanceof Container tc)
            return tc.getInventory();
        return hb.getState(false) instanceof Container own ? own.getInventory() : null;
    }

    /** Bonus Drops: how many extra cane one hand-broken block gives (chance per level, can be above 100%). */
    int bonusCane(PD d) {
        double chance = dropChance(d);
        if (chance <= 0) return 0;
        int n = (int) chance;
        if (rng.nextDouble() < chance - n) n++;
        return n;
    }

    void autoSubmitTick() {
        flushAutoSubmitNotices();
    }

    /** Sends one summary per owner once their 5 minute window is over (only if the option is on and they are online). */
    void flushAutoSubmitNotices() {
        if (autoSubWindow.isEmpty()) return;
        long now = System.currentTimeMillis();
        var it = autoSubWindow.entrySet().iterator();
        while (it.hasNext()) {
            var en = it.next();
            double[] w = en.getValue();
            if (now - (long) w[0] < AUTOSUBMIT_NOTIFY_MS) continue;
            it.remove();
            Player op = Bukkit.getPlayer(en.getKey());
            PD d = players.get(en.getKey());
            if (op != null && d != null && notif(d) && d.on("autosubmit"))
                msg(op, "&aYour Cane Core earned &e" + fmt((long) w[1]) + " &acane for &e" + fmt(w[2]) + " &acoins in the last 5 minutes.");
        }
    }

    // ------------------------------------------------------------------ world protection / events
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        purgeSandItems(p);
        migrateCoreItems(p);
        getServer().getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) p.sendMessage(txt(Credit.CHAT));
        }, 60L);
        getServer().getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) refreshTab(p);
        }, 10L);
        PD d = players.get(p.getUniqueId());
        if (d == null) {
            PD nd = createIsland(p); // island is made automatically (and createIsland already teleports them there right away)
            p.teleport(home(nd));
            // repeat the teleport a few times so no other plugin / spawn logic can leave them at the world spawn
            for (long delay : new long[]{1L, 2L, 10L}) {
                getServer().getScheduler().runTaskLater(this, () -> {
                    if (p.isOnline()) p.teleport(home(nd));
                }, delay);
            }
            getServer().getScheduler().runTaskLater(this, () -> {
                if (p.isOnline()) whisperCommands(p);
            }, 20L);
            return;
        }
        d.name = p.getName();
        checkRank(d, p);
        syncRank(d);
        syncFemboy(d);
        d.lastSim = hasCollector(d.id) ? System.currentTimeMillis() : 0; // Auto Sell only pays while the owner is online: nothing for time spent away
        getServer().getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) refreshTab(p);
        }, 40L);
        if (d.autoRebirth && rebirthReady(d)) doRebirth(d, p);
        if (!d.breakerGiven) {
            d.breakerGiven = true;
            give(p, lineBreaker());
            dirty = true;
            msg(p, "&aYou received a &c&lLine Breaker&a! &7Right-click a block to break a whole line.");
        }
        visiting.remove(p.getUniqueId());
        p.teleport(home(d));
        getServer().getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) p.teleport(home(d)); // after other plugins / spawn logic ran
        }, 2L);
        applyFly(p, d);
        applyTime(p, d);
        if (!d.pending.isEmpty()) {
            for (int rd : new ArrayList<>(d.pending)) applyReward(p, d, rd, false);
            d.pending.clear();
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        PD d = players.get(e.getPlayer().getUniqueId());
        if (d != null) {
            e.setRespawnLocation(home(d));
            Player p = e.getPlayer();
            getServer().getScheduler().runTaskLater(this, () -> {
                if (p.isOnline()) {
                    applyFly(p, d);
                    applyEffects(p, d);
                    applyTime(p, d);
                }
            }, 5L);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getEntity().getWorld().equals(world)) e.setCancelled(true); // no mobs / animals / spawn-egg entities on the islands at all
    }

    /** Everything else that spawns on the island world (falling blocks, TNT, XP orbs, minecarts, item frames, ...) is cancelled before it ever exists. Items and players are left alone. */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntitySpawn(org.bukkit.event.entity.EntitySpawnEvent e) {
        Entity en = e.getEntity();
        if (en instanceof Item || en instanceof Player || !en.getWorld().equals(world)) return;
        e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        final Block f = e.getBlock();
        if (!f.getWorld().equals(world)) return;
        final Block t = e.getToBlock();
        final int fcx = f.getX() >> 4, fcz = f.getZ() >> 4, tcx = t.getX() >> 4, tcz = t.getZ() >> 4;
        final UUID a = chunkOwners.get(chunkKey(fcx, fcz));
        if (a == null) { // source chunk unowned: always blocked (same result as before)
            e.setCancelled(true);
            return;
        }
        // most flow stays inside one chunk: then the target has the same owner and the second lookup is skipped
        if ((fcx != tcx || fcz != tcz) && !a.equals(chunkOwners.get(chunkKey(tcx, tcz)))) {
            e.setCancelled(true);
            return;
        }
        // "Stop Water Flow" option: the owner's water never spreads in any direction (sideways or down)
        if (waterStopped(players.get(a)) && holdsWater(f)) e.setCancelled(true);
    }

    /** True for water, waterlogged blocks and the plants / columns that hold water. */
    static boolean holdsWater(Block b) {
        Material m = b.getType();
        if (m == Material.WATER || m == Material.BUBBLE_COLUMN || m == Material.KELP || m == Material.KELP_PLANT
                || m == Material.SEAGRASS || m == Material.TALL_SEAGRASS) return true;
        return b.getBlockData() instanceof org.bukkit.block.data.Waterlogged wl && wl.isWaterlogged();
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Block b = e.getClickedBlock();
        if (b == null || e.getAction() == Action.PHYSICAL) return;
        if (!b.getWorld().equals(world)) return;
        if (!canBuild(e.getPlayer(), b.getLocation())) e.setCancelled(true);
    }

    // ------------------------------------------------------------------ pouch use
    @EventHandler(priority = EventPriority.HIGH)
    public void onPouchUse(PlayerInteractEvent e) {
        ItemStack item = e.getItem();
        if (!isPouch(item)) return;
        Action act = e.getAction();
        if (act != Action.RIGHT_CLICK_BLOCK && act != Action.RIGHT_CLICK_AIR) return;
        EquipmentSlot hand = e.getHand();
        if (hand == null) return;
        Player p = e.getPlayer();
        Block clicked = e.getClickedBlock();
        // let people still open chests, doors, etc. (sneak is reserved for storing)
        if (clicked != null && !p.isSneaking() && clicked.getType().isInteractable()) return;
        // another plugin / our own protection already denied the click
        if (clicked != null && e.useInteractedBlock() == org.bukkit.event.Event.Result.DENY) {
            e.setCancelled(true);
            return;
        }
        e.setCancelled(true); // the pouch itself never does anything vanilla
        if (!p.getWorld().equals(world)) {
            msg(p, "&cPouches only work on the cane islands.");
            return;
        }
        if (p.isSneaking()) {
            pouchDeposit(p, hand);
            return;
        }
        if (clicked == null) return;
        pouchPlace(p, hand, clicked, e.getBlockFace());
    }

    void pouchDeposit(Player p, EquipmentSlot hand) {
        ItemStack pouch = p.getInventory().getItem(hand);
        Material store = pouchStore(pouch);
        if (store == null) return;
        String what = pouchWhat(store);
        if (unlimited(store)) {
            p.sendActionBar(txt("&b\u221E Your " + pouchName(store) + " never runs out - nothing to store."));
            return;
        }
        int cur = pouchAmount(pouch);
        int space = POUCH_CAP - cur;
        if (space <= 0) {
            p.sendActionBar(txt("&cYour " + pouchName(store) + " is full!"));
            return;
        }
        int moved = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36 && moved < space; i++) {
            ItemStack it = inv.getItem(i);
            // only plain items: infinite / renamed / special items are never accepted
            if (it == null || it.getType() != store || it.hasItemMeta()) continue;
            int take = Math.min(it.getAmount(), space - moved);
            moved += take;
            if (take >= it.getAmount()) inv.setItem(i, null);
            else it.setAmount(it.getAmount() - take);
        }
        if (moved == 0) {
            p.sendActionBar(txt("&cYou have no plain " + what + " to store."));
            return;
        }
        pouch = inv.getItem(hand);
        if (pouchStore(pouch) != store) return;
        setPouchAmount(pouch, cur + moved);
        p.sendActionBar(txt("&aStored &e" + fmt(moved) + " &a" + what + " &7(" + fmt(cur + moved) + "/" + fmt(POUCH_CAP) + ")"));
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 0.7f, 1f);
    }

    static final int POUCH_MAX_LINE = 80; // hard cap per click (5 chunks)

    /** True if the player carries an Infinite version of this block (e.g. Infinite Dirt) - pouches then never run out. */
    boolean hasInfinite(Player p, Material m) {
        for (ItemStack it : p.getInventory().getContents()) {
            if (it != null && it.getType() == m && isInf(it)) return true;
        }
        return false;
    }

    /**
     * Right-click: places a line of blocks in the direction the player is facing.
     * Dirt stops at the first obstacle or island edge. Sugar cane skips spots where it can't survive
     * (needs dirt next to water) so one click can plant a whole farm row, and stops at obstacles / the edge.
     */
    void pouchPlace(Player p, EquipmentSlot hand, Block clicked, BlockFace face) {
        long now = System.currentTimeMillis();
        Long last = pouchCooldown.get(p.getUniqueId());
        if (last != null && now - last < POUCH_COOLDOWN_MS) return;
        pouchCooldown.put(p.getUniqueId(), now);

        ItemStack pouch = p.getInventory().getItem(hand);
        final Material store = pouchStore(pouch);
        if (store == null) return;
        final boolean cane = store == Material.SUGAR_CANE;
        final boolean infinite = unlimited(store) || hasInfinite(p, store);
        int amount = infinite ? Integer.MAX_VALUE : pouchAmount(pouch);
        if (amount <= 0) {
            p.sendActionBar(txt("&cYour " + pouchName(store) + " is empty! &7Sneak + right-click to store " + pouchWhat(store) + "."));
            return;
        }
        // the first block goes where vanilla would put it; the line then runs the way the player is facing
        Block first = clicked.isReplaceable() ? clicked : clicked.getRelative(face);
        BlockFace dir = p.getFacing(); // always one of the 4 horizontal directions
        if (dir == BlockFace.UP || dir == BlockFace.DOWN) return;

        int placed = 0, steps = 0;
        Block cur = first;
        Block against = clicked;
        org.bukkit.block.data.BlockData caneData = cane ? Material.SUGAR_CANE.createBlockData() : null;
        while (placed < amount && steps < POUCH_MAX_LINE) {
            if (pouchStore(p.getInventory().getItem(hand)) != store) break; // pouch gone: stop right away
            // stop at the world edge
            if (!cur.getWorld().equals(world) || cur.getY() < world.getMinHeight() || cur.getY() >= world.getMaxHeight()) break;
            // the first block may replace grass etc; every block after it must be empty air ("a block in front" = stop)
            boolean free = steps == 0 ? cur.isReplaceable() : airish(cur);
            if (store == Material.SPONGE && cur.getType() == Material.WATER) free = true; // sponges may soak up water in the line
            if (!free || specials.containsKey(keyOf(cur))) break;
            // ownership: stops at the edge of your island - never builds on / into anyone else's chunks
            if (steps == 0 && !canPouch(p, clicked.getLocation())) {
                deny(p);
                return;
            }
            if (!canPouch(p, cur.getLocation())) {
                if (steps == 0) deny(p);
                break;
            }
            // sugar cane can only go where it survives (dirt next to water, or on top of cane): skip the rest
            if (cane && !caneData.isSupported(cur)) {
                steps++;
                against = cur;
                cur = cur.getRelative(dir);
                continue;
            }
            // never place inside a player / mob (also stops trapping people)
            boolean blocked = false;
            for (Entity en : world.getNearbyEntities(BoundingBox.of(cur))) {
                if (en instanceof LivingEntity le && !le.isDead()
                        && !(en instanceof Player pl && pl.getGameMode() == GameMode.SPECTATOR)) {
                    blocked = true;
                    break;
                }
            }
            if (blocked) break;

            BlockState old = cur.getState();
            cur.setType(store, store == Material.SPONGE); // sponges need physics so they absorb nearby water
            // player-placed leaves never decay
            if (cur.getBlockData() instanceof org.bukkit.block.data.type.Leaves lv) {
                lv.setPersistent(true);
                cur.setBlockData(lv, false);
            }
            // fire a normal place event so our protection (and other plugins) get the final say
            BlockPlaceEvent ev = new BlockPlaceEvent(cur, old, against, pouch, p, true, hand);
            getServer().getPluginManager().callEvent(ev);
            if (ev.isCancelled() || !ev.canBuild()) {
                old.update(true, false);
                break;
            }
            placed++;
            steps++;
            against = cur;
            cur = cur.getRelative(dir);
        }
        if (placed == 0) {
            if (cane) p.sendActionBar(txt("&cNo valid spot - sugar cane needs dirt next to water."));
            return;
        }
        ItemStack now2 = p.getInventory().getItem(hand);
        if (pouchStore(now2) != store) return; // pouch vanished mid-line
        world.playSound(first.getLocation().add(0.5, 0.5, 0.5), pouchByStore.get(store).sound, 1f, 1f);
        if (infinite) {
            refreshPouchLore(now2); // old pouches get the new "never runs out" lore
            p.sendActionBar(txt("&6Placed &f" + placed + " &6" + pouchWhat(store) + " &7- &b\u221E infinite &7(pouch untouched)"));
        } else {
            setPouchAmount(now2, amount - placed);
            p.sendActionBar(txt("&6Placed &f" + placed + " &6" + pouchWhat(store) + " &7- pouch: &f" + fmt(amount - placed) + "&7/" + fmt(POUCH_CAP)));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlaceProtect(BlockPlaceEvent e) {
        final Player p = e.getPlayer();
        final Block b = e.getBlock();
        final ItemStack hand = e.getItemInHand();
        final boolean inWorld = b.getWorld().equals(world);
        // Sand is disabled: it can't be placed on the island world by anything
        if (inWorld && (isSand(b.getType()) || isSand(hand.getType()))) {
            e.setCancelled(true);
            msg(p, "&cSand has been removed and can't be placed.");
            return;
        }
        final UUID owner = inWorld ? chunkOwners.get(chunkKey(b.getX() >> 4, b.getZ() >> 4)) : null; // one lookup for the Core check AND canBuild
        // item meta is copied ONCE (it used to be copied up to 3 times: specialOf + isInf); plain blocks have no meta and skip all of this
        if (hand.hasItemMeta()) {
            final var pdc = hand.getItemMeta().getPersistentDataContainer();
            final String sp = pdc.get(KEY_SPECIAL, PersistentDataType.STRING);
            if (sp != null) {
                if (!isSpecialType(sp)) {
                    e.setCancelled(true);
                    msg(p, "&cThis item was removed.");
                    return;
                }
                if (!inWorld) {
                    e.setCancelled(true);
                    msg(p, "&cThis can only be placed on your cane island.");
                    return;
                }
                if ("sellcollector".equals(sp)) {
                    UUID co = owner != null ? owner : p.getUniqueId();
                    if (hasCollector(co) || hasCollector(p.getUniqueId())) {
                        e.setCancelled(true);
                        msg(p, "&cYou can only place &6one &cCane Core. Break your existing one first.");
                        return;
                    }
                }
            } else if (pdc.has(KEY_INF, PersistentDataType.BYTE) && (b.getType() == Material.HOPPER || b.getType() == Material.CHEST)) {
                // old Infinite Hopper / Infinite Chest blocks no longer exist
                e.setCancelled(true);
                msg(p, "&cInfinite Hoppers / Chests were removed.");
                return;
            }
        }
        if (!inWorld) return;
        // owner of the chunk can always build there: skips canBuild's permission lookup (the admin check) for the common case
        if (!p.getUniqueId().equals(owner) && !canBuild(p, b.getLocation())) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        // sugar cane is never taller than MAX_CANE_HEIGHT (placing it on top of cane included)
        if (b.getType() == Material.SUGAR_CANE) {
            int h = 1;
            Block down = b.getRelative(BlockFace.DOWN);
            while (down.getType() == Material.SUGAR_CANE) {
                h++;
                down = down.getRelative(BlockFace.DOWN);
            }
            if (h > MAX_CANE_HEIGHT) {
                e.setCancelled(true);
                p.sendActionBar(txt("&cSugar cane can only be " + MAX_CANE_HEIGHT + " blocks tall."));
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlaceDone(BlockPlaceEvent e) {
        final ItemStack it = e.getItemInHand();
        if (!it.hasItemMeta()) return; // plain blocks (nearly every placement): not special, not infinite - nothing to do
        final var pdc = it.getItemMeta().getPersistentDataContainer(); // one meta copy (was two: specialOf + isInf)
        final String sp = pdc.get(KEY_SPECIAL, PersistentDataType.STRING);
        final boolean inf = pdc.has(KEY_INF, PersistentDataType.BYTE);
        if (sp == null && !inf) return;
        final Player p = e.getPlayer();
        if (sp != null) {
            Block b = e.getBlock();
            UUID owner = chunkOwners.get(chunkKey(b.getX() >> 4, b.getZ() >> 4));
            if (owner == null) owner = p.getUniqueId();
            specials.put(keyOf(b), new Special(sp, b.getX(), b.getY(), b.getZ(), owner));
            dirty = true;
            if (sp.equals("sellcollector")) {
                PD od = players.get(owner);
                if (od != null && od.lastSim <= 0) od.lastSim = System.currentTimeMillis(); // income starts counting now
                msg(p, "&aPlaced Cane Core! &7It now pays you for every cane plant on your island.");
            } else if (sp.equals("chunkhopper")) {
                msg(p, "&aPlaced Chunk Hopper! &7Point it at a chest.");
            }
        }
        if (inf) {
            EquipmentSlot hs = e.getHand();
            ItemStack copy = it.clone();
            copy.setAmount(copy.getMaxStackSize());
            getServer().getScheduler().runTask(this, () -> {
                ItemStack cur = p.getInventory().getItem(hs);
                if (cur == null || cur.getType() == Material.AIR || cur.isSimilar(copy)) p.getInventory().setItem(hs, copy);
            });
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        final Block b = e.getBlock();
        if (!b.getWorld().equals(world)) return;
        final Player p = e.getPlayer();
        // owner of the chunk can always break there: skips canBuild's permission lookup (the admin check) for the common case
        final UUID owner = chunkOwners.get(chunkKey(b.getX() >> 4, b.getZ() >> 4));
        if (!p.getUniqueId().equals(owner) && !canBuild(p, b.getLocation())) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        final Material type = b.getType();
        // specials only ever sit in these block types: every other break (cane, dirt, ...) skips building the "x,y,z" key string
        if (type == Material.BEACON || type == Material.HOPPER || type == Material.CHEST) {
            Special sp = specials.remove(keyOf(b));
            if (sp != null) {
                dirty = true;
                e.setDropItems(false);
                if (sp.type.equals("sellcollector")) {
                    // pay out what the island grew up to now; the clock stops when the last Cane Core is gone
                    PD od = players.get(sp.owner);
                    if (od != null && !hasCollector(sp.owner)) {
                        simulate(od);
                        od.lastSim = 0;
                    }
                }
                if (p.getGameMode() != GameMode.CREATIVE)
                    world.dropItemNaturally(b.getLocation().add(0.5, 0.5, 0.5), specialItem(sp.type));
                return;
            }
        }
        if (type == Material.SUGAR_CANE) {
            // Cane only drops when a PLAYER breaks it. Break the whole stack here so nothing pops off by itself
            // (those pops are cancelled in onCaneItemSpawn), then drop everything once the block is gone.
            PD d = players.get(p.getUniqueId());
            int count = 1;
            Block up = b.getRelative(BlockFace.UP);
            while (up.getType() == Material.SUGAR_CANE) {
                up.setType(Material.AIR, false);
                count++;
                up = up.getRelative(BlockFace.UP);
            }
            e.setDropItems(false);
            if (p.getGameMode() != GameMode.CREATIVE) {
                int total = count;
                if (d != null) for (int i = 0; i < count; i++) total += bonusCane(d);
                final int amount = total;
                final Location at = b.getLocation().add(0.5, 0.5, 0.5);
                getServer().getScheduler().runTask(this, () -> world.dropItemNaturally(at, new ItemStack(Material.SUGAR_CANE, amount)));
            }
        }
    }

    // ------------------------------------------------------------------ cane rules
    /** Vanilla cane growth is off on the islands: cane only grows through the plugin's growth (Growth Boost), to 2 blocks. */
    @EventHandler(ignoreCancelled = true)
    public void onCaneGrow(BlockGrowEvent e) {
        if (e.getBlock().getWorld().equals(world) && e.getNewState().getType() == Material.SUGAR_CANE) e.setCancelled(true);
    }

    /**
     * Cane never drops by itself (support lost, water, pistons...): a cane item that would appear INSIDE a cane block is cancelled.
     * Player breaks are not affected - the block is already air when their drops appear.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCaneItemSpawn(ItemSpawnEvent e) {
        Item it = e.getEntity();
        if (!it.getWorld().equals(world)) return;
        Location l = e.getLocation();
        int bx = l.getBlockX(), by = l.getBlockY(), bz = l.getBlockZ();
        if (it.getItemStack().getType() == Material.SUGAR_CANE && world.getType(bx, by, bz) == Material.SUGAR_CANE) {
            e.setCancelled(true); // cane never drops by itself
            return;
        }
        if (lagEnabled) { // this island just got a new drop: the lag remover should look at it
            UUID owner = chunkOwners.get(chunkKey(bx >> 4, bz >> 4));
            if (owner != null) lagHot.add(owner);
        }
    }

    /** Entities saved in a chunk just loaded: their island may now be over the lag threshold. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onLagEntitiesLoad(org.bukkit.event.world.EntitiesLoadEvent e) {
        if (!lagEnabled || !e.getWorld().equals(world) || e.getEntities().isEmpty()) return;
        UUID owner = chunkOwners.get(chunkKey(e.getChunk().getX(), e.getChunk().getZ()));
        if (owner != null) lagHot.add(owner);
    }

    /** Cane placed (by hand, by a pouch line - they fire this event too) or any block placed next to water/soil. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxPlace(BlockPlaceEvent e) {
        Block b = e.getBlockPlaced();
        if (b.getWorld().equals(world)) caneTouch(b.getX(), b.getY(), b.getZ(), true);
    }

    /** Anything broken (player or Breaker tool): cane, its soil, or the water beside it. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxBreak(BlockBreakEvent e) {
        Block b = e.getBlock();
        if (b.getWorld().equals(world)) caneTouch(b.getX(), b.getY(), b.getZ(), false);
    }

    /** Water placed / picked up with a bucket. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxBucketEmpty(PlayerBucketEmptyEvent e) {
        Block b = e.getBlock();
        if (b.getWorld().equals(world)) caneTouch(b.getX(), b.getY(), b.getZ(), false);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxBucketFill(PlayerBucketFillEvent e) {
        Block b = e.getBlock();
        if (b.getWorld().equals(world)) caneTouch(b.getX(), b.getY(), b.getZ(), false);
    }

    /** Water that flows into a new block. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxFlow(BlockFromToEvent e) {
        Block t = e.getToBlock();
        if (t.getWorld().equals(world)) caneTouch(t.getX(), t.getY(), t.getZ(), false);
    }

    /** A sponge soaks up water. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxSponge(org.bukkit.event.block.SpongeAbsorbEvent e) {
        if (!e.getBlock().getWorld().equals(world)) return;
        for (BlockState s : e.getBlocks()) caneTouch(s.getX(), s.getY(), s.getZ(), false);
    }

    /** Frosted ice (counts as water for cane) forming ... */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxIceForm(org.bukkit.event.block.BlockFormEvent e) {
        Block b = e.getBlock();
        if (b.getWorld().equals(world) && e.getNewState().getType() == Material.FROSTED_ICE) caneTouch(b.getX(), b.getY(), b.getZ(), false);
    }

    /** ... and melting. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCaneIdxIceFade(org.bukkit.event.block.BlockFadeEvent e) {
        Block b = e.getBlock();
        if (b.getWorld().equals(world) && b.getType() == Material.FROSTED_ICE) caneTouch(b.getX(), b.getY(), b.getZ(), false);
    }

    /** Copy & Paste Wand pastes (and /undo) set blocks without any event: using the wand asks the nearby chunks for a refresh on the next tick. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onCaneIdxWand(PlayerInteractEvent e) {
        ItemStack it = e.getItem();
        if (e.getAction() == Action.PHYSICAL || it == null || !isWand(it)) return;
        Player p = e.getPlayer();
        if (!p.getWorld().equals(world)) return;
        final int pcx = p.getLocation().getBlockX() >> 4, pcz = p.getLocation().getBlockZ() >> 4;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                CaneChunk cc = caneIndex.get(chunkKey(pcx + dx, pcz + dz));
                if (cc != null) cc.scannedAt = 0L;
            }
        }
    }

    /**
     * A chunk that unloads drops its index (the cached count stays) and gets one full scan again when it loads. Its 4 neighbours re-check their water on
     * both events, because water in an unloaded neighbour chunk does not count (same rule as caneHasWater).
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onCaneIdxUnload(ChunkUnloadEvent e) {
        if (!e.getWorld().equals(world)) return;
        final int cx = e.getChunk().getX(), cz = e.getChunk().getZ();
        caneIndex.remove(chunkKey(cx, cz));
        caneDirty(cx - 1, cz);
        caneDirty(cx + 1, cz);
        caneDirty(cx, cz - 1);
        caneDirty(cx, cz + 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onCaneIdxLoad(org.bukkit.event.world.ChunkLoadEvent e) {
        if (!e.getWorld().equals(world)) return;
        final int cx = e.getChunk().getX(), cz = e.getChunk().getZ();
        caneDirty(cx - 1, cz);
        caneDirty(cx + 1, cz);
        caneDirty(cx, cz - 1);
        caneDirty(cx, cz + 1);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        Player p = e.getPlayer();
        if (e.getBlock().getWorld().equals(world) && !canBuild(p, e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(p);
            return;
        }
        ItemStack hand = p.getInventory().getItem(e.getHand());
        if (hand != null && isInf(hand)) e.setItemStack(hand.clone());
    }

    @EventHandler(ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        Player p = e.getPlayer();
        if (e.getBlock().getWorld().equals(world) && !canBuild(p, e.getBlock().getLocation())) {
            e.setCancelled(true);
            deny(p);
        }
    }

    @EventHandler
    public void onCraftPrep(PrepareItemCraftEvent e) {
        for (ItemStack i : e.getInventory().getMatrix()) {
            if (i != null && (isInf(i) || specialOf(i) != null || isPouch(i) || isWaterPouch(i) || isBreaker(i) || isWand(i))) {
                e.getInventory().setResult(null);
                return;
            }
        }
    }

    // ------------------------------------------------------------------ island boundaries
    static final int BORDER_MARGIN = 3; // blocks players may stand outside their own chunks

    /** bx/bz are BLOCK coordinates. Own chunks + a margin of BORDER_MARGIN blocks around them are allowed. */
    boolean mayBeAt(Player p, int bx, int bz) {
        return mayBeAt(p, bx, bz, chunkOwners.get(chunkKey(bx >> 4, bz >> 4)));
    }

    /** Same rule, with the owner of the chunk at bx/bz already looked up by the caller. */
    boolean mayBeAt(Player p, int bx, int bz, UUID here) {
        final UUID me = p.getUniqueId();
        final boolean hasIsland = players.containsKey(me);
        if (hasIsland && me.equals(here)) return true; // own chunk (nearly every call): no permission lookup needed
        if (p.hasPermission("caneislands.admin")) return true;
        if (!hasIsland) return here == null; // no island: stay out of everyone's island
        UUID vis = visiting.get(me);
        if (here != null) return here.equals(vis); // someone else's chunk: only the island being visited
        return nearOwned(me, bx, bz) || (vis != null && nearOwned(vis, bx, bz));
    }

    boolean nearOwned(UUID u, int bx, int bz) {
        int m = BORDER_MARGIN;
        for (int dx = -m; dx <= m; dx += m) {
            for (int dz = -m; dz <= m; dz += m) {
                if (dx == 0 && dz == 0) continue;
                if (u.equals(chunkOwners.get(chunkKey((bx + dx) >> 4, (bz + dz) >> 4)))) return true;
            }
        }
        return false;
    }

    void warnBoundary(Player p) {
        long now = System.currentTimeMillis();
        Long last = boundaryWarned.get(p.getUniqueId());
        if (last != null && now - last < 1500) return;
        boundaryWarned.put(p.getUniqueId(), now);
        p.sendActionBar(txt("&cYou can't leave your island!"));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        final Location to = e.getTo();
        if (to == null) return;
        final Location from = e.getFrom();
        final int bx = to.getBlockX(), bz = to.getBlockZ();
        if (bx == from.getBlockX() && bz == from.getBlockZ()) return; // head turns, jumps, same-block moves: the vast majority of events
        if (!to.getWorld().equals(world)) return;
        final Player p = e.getPlayer();
        if (mayBeAt(p, bx, bz)) return;
        Location back = from.clone();
        back.setYaw(to.getYaw());
        back.setPitch(to.getPitch());
        e.setTo(back);
        p.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
        warnBoundary(p);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTeleportBoundary(PlayerTeleportEvent e) {
        final Location to = e.getTo();
        if (to == null || !to.getWorld().equals(world)) return;
        final Player p = e.getPlayer();
        final int bx = to.getBlockX(), bz = to.getBlockZ();
        final UUID here = chunkOwners.get(chunkKey(bx >> 4, bz >> 4)); // one lookup for both checks
        if (!mayBeAt(p, bx, bz, here)) {
            e.setCancelled(true);
            warnBoundary(p);
            return;
        }
        if (p.getUniqueId().equals(here))
            visiting.remove(p.getUniqueId()); // back on own island
    }

    /** Merged into fastTick(). Kept as an empty stub only so globalTick() still compiles; delete it together with its call there. */
    void boundaryTick() {
    }

    UUID ownerAt(Block b) {
        return chunkOwners.get(chunkKey(b.getX() >> 4, b.getZ() >> 4));
    }

    // ------------------------------------------------------------------ redstone is disabled on the whole server
    static final Set<Material> REDSTONE_BLOCKS = new HashSet<>();

    static {
        Collections.addAll(REDSTONE_BLOCKS, Material.REDSTONE_WIRE, Material.REDSTONE, Material.REDSTONE_TORCH, Material.REDSTONE_WALL_TORCH,
                Material.REDSTONE_BLOCK, Material.REDSTONE_LAMP, Material.REPEATER, Material.COMPARATOR, Material.LEVER,
                Material.OBSERVER, Material.PISTON, Material.STICKY_PISTON, Material.DROPPER, Material.DISPENSER, Material.CRAFTER,
                Material.TARGET, Material.TRIPWIRE_HOOK, Material.DAYLIGHT_DETECTOR, Material.SCULK_SENSOR, Material.CALIBRATED_SCULK_SENSOR,
                Material.POWERED_RAIL, Material.DETECTOR_RAIL, Material.ACTIVATOR_RAIL, Material.TRAPPED_CHEST);
        REDSTONE_BLOCKS.addAll(org.bukkit.Tag.BUTTONS.getValues());
        REDSTONE_BLOCKS.addAll(org.bukkit.Tag.PRESSURE_PLATES.getValues());
    }

    /** Redstone components can't be placed anywhere. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onRedstonePlace(BlockPlaceEvent e) {
        if (!REDSTONE_BLOCKS.contains(e.getBlockPlaced().getType())) return;
        e.setCancelled(true);
        msg(e.getPlayer(), "&cRedstone is disabled on this server.");
    }

    /** Every redstone signal is forced off, so nothing can be powered. */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRedstone(BlockRedstoneEvent e) {
        if (e.getNewCurrent() != 0) e.setNewCurrent(0);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDispense(BlockDispenseEvent e) {
        e.setCancelled(true);
    }

    // ------------------------------------------------------------------ /options
    /** The options that are notifications: they only show while the master "All Notifications" switch is on. */
    static final Set<String> NOTIF_IDS = Set.of("daymsg", "rewards", "dailybonus", "tokens", "failday", "rebirthready", "rebirthmsg",
            "rankmsg", "broadcasts", "autosubmit", "actionbar", "warnings", "lagmsg", "purchasemsg");

    void buildOptions() {
        options.add(new Opt("notifications", "&c&lAll Notifications", Material.BELL, "Master switch. Turn it off to hide every automatic notification below - they only show while this is on. Discord messages still show."));
        options.add(new Opt("daymsg", "&aDay Complete Message", Material.WRITABLE_BOOK, "Chat message when you finish a day (e.g. Day 5 complete!). Off by default.", true));
        options.add(new Opt("rewards", "&6Day Reward Messages", Material.GOLD_INGOT, "Chat message with the reward you get for passing a new day."));
        options.add(new Opt("dailybonus", "&6Daily Bonus Messages", Material.EXPERIENCE_BOTTLE, "Chat message for the free Bonus Drop and Coin Boost levels from new days."));
        options.add(new Opt("tokens", "&6Cane Token Messages", Material.GOLD_NUGGET, "Chat message when you earn a Cane Token (every new day from Day 35 on, and every 1000 rebirths)."));
        options.add(new Opt("failday", "&cDay Failed Message", Material.SKELETON_SKULL, "Chat message when the timer runs out and you fall back to Day 1."));
        options.add(new Opt("rebirthready", "&dRebirth Ready Message", Material.NETHER_STAR, "Chat message when you reach the day where you can rebirth."));
        options.add(new Opt("rebirthmsg", "&dAuto Rebirth Messages", Material.ENDER_PEARL, "Chat messages when Auto Rebirth rebirths you. A manual /rebirth always shows its messages."));
        options.add(new Opt("rankmsg", "&bRank Earned Message", Material.NAME_TAG, "Chat message when you earn a new playtime rank."));
        options.add(new Opt("broadcasts", "&bServer Announcements", Material.GOAT_HORN, "Server-wide chat announcements, like other players earning ranks or buying the Femboy rank."));
        options.add(new Opt("purchasemsg", "&aPurchase Messages", Material.EMERALD, "Chat message when you buy something in /caneshop or /tokenshop (what you bought, the price and the next price)."));
        options.add(new Opt("autosubmit", "&6Auto Sell Messages", Material.CHEST, "Chat summary (at most every 5 minutes) of the cane and coins from all your Cane Cores."));
        options.add(new Opt("actionbar", "&eAction Bar", Material.OAK_SIGN, "Day, quota and timer shown above your hotbar."));
        options.add(new Opt("warnings", "&cTimer Warnings", Material.CLOCK, "Chat warnings at 5:00, 1:00 and 0:10 left."));
        options.add(new Opt("lagmsg", "&eLag Remover Notice", Material.HOPPER, "Chat message when the lag remover clears old dropped items on your island."));
        options.add(new Opt("scoreboard", "&aScoreboard", Material.PAINTING, "The sidebar with your balance, rank, cane placed and /canetop position."));
        options.add(new Opt("sounds", "&bSound Effects", Material.NOTE_BLOCK, "Sounds for completed days, rewards and purchases."));
        options.add(new Opt("stopwater", "&9Stop Water Flow", Material.WATER_BUCKET, "When ON, water on your island never flows or spreads in any direction - every water block stays exactly where you put it. Off by default.", true));
        options.add(new Opt("stopcane", "&2Stop Sugar Cane Growth", Material.SUGAR_CANE, "When ON, the sugar cane on your island stops growing (and your Cane Cores earn nothing while it is stopped). Off by default.", true));
        options.add(new Opt("bedrock", "&8Bedrock Layer", Material.BEDROCK, "Left-click adds a bedrock floor (Y 64, like the starter island) to every chunk you own - it only fills empty spots. Right-click removes the bedrock at Y 64 from every chunk you own (the block under your island spawn stays so you don't fall). Anything else you built stays.", false, true));
    }

    /** Options menu: 7 per row in the four rows under the top border (slots 10-16, 19-25, 28-34, 37-43). */
    static int optSlot(int i) {
        return 10 + i + 2 * (i / 7);
    }

    static int optIndex(int slot) {
        int row = slot / 9, col = slot % 9;
        if (row < 1 || row > 4 || col < 1 || col > 7) return -1;
        return (row - 1) * 7 + (col - 1);
    }

    void fillOptions(Inventory inv, PD d) {
        inv.clear();
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        for (int i = 0; i < options.size() && i < 28; i++) {
            Opt o = options.get(i);
            ItemStack it = new ItemStack(o.icon);
            ItemMeta im = it.getItemMeta();
            im.displayName(txt(o.name));
            List<Component> lore = new ArrayList<>();
            lore.add(txt("&7" + o.desc));
            lore.add(txt(" "));
            if (o.action) {
                lore.add(txt("&eLeft-click: add bedrock"));
                lore.add(txt("&eRight-click: remove bedrock"));
            } else {
                boolean on = o.defOff ? d.off.contains(o.id) : d.on(o.id);
                lore.add(txt(on ? "&aEnabled" : "&cDisabled"));
                if (NOTIF_IDS.contains(o.id) && !notif(d)) lore.add(txt("&8Hidden while All Notifications is off"));
                lore.add(txt("&eClick to toggle"));
                if (on) im.setEnchantmentGlintOverride(true);
            }
            im.lore(lore);
            it.setItemMeta(im);
            inv.setItem(optSlot(i), it);
        }
    }

    void openOptions(Player p, PD d) {
        OptionsHolder h = new OptionsHolder();
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lCane Options"));
        h.inv = inv;
        fillOptions(inv, d);
        p.openInventory(inv);
    }

    /** Adds a bedrock block at Y 64 to every empty spot of every chunk the player owns (nothing that exists is replaced). */
    void fillBedrock(Player p, PD d) {
        if (islandResetting.contains(d.id)) {
            msg(p, "&cYour island is being reset - try again in a moment.");
            return;
        }
        int placed = 0;
        for (int[] c : chunksOf(d)) {
            world.getChunkAt(c[0], c[1]);
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    Block b = world.getBlockAt(c[0] * 16 + lx, 64, c[1] * 16 + lz);
                    if (!b.getType().isAir()) continue;
                    b.setType(Material.BEDROCK, false);
                    placed++;
                }
            }
        }
        dirty = true;
        if (placed == 0) msg(p, "&eAll your chunks already have no empty spots at Y 64 - nothing to fill.");
        else msg(p, "&aAdded &e" + fmt((long) placed) + " &abedrock block(s) at Y 64 across your &e" + chunksOf(d).size() + " &aowned chunk(s).");
    }

    /** Removes the bedrock at Y 64 from every owned chunk. The block under the island spawn is kept so players never lose their floor. */
    void removeBedrock(Player p, PD d) {
        if (islandResetting.contains(d.id)) {
            msg(p, "&cYour island is being reset - try again in a moment.");
            return;
        }
        Location sp = home(d);
        int keepX = sp.getBlockX(), keepZ = sp.getBlockZ();
        int removed = 0;
        for (int[] c : chunksOf(d)) {
            world.getChunkAt(c[0], c[1]);
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    int x = c[0] * 16 + lx, z = c[1] * 16 + lz;
                    if (x == keepX && z == keepZ) continue;
                    Block b = world.getBlockAt(x, 64, z);
                    if (b.getType() != Material.BEDROCK) continue;
                    b.setType(Material.AIR, false);
                    removed++;
                }
            }
        }
        dirty = true;
        if (removed == 0) msg(p, "&eThere is no bedrock at Y 64 in your chunks - nothing to remove.");
        else msg(p, "&aRemoved &e" + fmt((long) removed) + " &abedrock block(s) at Y 64 across your &e" + chunksOf(d).size() + " &aowned chunk(s). &7The block under your spawn stays.");
    }

    @EventHandler
    public void onOptionsClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof OptionsHolder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int i = optIndex(e.getRawSlot());
        if (i < 0 || i >= options.size()) return;
        Opt o = options.get(i);
        if (o.action) {
            if (o.id.equals("bedrock")) {
                if (e.isRightClick()) removeBedrock(p, d);
                else fillBedrock(p, d);
            }
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1f);
            return;
        }
        if (!d.off.remove(o.id)) d.off.add(o.id);
        dirty = true;
        if (o.id.equals("scoreboard") && !d.on("scoreboard")) removeBoard(p);
        fillOptions(top, d);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1f);
    }

    // ------------------------------------------------------------------ shop commands: /autocaneday, /daytoggle
    void cmdAutoDay(Player p, PD d) {
        if (d.lvl("autoday") < 1) {
            msg(p, "&cBuy &dAuto Day &cin &e/caneshop &cfirst!");
            return;
        }
        d.autoDayOn = !d.autoDayOn;
        dirty = true;
        if (d.autoDayOn) {
            msg(p, "&aAuto Day &2enabled&a. The next day starts as soon as you finish the current one.");
            if (d.completed) nextDay(d, p); // today is already done - move on right away
        } else {
            msg(p, "&cAuto Day disabled. &7Use &e/caneday &7to move on manually.");
        }
    }

    /** 0 = normal cycle, 1 = always day, 2 = always night (exactly the old if/else, as a number). */
    int timeStateOf(Player p, PD d) {
        if (d.timeMode == 0 || d.lvl("daytoggle") < 1 || !p.getWorld().equals(world)) return 0;
        return d.timeMode == 1 ? 1 : 2;
    }

    void sendTime(Player p, int state) {
        if (state == 0) p.resetPlayerTime();
        else p.setPlayerTime(state == 1 ? 6000L : 18000L, false);
        PerkState s = perkOf(p);
        s.timeState = state;
        s.timeAt = System.currentTimeMillis();
    }

    /** Forced send - used by join / respawn / /daytoggle, same behaviour as before. */
    void applyTime(Player p, PD d) {
        sendTime(p, timeStateOf(p, d));
    }

    /** Used by perkTick: only talks to the client when the wanted state changed (plus a 60 s safety resync). */
    void applyTimeIfChanged(Player p, PD d, long now) {
        int want = timeStateOf(p, d);
        PerkState s = perkOf(p);
        if (s.timeState == want && now - s.timeAt < TIME_RESYNC_MS) return;
        sendTime(p, want);
    }

    void cmdDayToggle(Player p, PD d, String[] a) {
        if (d.lvl("daytoggle") < 1) {
            msg(p, "&cBuy &eDay / Night Control &cin &e/caneshop &cfirst!");
            return;
        }
        if (a.length > 0 && a[0].equalsIgnoreCase("reset")) {
            d.timeMode = 0;
            msg(p, "&aYour island time is back to the normal day/night cycle.");
        } else {
            d.timeMode = d.timeMode == 1 ? 2 : 1;
            msg(p, d.timeMode == 1 ? "&eYour island is now always &6day&e." : "&9Your island is now always &1night&9.");
        }
        dirty = true;
        applyTime(p, d);
    }

    // ------------------------------------------------------------------ /is (visit / trust) and ground-item protection
    PD findPD(String name) {
        for (PD x : players.values()) if (x.name.equalsIgnoreCase(name)) return x;
        return null;
    }

    void cmdIs(Player p, PD d, String[] a) {
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "visit", "v" -> {
                if (a.length < 2) {
                    msg(p, "&cUsage: &e/is visit <player>");
                    return;
                }
                PD t = findPD(a[1]);
                if (t == null) {
                    msg(p, "&cNo island found for &e" + a[1] + "&c.");
                    return;
                }
                if (t.id.equals(d.id)) {
                    msg(p, "&cThat's your own island! Use &e/canehome&c.");
                    return;
                }
                visiting.put(p.getUniqueId(), t.id);
                if (!p.teleport(home(t))) {
                    visiting.remove(p.getUniqueId());
                    return;
                }
                if (t.trusted.contains(d.id))
                    msg(p, "&aVisiting &e" + t.name + "&a's island. &7They trust you, so you can build here. Use &e/canehome &7to leave.");
                else
                    msg(p, "&aVisiting &e" + t.name + "&a's island. &7You can look around but not build unless they run &e/is trust " + p.getName() + "&7. Use &e/canehome &7to leave.");
                Player owner = Bukkit.getPlayer(t.id);
                if (owner != null) msg(owner, "&e" + p.getName() + " &7is visiting your island.");
            }
            case "trust" -> {
                if (a.length < 2) {
                    msg(p, "&cUsage: &e/is trust <player>");
                    return;
                }
                PD t = findPD(a[1]);
                if (t == null) {
                    msg(p, "&cNo player named &e" + a[1] + " &cwith an island found (they must have used /start).");
                    return;
                }
                if (t.id.equals(d.id)) {
                    msg(p, "&cYou can't trust yourself.");
                    return;
                }
                if (!d.trusted.add(t.id)) {
                    msg(p, "&e" + t.name + " &7is already trusted.");
                    return;
                }
                dirty = true;
                msg(p, "&aYou trusted &e" + t.name + "&a. They can now build and break on your island.");
                Player tp = Bukkit.getPlayer(t.id);
                if (tp != null) msg(tp, "&e" + p.getName() + " &atrusted you! Use &e/is visit " + p.getName() + " &ato go there.");
            }
            case "untrust" -> {
                if (a.length < 2) {
                    msg(p, "&cUsage: &e/is untrust <player>");
                    return;
                }
                PD t = findPD(a[1]);
                if (t == null || !d.trusted.remove(t.id)) {
                    msg(p, "&cThat player isn't trusted on your island.");
                    return;
                }
                dirty = true;
                msg(p, "&aYou removed trust from &e" + t.name + "&a.");
            }
            case "trusted", "list" -> {
                List<String> names = new ArrayList<>();
                for (UUID u : d.trusted) {
                    PD t = players.get(u);
                    if (t != null) names.add(t.name);
                }
                msg(p, names.isEmpty() ? "&7You haven't trusted anyone." : "&eTrusted: &f" + String.join(", ", names));
            }
            case "home" -> {
                p.teleport(home(d));
                msg(p, "&aWelcome home!");
            }
            case "setspawn" -> cmdSetSpawn(p, d);
            case "reset" -> cmdIslandReset(p, d, a);
            default -> {
                p.sendMessage(txt("&6&l=== Island Commands ==="));
                p.sendMessage(txt("&e/is reset &7- wipe ONLY your island (progress is kept)"));
                p.sendMessage(txt("&e/is visit <player> &7- visit someone's island"));
                p.sendMessage(txt("&e/is trust <player> &7- let them build on yours"));
                p.sendMessage(txt("&e/is untrust <player> &7- remove their access"));
                p.sendMessage(txt("&e/is trusted &7- list trusted players"));
                p.sendMessage(txt("&e/is home &7- go back to your island"));
                p.sendMessage(txt("&e/is setspawn &7- set your island spawn to where you stand"));
            }
        }
    }

    /** /is setspawn - the spot you stand on becomes your island spawn (/canehome, /is home, respawn, /start). Must be inside your own chunks. */
    void cmdSetSpawn(Player p, PD d) {
        Location l = p.getLocation();
        if (!l.getWorld().equals(world) || !d.id.equals(chunkOwners.get(chunkKey(l.getBlockX() >> 4, l.getBlockZ() >> 4)))) {
            msg(p, "&cYou can only set your spawn inside your own island chunks.");
            return;
        }
        if (islandResetting.contains(d.id)) {
            msg(p, "&cYour island is being reset - try again in a moment.");
            return;
        }
        d.hasSpawn = true;
        d.spawnX = l.getBlockX() + 0.5;
        d.spawnY = l.getY();
        d.spawnZ = l.getBlockZ() + 0.5;
        d.spawnYaw = l.getYaw();
        d.spawnPitch = l.getPitch();
        dirty = true;
        msg(p, "&aIsland spawn set to &e" + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() + "&a. &7/canehome and respawning now bring you here.");
    }

    /** /is reset - wipes every block on the player's island but keeps all progress, coins, shop upgrades and unlocked chunks. */
    void cmdIslandReset(Player p, PD d, String[] a) {
        long now = System.currentTimeMillis();
        if (a.length > 1 && a[1].equalsIgnoreCase("confirm")) {
            Long t = islandResetConfirm.remove(p.getUniqueId());
            if (t == null || now - t > 30000) {
                msg(p, "&cNothing to confirm. Type &e/is reset &cfirst.");
                return;
            }
            doIslandReset(p, d);
            return;
        }
        islandResetConfirm.put(p.getUniqueId(), now);
        msg(p, "&c&lWARNING: &cThis wipes your whole island and everything built on it (all your chunks), including placed Cane Cores, and Chunk Hoppers. They are NOT returned.");
        msg(p, "&7Your coins, shop upgrades, inventory, rebirth, days and unlocked chunks are &akept&7.");
        msg(p, "&cThis cannot be undone. Type &e/is reset confirm &cwithin 30 seconds to continue.");
    }

    void doIslandReset(Player p, PD d) {
        if (!islandResetting.add(d.id)) {
            msg(p, "&cYour island is already being reset - give it a moment.");
            return;
        }
        // send visitors home
        for (Map.Entry<UUID, UUID> en : new ArrayList<>(visiting.entrySet())) {
            if (!en.getValue().equals(d.id)) continue;
            visiting.remove(en.getKey());
            Player v = Bukkit.getPlayer(en.getKey());
            if (v == null) continue;
            PD vd = players.get(v.getUniqueId());
            v.teleport(vd != null ? home(vd) : Bukkit.getWorlds().get(0).getSpawnLocation());
            msg(v, "&cThis island was reset by its owner.");
        }
        final List<int[]> chunks = chunksOf(d);
        final List<int[]> area = fullArea(d);
        final Set<Long> islandChunks = new HashSet<>();
        for (int[] c : area) islandChunks.add(chunkKey(c[0], c[1]));
        // everything that was on the island goes with it: Auto Sell collectors and Chunk Hoppers
        // are gone for good - nothing is handed back, so Auto Sell income / cane placed drop to 0
        specials.values().removeIf(sp -> d.id.equals(sp.owner) || islandChunks.contains(chunkKey(sp.x >> 4, sp.z >> 4)));
        for (int[] c : area) chunkStalks.remove(chunkKey(c[0], c[1]));
        stalkCache.remove(d.id);
        autoSubWindow.remove(d.id);
        d.lastSim = 0;
        d.carry = 0;
        d.hasSpawn = false; // the island is wiped, so the custom spawn goes too
        p.teleport(home(d));
        dirty = true;
        msg(p, "&eWiping your island...");
        final UUID pid = p.getUniqueId();
        final int[] idx = {0};
        new BukkitRunnable() {
            @Override
            public void run() {
                if (idx[0] >= area.size()) {
                    buildBedrockLayer(chunks.get(0)[0], chunks.get(0)[1]);
                    for (int[] c2 : area) chunkStalks.remove(chunkKey(c2[0], c2[1]));
                    stalkCache.remove(d.id);
                    d.lastSim = 0;
                    d.carry = 0;
                    islandResetting.remove(d.id);
                    dirty = true;
                    saveData();
                    Player pl = Bukkit.getPlayer(pid);
                    if (pl != null) {
                        pl.teleport(home(d));
                        msg(pl, "&a&lYour island was reset! &7Everything on it is gone (Cane Cores, hoppers, chests, cane). Your coins, upgrades, inventory, rebirth, days and chunks were kept.");
                    }
                    cancel();
                    return;
                }
                int[] c = area.get(idx[0]++);
                clearChunk(c[0], c[1]);
            }
        }.runTaskTimer(CaneIslands.this, 1L, 1L);
    }

    /** Players can't pick up items lying on someone else's island (stops trusted players stealing cane). */
    @EventHandler(ignoreCancelled = true)
    public void onPickupOnOthers(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Location l = e.getItem().getLocation();
        if (!l.getWorld().equals(world) || p.hasPermission("caneislands.admin")) return;
        UUID o = chunkOwners.get(chunkKey(l.getBlockX() >> 4, l.getBlockZ() >> 4));
        if (o != null && !o.equals(p.getUniqueId())) e.setCancelled(true);
    }

    /** NEW handler: saves playtime after a quit (debounced in globalTick) and drops the player's action-bar cache. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuitPlaytime(PlayerQuitEvent e) {
        lastBar.remove(e.getPlayer().getUniqueId());
        if (playDirty) quitSaveDue = true;
    }

    @EventHandler
    public void onQuitCleanup(PlayerQuitEvent e) {
        pouchCooldown.remove(e.getPlayer().getUniqueId());
        clipboards.remove(e.getPlayer().getUniqueId());
        wandPreviewShown.remove(e.getPlayer().getUniqueId());
        wandPreviewKey.remove(e.getPlayer().getUniqueId());
        UUID id = e.getPlayer().getUniqueId();
        visiting.remove(id);
        resetConfirm.remove(id);
        islandResetConfirm.remove(id);
        chunkBorders.remove(id);
        rebirthConfirm.remove(id);
        boundaryWarned.remove(id);
        autoSubWindow.remove(id);
        spongeJobs.remove(id);
        boards.remove(id);
        stalkCache.remove(id);
    }

    // ------------------------------------------------------------------ /reset
    void cmdReset(Player p, PD d, String[] a) {
        long now = System.currentTimeMillis();
        if (a.length > 0 && a[0].equalsIgnoreCase("confirm")) {
            Long t = resetConfirm.remove(p.getUniqueId());
            if (t == null || now - t > 30000) {
                msg(p, "&cNothing to confirm. Type &e/reset &cfirst.");
                return;
            }
            doReset(p, d);
            return;
        }
        resetConfirm.put(p.getUniqueId(), now);
        msg(p, "&c&lWARNING: &cThis wipes EVERYTHING - day, best day, coins, shop upgrades, rewards, ranks, playtime, tokens + token shop items, extra chunks, your whole island (and everything built on it) and your inventory + ender chest.");
        msg(p, "&cThis cannot be undone. Type &e/reset confirm &cwithin 30 seconds to continue.");
    }

    void doReset(Player p, PD d) {
        // send visitors home
        for (Map.Entry<UUID, UUID> en : new ArrayList<>(visiting.entrySet())) {
            if (!en.getValue().equals(d.id)) continue;
            visiting.remove(en.getKey());
            Player v = Bukkit.getPlayer(en.getKey());
            if (v == null) continue;
            PD vd = players.get(v.getUniqueId());
            v.teleport(vd != null ? home(vd) : Bukkit.getWorlds().get(0).getSpawnLocation());
            msg(v, "&cThis island was reset by its owner.");
        }
        // forget special blocks + extra chunks
        List<int[]> chunks = chunksOf(d);
        final List<int[]> area = fullArea(d); // owned chunks + the ones they could still buy
        final Set<Long> islandChunks = new HashSet<>();
        for (int[] c : area) islandChunks.add(chunkKey(c[0], c[1]));
        specials.values().removeIf(sp -> d.id.equals(sp.owner) || islandChunks.contains(chunkKey(sp.x >> 4, sp.z >> 4)));
        d.lastSim = 0;
        d.carry = 0;
        for (int i = 1; i < chunks.size(); i++) chunkOwners.remove(chunkKey(chunks.get(i)[0], chunks.get(i)[1]));
        // reset progress
        d.extra = 0;
        d.day = 1;
        d.bestDay = 0;
        d.runBest = 1;
        d.submitted = 0;
        d.totalCane = 0;
        d.rebirths = 0;
        d.lastRebirth = 0;
        d.fastStreak = 0;
        d.autoRebirth = false;
        d.completed = false;
        d.coins = 0;
        d.rewardGrowth = 0;
        d.rewardTime = 0;
        d.rewardDrop = 0;
        d.rewardSell = 0;
        if ((d.rankTier > 0 || d.owned.contains("rank_femboy")) && lpAvailable()) {
            try {
                List<String> rg = new ArrayList<>(tierGroups());
                rg.add(FEMBOY_GROUP);
                LuckPermsHook.revokeAll(d.id, rg, getLogger());
            } catch (Throwable ex) {
                getLogger().warning("Could not remove the LuckPerms rank: " + ex);
            }
        }
        d.rankTier = 0;
        d.playMs = 0;
        d.tokens = 0;
        d.owned.clear();
        { Player rp = Bukkit.getPlayer(d.id); if (rp != null && rp.getGameMode() == GameMode.CREATIVE) rp.setGameMode(GameMode.SURVIVAL); }
        d.activeTag = "";
        d.activeName = "";
        d.activeSellFx = "";
        d.off.remove("femboy");
        d.flyOwned = false;
        d.flyOn = false;
        d.autoDayOn = false;
        d.timeMode = 0;
        d.hasSpawn = false;
        d.bought.clear();
        d.priceBase.clear(); // back to base prices
        d.off.removeIf(k -> k.startsWith("fx_"));
        d.pending.clear();
        d.trusted.clear();
        d.timeLeft = timeFor(d);
        stalkCache.remove(d.id);
        // reset the player
        p.teleport(home(d));
        p.getInventory().clear();
        p.getEnderChest().clear();
        for (PotionEffect pe : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(pe.getType());
        if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
        p.resetPlayerTime();
        // wipe EVERY block of the whole expandable island area (owned chunks AND the chunks they could still buy), all heights, pouch-placed blocks, water, light blocks...
        // right now, then give the home chunk its bedrock floor back
        for (int[] c : area) clearChunk(c[0], c[1]);
        buildBedrockLayer(chunks.get(0)[0], chunks.get(0)[1]);
        giveStarterKit(p);
        dirty = true;
        saveData();
        msg(p, "&a&lYour progress was reset! &7You're back on Day 1 with a fresh island.");
        msg(p, "&7You keep &bInfinite Dirt&7, &e64 sugar cane&7, an &bInfinite Water Bucket &7and a &6Cane Core &7on a fresh bedrock chunk.");
        msg(p, "&7Day 1 needs &e1 &7cane. You have &e" + mmss(d.timeLeft) + " &7per day.");
    }

    /** Removes every block (any height) and every non-player entity in the chunk. */
    void clearChunk(int cx, int cz) {
        if (!world.isChunkGenerated(cx, cz)) return; // never touched: nothing to remove
        org.bukkit.Chunk ch = world.getChunkAt(cx, cz);
        for (Entity en : ch.getEntities()) if (!(en instanceof Player)) en.remove();
        ChunkSnapshot snap = ch.getChunkSnapshot(false, false, false);
        int minY = world.getMinHeight(), maxY = world.getMaxHeight();
        for (int y = minY; y < maxY; y++) {
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    if (snap.getBlockType(lx, y, lz).isAir()) continue;
                    world.getBlockAt(cx * 16 + lx, y, cz * 16 + lz).setType(Material.AIR, false);
                }
            }
        }
    }

    // ------------------------------------------------------------------ commands
    @SuppressWarnings("unused")
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if (n.equals("caneadmin")) return admin(s, a);
        if (!(s instanceof Player p)) {
            s.sendMessage("Players only.");
            return true;
        }
        if (n.equals("discord")) { // works for everyone, even before /start
            p.sendMessage(discordMessage());
            return true;
        }
        if (n.equals("commands")) {
            if (a.length > 0 && a[0].equalsIgnoreCase("list")) cmdCommands(p);
            else openCommands(p);
            return true;
        }
        PD d = players.get(p.getUniqueId());
        if (n.equals("start")) {
            cmdStart(p, d);
            return true;
        }
        if (d == null) {
            msg(p, "&cYou don't have an island yet. Use &e/start&c!");
            return true;
        }
        switch (n) {
            case "canehome" -> {
                p.teleport(home(d));
                msg(p, "&aWelcome home!");
            }
            case "sell" -> cmdSell(p, d);
            case "caneday" -> cmdDay(p, d);
            case "caneinfo" -> cmdInfo(p, d);
            case "canerewards" -> cmdRewards(p, d);
            case "canetop" -> cmdTop(p);
            case "caneshop" -> openShop(p, d, 0);
            case "isfly" -> cmdFly(p, d);
            case "options" -> openOptions(p, d);
            case "autocaneday" -> cmdAutoDay(p, d);
            case "daytoggle" -> cmdDayToggle(p, d, a);
            case "is" -> cmdIs(p, d, a);
            case "reset" -> cmdReset(p, d, a);
            case "rebirth" -> cmdRebirth(p, d, a);
            case "autorebirth" -> cmdAutoRebirth(p, d);
            case "lightblock" -> cmdLightBlock(p, d, a);
            case "removesponge" -> cmdRemoveSponge(p, d);
            case "drain" -> cmdDrain(p);
            case "chunkmanagement" -> openChunkManagement(p, d);
            case "pay" -> cmdPay(p, d, a);
            case "tokenshop" -> openTokenShop(p, d);
            case "tags" -> openEquip(p, d, "&6&lYour Tags", true);
            case "cosmetic" -> openEquip(p, d, "&6&lYour Cosmetics", false);
            case "playtimerewards" -> openPlaytimeRewards(p, d);
            case "undo" -> cmdUndo(p);
            case "wandsettings" -> openWandSettings(p, d);
            default -> {
            }
        }
        return true;
    }

    /** /commands - lists every command with its description, read straight from plugin.yml so it never goes stale. */
    void cmdCommands(Player p) {
        p.sendMessage(txt("&6&l=== Cane Islands Commands ==="));
        p.sendMessage(txt(Credit.LORE));
        for (Map.Entry<String, Map<String, Object>> en : getDescription().getCommands().entrySet()) {
            String name = en.getKey();
            if (name.equals("caneadmin") && !p.hasPermission("caneislands.admin")) continue;
            Map<String, Object> info = en.getValue();
            Object desc = info.get("description");
            Object usage = info.get("usage");
            Object aliases = info.get("aliases");
            String u = usage == null ? "/" + name : usage.toString();
            StringBuilder line = new StringBuilder("&e").append(u).append(" &7- ").append(desc == null ? "" : desc.toString());
            if (aliases instanceof List<?> al && !al.isEmpty()) {
                List<String> as = new ArrayList<>();
                for (Object o : al) as.add("/" + o);
                line.append(" &8(").append(String.join(", ", as)).append(")");
            }
            p.sendMessage(txt(line.toString()));
        }
    }

    // ------------------------------------------------------------------ /pay
    /** Parses 1500, 1.5k, 2m, 3b (case-insensitive). Returns -1 when it is not a valid number. */
    static double parseAmount(String in) {
        String t = in.trim().toLowerCase(Locale.ROOT).replace(",", "");
        double mult = 1;
        if (t.endsWith("k")) mult = 1e3;
        else if (t.endsWith("m")) mult = 1e6;
        else if (t.endsWith("b")) mult = 1e9;
        if (mult != 1) t = t.substring(0, t.length() - 1);
        try {
            double v = Double.parseDouble(t) * mult;
            return Double.isNaN(v) || Double.isInfinite(v) ? -1 : v;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    /** /pay <player> <amount> - sends coins to another player (works for offline players that have an island). */
    static final long PAY_MIN_PLAY_MS = 30 * 60 * 1000L; // the receiver of /pay needs this much playtime

    void cmdPay(Player p, PD d, String[] a) {
        if (a.length < 2) {
            msg(p, "&cUsage: &e/pay <player> <amount>");
            return;
        }
        PD t = findPD(a[0]);
        if (t == null) {
            msg(p, "&cNo player named &e" + a[0] + " &cwith an island found (they must have used /start).");
            return;
        }
        if (t.id.equals(d.id)) {
            msg(p, "&cYou can't pay yourself.");
            return;
        }
        if (t.playMs < PAY_MIN_PLAY_MS) {
            msg(p, "&e" + t.name + " &chas only played &e" + fmtPlay(t.playMs) + "&c. You can only pay players with at least &e30 minutes &cof playtime.");
            return;
        }
        double amt = Math.floor(parseAmount(a[1]));
        if (amt < 1) {
            msg(p, "&cEnter a whole amount of at least 1 coin, e.g. &e/pay " + t.name + " 500 &cor &e1.5k&c.");
            return;
        }
        if (d.coins < amt) {
            msg(p, "&cYou only have &e" + fmt((long) d.coins) + " &ccoins.");
            return;
        }
        d.coins -= amt;
        t.coins += amt;
        dirty = true;
        msg(p, "&aYou paid &e" + fmt((long) amt) + " &acoins to &e" + t.name + "&a.");
        Player tp = Bukkit.getPlayer(t.id);
        if (tp != null) msg(tp, "&e" + p.getName() + " &apaid you &e" + fmt((long) amt) + " &acoins!");
    }

    // ------------------------------------------------------------------ /chunkmanagement
    static final int CM_BORDERS = 47, CM_INFO = 49, CM_BLOCKS = 51;

    void openChunkManagement(Player p, PD d) {
        ChunksHolder h = new ChunksHolder();
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lChunk Management"));
        h.inv = inv;
        fillChunkManagement(inv, p, d);
        p.openInventory(inv);
    }

    void fillChunkManagement(Inventory inv, Player p, PD d) {
        inv.clear();
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        int bx = baseX(d), bz = baseZ(d);
        // 5x5 map of the island area, north (-Z) at the top, east (+X) on the right, in columns 2-6
        for (int dz = -2; dz <= 2; dz++) {
            for (int dx = -2; dx <= 2; dx++) {
                int cx = bx + dx, cz = bz + dz;
                int slot = (dz + 2) * 9 + (dx + 2) + 2;
                int order = -1;
                for (int i = 0; i < ORDER.size(); i++) if (ORDER.get(i)[0] == dx && ORDER.get(i)[1] == dz) order = i;
                ItemStack it;
                if (dx == 0 && dz == 0) {
                    it = named(Material.LIME_CONCRETE, "&a&lHome chunk", "&7Chunk &f" + cx + ", " + cz, "&7Blocks &f" + (cx * 16) + " &7to &f" + (cx * 16 + 15) + "&7, &f" + (cz * 16) + " &7to &f" + (cz * 16 + 15), "&aUnlocked");
                } else if (order >= 0 && order < d.extra) {
                    it = named(Material.GREEN_STAINED_GLASS, "&aChunk #" + (order + 2), "&7Chunk &f" + cx + ", " + cz, "&7Blocks &f" + (cx * 16) + " &7to &f" + (cx * 16 + 15) + "&7, &f" + (cz * 16) + " &7to &f" + (cz * 16 + 15), "&aUnlocked");
                } else {
                    it = named(Material.RED_STAINED_GLASS, "&cLocked chunk", "&7Buy &aNew Chunk &7in &e/caneshop &7to unlock it.");
                }
                inv.setItem(slot, it);
            }
        }
        boolean borders = chunkBorders.contains(p.getUniqueId());
        ItemStack b = named(Material.ENDER_EYE, "&bShow My Chunks",
                "&7Draws particle lines around the chunks you own.",
                "&7Green = edge of your island, aqua = chunk lines.",
                " ", borders ? "&aEnabled" : "&cDisabled", "&eClick to toggle");
        if (borders) {
            ItemMeta im = b.getItemMeta();
            im.setEnchantmentGlintOverride(true);
            b.setItemMeta(im);
        }
        inv.setItem(CM_BORDERS, b);
        boolean blocks = d.on("chunkblocks");
        ItemStack t = named(blocks ? Material.GRASS_BLOCK : Material.GLASS, "&6New Chunks Have Blocks",
                "&7When &aON&7, newly unlocked chunks come with the", "&7dirt and water layout like the starter island.",
                "&7When &cOFF&7, you only get the chunk and building", "&7permission - no blocks are placed.",
                " ", blocks ? "&aEnabled" : "&cDisabled", "&eClick to toggle");
        if (blocks) {
            ItemMeta im = t.getItemMeta();
            im.setEnchantmentGlintOverride(true);
            t.setItemMeta(im);
        }
        inv.setItem(CM_BLOCKS, t);
        inv.setItem(CM_INFO, named(Material.FILLED_MAP, "&6Your chunks", "&7Unlocked: &f" + (d.extra + 1) + "&7/" + (ORDER.size() + 1), "&8North is up, east is right."));
    }

    @EventHandler
    public void onChunkManagementClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof ChunksHolder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PD d = players.get(p.getUniqueId());
        if (d == null) return;
        int slot = e.getRawSlot();
        if (slot == CM_BORDERS) {
            if (!chunkBorders.remove(p.getUniqueId())) chunkBorders.add(p.getUniqueId());
        } else if (slot == CM_BLOCKS) {
            if (!d.off.remove("chunkblocks")) d.off.add("chunkblocks");
            dirty = true;
        } else return;
        fillChunkManagement(top, p, d);
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1f);
    }

    // ---- chunk border particles ----
    static final Particle.DustOptions CB_OUTER = new Particle.DustOptions(org.bukkit.Color.fromRGB(60, 255, 60), 1.3f);
    static final Particle.DustOptions CB_INNER = new Particle.DustOptions(org.bukkit.Color.fromRGB(80, 220, 255), 0.8f);
    static final double CB_RANGE = 32.0;      // the client does not draw non-forced particles farther than 32 blocks
    static final double CB_RANGE_SQ = 1008.0; // 32^2 minus ~4 blocks of height difference, compared on the flat distance
    static final boolean CB_ALT_LAYERS = true; // true: edge points alternate between the 2 heights (half the packets). false: both heights like before

    static final class CbCache {
        int slot = Integer.MIN_VALUE, extra = -1;
        int[][] chunks;   // the owned chunks
        long[] keys;      // their chunk keys, sorted (binary search = no HashSet, no boxing)
    }

    final Map<UUID, CbCache> cbCache = new HashMap<>();

    static boolean cbMine(long[] keys, int cx, int cz) {
        return java.util.Arrays.binarySearch(keys, chunkKey(cx, cz)) >= 0;
    }

    /** Draws particle lines (only the viewer sees them) around the player's own chunks while the toggle is on. */
    void chunkBorderTick() {
        if (chunkBorders.isEmpty()) {
            if (!cbCache.isEmpty()) cbCache.clear();
            return;
        }
        if (cbCache.size() > chunkBorders.size()) cbCache.keySet().retainAll(chunkBorders);
        for (java.util.Iterator<UUID> it = chunkBorders.iterator(); it.hasNext(); ) {
            UUID id = it.next();
            Player p = Bukkit.getPlayer(id);
            PD d = players.get(id);
            if (p == null || d == null) {
                it.remove();
                cbCache.remove(id);
                continue;
            }
            if (!p.getWorld().equals(world)) continue;
            CbCache cc = cbCache.get(id);
            if (cc == null) {
                cc = new CbCache();
                cbCache.put(id, cc);
            }
            if (cc.chunks == null || cc.slot != d.slot || cc.extra != d.extra) { // rebuilt only when the island layout changed
                List<int[]> list = chunksOf(d);
                cc.chunks = list.toArray(new int[0][]);
                long[] ks = new long[cc.chunks.length];
                for (int i = 0; i < ks.length; i++) ks[i] = chunkKey(cc.chunks[i][0], cc.chunks[i][1]);
                java.util.Arrays.sort(ks);
                cc.keys = ks;
                cc.slot = d.slot;
                cc.extra = d.extra;
            }
            final long[] keys = cc.keys;
            Location pl = p.getLocation();
            final double px = pl.getX(), pz = pl.getZ(), py = pl.getY();
            final double yLow = py + 0.3, yHigh = py + 1.7;
            for (int[] c : cc.chunks) {
                double x0 = c[0] * 16, z0 = c[1] * 16, x1 = x0 + 16, z1 = z0 + 16;
                if (x1 < px - CB_RANGE || x0 > px + CB_RANGE || z1 < pz - CB_RANGE || z0 > pz + CB_RANGE) continue;
                // sides: 0 = north, 1 = south, 2 = west, 3 = east
                for (int side = 0; side < 4; side++) {
                    int nx = c[0] + (side == 2 ? -1 : side == 3 ? 1 : 0), nz = c[1] + (side == 0 ? -1 : side == 1 ? 1 : 0);
                    boolean neighbourMine = cbMine(keys, nx, nz);
                    if (neighbourMine && (side == 0 || side == 2)) continue; // that line is drawn by the neighbour
                    Particle.DustOptions opt = neighbourMine ? CB_INNER : CB_OUTER;
                    int step = neighbourMine ? 4 : 2;
                    int n = 0;
                    for (int t = 0; t <= 16; t += step, n++) {
                        double x = side < 2 ? x0 + t : (side == 2 ? x0 : x1);
                        double z = side < 2 ? (side == 0 ? z0 : z1) : z0 + t;
                        double dx = x - px, dz = z - pz;
                        if (dx * dx + dz * dz > CB_RANGE_SQ) continue;
                        if (CB_ALT_LAYERS) {
                            p.spawnParticle(Particle.DUST, x, (n & 1) == 0 ? yLow : yHigh, z, 1, 0, 0, 0, 0, opt);
                        } else {
                            p.spawnParticle(Particle.DUST, x, yLow, z, 1, 0, 0, 0, 0, opt);
                            p.spawnParticle(Particle.DUST, x, yHigh, z, 1, 0, 0, 0, 0, opt);
                        }
                    }
                }
                // vertical lines on the 4 corners. A corner shared by several of your chunks is drawn once (by the first one in
                // the order (a-1,b-1), (a,b-1), (a-1,b), (a,b)), instead of once per chunk on top of each other.
                for (int k = 0; k < 4; k++) {
                    int a = c[0] + (k & 1), b = c[1] + (k >> 1);
                    boolean first = true;
                    for (int j = 0, mine = 3 - k; j < mine; j++) {
                        if (cbMine(keys, a - 1 + (j & 1), b - 1 + (j >> 1))) {
                            first = false;
                            break;
                        }
                    }
                    if (!first) continue;
                    double kx = a * 16, kz = b * 16;
                    double dx = kx - px, dz = kz - pz;
                    if (dx * dx + dz * dz > CB_RANGE_SQ) continue;
                    for (double y = py - 2; y <= py + 4; y += 1)
                        p.spawnParticle(Particle.DUST, kx, y, kz, 1, 0, 0, 0, 0, CB_OUTER);
                }
            }
        }
    }

    // ------------------------------------------------------------------ /commands GUI
    static Material cmdIcon(String name) {
        return switch (name) {
            case "start" -> Material.GRASS_BLOCK;
            case "canehome" -> Material.RED_BED;
            case "sell" -> Material.SUGAR_CANE;
            case "caneday" -> Material.CLOCK;
            case "caneinfo" -> Material.BOOK;
            case "canerewards" -> Material.CHEST;
            case "canetop" -> Material.NETHER_STAR;
            case "caneshop" -> Material.EMERALD;
            case "isfly" -> Material.FEATHER;
            case "options" -> Material.COMPARATOR;
            case "autocaneday" -> Material.REPEATER;
            case "daytoggle" -> Material.DAYLIGHT_DETECTOR;
            case "is" -> Material.OAK_DOOR;
            case "rebirth" -> Material.TOTEM_OF_UNDYING;
            case "autorebirth" -> Material.ENDER_EYE;
            case "reset" -> Material.TNT;
            case "lightblock" -> Material.GLOWSTONE;
            case "removesponge" -> Material.WET_SPONGE;
            case "drain" -> Material.BUCKET;
            case "chunkmanagement" -> Material.FILLED_MAP;
            case "pay" -> Material.GOLD_INGOT;
            case "discord" -> Material.BLUE_DYE;
            case "tokenshop" -> Material.AMETHYST_SHARD;
            case "tags" -> Material.NAME_TAG;
            case "cosmetic" -> Material.FIREWORK_STAR;
            case "playtimerewards" -> Material.EXPERIENCE_BOTTLE;
            case "undo" -> Material.RECOVERY_COMPASS;
            case "wandsettings" -> Material.BLAZE_ROD;
            case "commands" -> Material.KNOWLEDGE_BOOK;
            case "caneadmin" -> Material.COMMAND_BLOCK;
            default -> Material.PAPER;
        };
    }

    static List<String> wrap(String text, int width) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String w : text.split(" ")) {
            if (line.length() > 0 && line.length() + 1 + w.length() > width) {
                out.add(line.toString());
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(w);
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    /** /commands - a chest menu with every command and what it does (read from plugin.yml, so it never goes stale). */
    void openCommands(Player p) {
        CommandsHolder h = new CommandsHolder();
        Inventory inv = Bukkit.createInventory(h, 54, txt("&6&lCane Commands"));
        h.inv = inv;
        int slot = 0;
        for (Map.Entry<String, Map<String, Object>> en : getDescription().getCommands().entrySet()) {
            String name = en.getKey();
            if (name.equals("caneadmin") && !p.hasPermission("caneislands.admin")) continue;
            if (slot >= 45) break;
            Map<String, Object> info = en.getValue();
            Object desc = info.get("description");
            Object usage = info.get("usage");
            Object aliases = info.get("aliases");
            ItemStack it = new ItemStack(cmdIcon(name));
            ItemMeta im = it.getItemMeta();
            im.displayName(txt("&e" + (usage == null ? "/" + name : usage.toString())));
            List<Component> lore = new ArrayList<>();
            if (desc != null) for (String ln : wrap(desc.toString(), 38)) lore.add(txt("&7" + ln));
            if (aliases instanceof List<?> al && !al.isEmpty()) {
                List<String> as = new ArrayList<>();
                for (Object o : al) as.add("/" + o);
                lore.add(txt(" "));
                lore.add(txt("&8Aliases: " + String.join(", ", as)));
            }
            lore.add(txt(" "));
            lore.add(txt("&aClick to run /" + name));
            im.lore(lore);
            it.setItemMeta(im);
            h.names.add(name);
            inv.setItem(slot++, it);
        }
        ItemStack filler = named(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 45; i < 54; i++) inv.setItem(i, filler);
        inv.setItem(49, named(Material.BOOK, "&6Cane Islands", "&7" + slot + " commands available to you.", "&8Click a command to run it.", Credit.LORE));
        p.openInventory(inv);
    }

    @EventHandler
    public void onCommandsClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof CommandsHolder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || !e.getClickedInventory().equals(top)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getRawSlot();
        if (slot < 0 || slot >= h.names.size()) return;
        final String name = h.names.get(slot);
        if (name.equals("commands")) return; // already in the menu
        // close the menu, then run the command next tick (so GUIs like /caneshop open cleanly)
        getServer().getScheduler().runTask(this, () -> {
            p.closeInventory();
            p.performCommand(name);
        });
    }

    /** Pressing the offhand key (F by default) on the cane islands opens the /commands menu. */
    @EventHandler(ignoreCancelled = true)
    public void onSwapHands(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        if (!p.getWorld().equals(world)) return;
        e.setCancelled(true);
        openCommands(p);
    }

    // ------------------------------------------------------------------ /drain
    /** /drain - removes all water from the chunk the player stands in, on the layer (Y) they stand at only. */
    void cmdDrain(Player p) {
        if (!p.getWorld().equals(world)) {
            msg(p, "&cThis only works on the cane islands.");
            return;
        }
        if (!canBuild(p, p.getLocation())) {
            msg(p, "&cYou can only use this in a chunk of your island (or one that trusts you).");
            return;
        }
        final int cx = p.getLocation().getBlockX() >> 4, cz = p.getLocation().getBlockZ() >> 4;
        final int y = p.getLocation().getBlockY();
        int drained = 0;
        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                Block b = world.getBlockAt(cx * 16 + lx, y, cz * 16 + lz);
                Material t = b.getType();
                if (t == Material.WATER || t == Material.BUBBLE_COLUMN || t == Material.SEAGRASS
                        || t == Material.TALL_SEAGRASS || t == Material.KELP || t == Material.KELP_PLANT) {
                    b.setType(Material.AIR, false);
                    drained++;
                } else if (b.getBlockData() instanceof org.bukkit.block.data.Waterlogged wl && wl.isWaterlogged()) {
                    wl.setWaterlogged(false); // leaves, slabs, stairs, grates... keep the block, lose the water
                    b.setBlockData(wl, false);
                    drained++;
                }
            }
        }
        if (drained == 0) {
            msg(p, "&7There is no water on this layer (Y " + y + ") of this chunk.");
            return;
        }
        p.playSound(p.getLocation(), Sound.ITEM_BUCKET_FILL, 1f, 1f);
        msg(p, "&aDrained &e" + fmt((long) drained) + " &awater block(s) from layer &eY " + y + " &ain this chunk.");
    }

    // ------------------------------------------------------------------ /lightblock
    final Set<Long> lightJobs = new HashSet<>();

    static boolean airish(Block b) {
        Material t = b.getType();
        return t.isAir() || t == Material.LIGHT;
    }

    /** Fills every empty block of the chunk you stand in with a light level 15 block (/lightblock remove undoes it). */
    void cmdLightBlock(Player p, PD d, String[] a) {
        if (!p.getWorld().equals(world)) {
            msg(p, "&cThis only works on the cane islands.");
            return;
        }
        if (!canBuild(p, p.getLocation())) {
            msg(p, "&cYou can only use this in a chunk of your island (or one that trusts you).");
            return;
        }
        final int cx = p.getLocation().getBlockX() >> 4, cz = p.getLocation().getBlockZ() >> 4;
        final long key = chunkKey(cx, cz);
        if (!lightJobs.add(key)) {
            msg(p, "&cThis chunk is already being processed - give it a moment.");
            return;
        }
        final boolean remove = a.length > 0 && a[0].equalsIgnoreCase("remove");
        final int minY = Math.max(world.getMinHeight(), getConfig().getInt("lightblock.min-y"));
        final int maxY = Math.min(world.getMaxHeight() - 1, getConfig().getInt("lightblock.max-y"));
        final UUID pid = p.getUniqueId();
        final org.bukkit.block.data.type.Light lightData = (org.bukkit.block.data.type.Light) Material.LIGHT.createBlockData();
        lightData.setLevel(15);
        msg(p, remove ? "&eRemoving light blocks from this chunk..." : "&eFilling this chunk with light level 15 (Y " + minY + "-" + maxY + ")...");
        final int[] y = {minY};
        final int[] changed = {0};
        getServer().getScheduler().runTaskTimer(this, task -> {
            // two layers per tick so big chunks don't lag the server
            for (int n = 0; n < 2 && y[0] <= maxY; n++, y[0]++) {
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        Block b = world.getBlockAt(cx * 16 + lx, y[0], cz * 16 + lz);
                        if (remove) {
                            if (b.getType() == Material.LIGHT) {
                                b.setType(Material.AIR, false);
                                changed[0]++;
                            }
                        } else if (b.getType().isAir()) {
                            b.setBlockData(lightData, false);
                            changed[0]++;
                        }
                    }
                }
            }
            if (y[0] > maxY) {
                task.cancel();
                lightJobs.remove(key);
                Player on = Bukkit.getPlayer(pid);
                if (on != null)
                    msg(on, remove ? "&aRemoved &e" + fmt((long) changed[0]) + " &alight blocks." : "&aDone! &e" + fmt((long) changed[0]) + " &ablocks now have light level 15. &7(/lightblock remove to undo)");
            }
        }, 1L, 1L);
    }

    void cmdStart(Player p, PD existing) {
        if (existing != null) {
            msg(p, "&cYour &e/start &chas already been used - you get your island automatically when you join. Use &e/canehome &cto go back.");
            return;
        }
        createIsland(p);
    }

    /** Creates a brand new island for the player, gives the starter kit and teleports them there. */
    PD createIsland(Player p) {
        PD d = new PD(p.getUniqueId());
        d.name = p.getName();
        d.slot = nextSlot++;
        d.timeLeft = timeFor(d);
        players.put(d.id, d);
        indexChunks(d);
        buildBedrockLayer(baseX(d), baseZ(d));
        d.breakerGiven = true;
        giveStarterKit(p);
        p.teleport(home(d));
        dirty = true;
        saveData();
        msg(p, "&aYour island is ready! Farm sugar cane, then &e/sell &ato hand it in.");
        msg(p, "&7Day 1 needs &e1 &7cane. Each day doubles. You have &e" + mmss(d.timeLeft) + " &7per day.");
        return d;
    }

    /** Server whisper with the key commands, sent to brand new players. */
    void whisperCommands(Player p) {
        p.sendMessage(txt("&7&o[Server -> You] Welcome to Cane Islands! Useful commands:"));
        p.sendMessage(txt("&7&o[Server -> You] &e/caneshop &7&o- buy upgrades"));
        p.sendMessage(txt("&7&o[Server -> You] &e/sell &7&o- sell your sugar cane"));
        p.sendMessage(txt("&7&o[Server -> You] &e/isfly &7&o- toggle flight"));
        p.sendMessage(txt("&7&o[Server -> You] &e/is help &7&o- visit and trust other islands"));
        p.sendMessage(txt("&7&o[Server -> You] &e/commands &7&o- list every command"));
    }

    void cmdSell(Player p, PD d) {
        long total = 0;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && it.getType() == Material.SUGAR_CANE) {
                total += it.getAmount();
                inv.setItem(i, null);
            }
        }
        if (total == 0) {
            msg(p, "&cYou have no sugar cane in your inventory!");
            return;
        }
        double before = d.coins;
        submit(d, total);
        msg(p, "&aSubmitted &e" + fmt(total) + " &acane! &7(+" + fmt(d.coins - before) + " coins)");
        if (!d.completed) msg(p, "&7Progress: &f" + fmt(d.submitted) + "/" + fmt(required(d.day)) + " &7(Cane Multi &bx" + String.format(Locale.ROOT, "%.2f", caneMulti(d)) + "&7 counted &e" + fmt(countedCane(d, total)) + " &7of it toward the day)");
        playSellFx(p, d);
    }

    void cmdDay(Player p, PD d) {
        if (!d.completed) {
            msg(p, "&cFinish Day " + d.day + " first! &7(" + fmt(d.submitted) + "/" + fmt(required(d.day)) + ", " + mmss(Math.max(0, d.timeLeft)) + " left)");
            return;
        }
        nextDay(d, p);
    }

    void cmdInfo(Player p, PD d) {
        p.sendMessage(txt("&6&l=== Cane Island ==="));
        p.sendMessage(txt(Credit.LORE));
        p.sendMessage(txt("&eDay: &f" + d.day + " &7(best passed: " + d.bestDay + ")"));
        p.sendMessage(txt("&eQuota: &f" + fmt(d.submitted) + "/" + fmt(required(d.day)) + (d.completed ? " &a(complete - /caneday)" : "")));
        if (!d.completed) p.sendMessage(txt("&eTime left: &f" + mmss(Math.max(0, d.timeLeft))));
        p.sendMessage(txt("&eCoins: &f" + fmt(d.coins)));
        p.sendMessage(txt("&ePlaytime: &f" + fmtPlay(d.playMs) + nextRankText(d)));
        p.sendMessage(txt("&eTokens: &6" + d.tokens + " &7(1 per new day from Day 35 on and 1 per 1000 rebirths - spend them in /tokenshop)"));
        p.sendMessage(txt("&eTotal cane submitted: &f" + fmt(d.totalCane)));
        p.sendMessage(txt("&eCane Multi: &bx" + String.format(Locale.ROOT, "%.2f", caneMulti(d)) + " &7(more cane counts toward your daily quota - Coin Boost levels and rebirths raise it)"));
        p.sendMessage(txt("&eRebirths: &f" + d.rebirths + " &7(x" + String.format(Locale.ROOT, "%.2f", rebirthMult(d)) + " cane + coins)  &eNext rebirth: &fDay " + rebirthDay(d)));
        p.sendMessage(txt("&eBonus Drops: &f" + (d.lvl("doubledrop") + d.rewardDrop) + " &7(" + d.rewardDrop + " free)   &eCoin Boost: &f" + (d.lvl("coinboost") + d.rewardSell) + " &7(" + d.rewardSell + " free)"));
        p.sendMessage(txt("&eChunks: &f" + (d.extra + 1) + "&7/" + (ORDER.size() + 1) + "   &eGrowth level: &f" + growthLevel(d)));
        if (hasCollector(d.id)) {
            int st = stalksOf(d);
            p.sendMessage(txt("&eAuto Sell: &f" + fmt((long) st) + " &7plants = &f" + fmt(simRate(d, st) * 60.0) + " &7cane/min = &f"
                    + fmt(simCoinsPerMinute(d, st)) + " &7coins/min (with all your multipliers)"));
        } else {
            p.sendMessage(txt("&eAuto Sell: &7place a &6Cane Core &7(/caneshop) to earn from your plants automatically."));
        }
        String next = d.day <= 100 ? reward(d.day).desc : "Random reward from the Day 1-100 pool";
        p.sendMessage(txt("&eThis day's reward: &f" + (d.day > d.bestDay ? next : "&7none (already claimed)")));
    }

    void cmdRewards(Player p, PD d) {
        p.sendMessage(txt("&6&l=== Upcoming Rewards ==="));
        for (int rd = d.day; rd < d.day + 6; rd++) {
            String line = rd <= 100 ? reward(rd).desc : "Random reward from Day 1-100";
            boolean claimed = rd <= d.bestDay;
            p.sendMessage(txt("&eDay " + rd + ": " + (claimed ? "&8" : "&f") + line + (claimed ? " &7(already claimed)" : "")));
        }
    }

    void cmdTop(Player p) {
        List<PD> list = new ArrayList<>(players.values());
        list.sort((x, y) -> Long.compare(y.totalCane, x.totalCane));
        p.sendMessage(txt("&6&l=== Cane Top ==="));
        int shown = Math.min(10, list.size());
        for (int i = 0; i < shown; i++) {
            PD d = list.get(i);
            p.sendMessage(txt("&6#" + (i + 1) + " &f" + d.name + " &7- &e" + fmt(d.totalCane) + " cane &7- &bDay " + d.day + (d.rebirths > 0 ? " &7- &dR" + d.rebirths : "")));
        }
        int rank = list.indexOf(players.get(p.getUniqueId())) + 1;
        if (rank > 0) p.sendMessage(txt("&7Your rank: &e#" + rank));
    }

    void cmdFly(Player p, PD d) {
        if (!d.flyOwned) {
            msg(p, "&cBuy &bFlight &cin &e/caneshop &cfirst!");
            return;
        }
        d.flyOn = !d.flyOn;
        dirty = true;
        if (d.flyOn) {
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) p.setAllowFlight(true);
            msg(p, "&aFlight &2enabled&a.");
        } else {
            if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                p.setFlying(false);
                p.setAllowFlight(false);
            }
            msg(p, "&cFlight disabled.");
        }
    }

    boolean admin(CommandSender s, String[] a) {
        if (!s.hasPermission("caneislands.admin")) {
            msg(s, "&cNo permission.");
            return true;
        }
        if (a.length < 2) {
            msg(s, "&e/caneadmin <coins|day|chunk|tokens> <player> [amount]");
            return true;
        }
        Player t = Bukkit.getPlayerExact(a[1]);
        PD d = t == null ? null : players.get(t.getUniqueId());
        if (d == null) {
            msg(s, "&cPlayer must be online and have an island.");
            return true;
        }
        double val = 0;
        if (a.length > 2) {
            try {
                val = Double.parseDouble(a[2]);
            } catch (NumberFormatException ex) {
                msg(s, "&cInvalid number.");
                return true;
            }
        }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "coins" -> {
                d.coins += val;
                msg(s, "&aGave " + fmt(val) + " coins.");
            }
            case "day" -> {
                d.day = Math.max(1, (int) val);
                if (d.day > d.runBest) d.runBest = d.day;
                d.submitted = 0;
                d.completed = false;
                d.timeLeft = timeFor(d);
                msg(s, "&aSet day to " + d.day + ".");
                checkRank(d, t);
                checkRebirthReady(d, t);
            }
            case "tokens" -> {
                d.tokens = Math.max(0, d.tokens + (int) val);
                msg(s, "&aGave " + (int) val + " tokens (now " + d.tokens + ").");
            }
            case "chunk" -> msg(s, addChunk(d) ? "&aAdded a chunk." : "&cAlready at max chunks.");
            default -> msg(s, "&e/caneadmin <coins|day|chunk|tokens> <player> [amount]");
        }
        dirty = true;
        return true;
    }

    // ------------------------------------------------------------------ persistence
    /** Builds the YAML on the main thread (a snapshot), writes the file on the save thread. Falls back to a synchronous write when the plugin is not enabled (shutdown). */
    void saveData() {
        if (!isEnabled()) {
            saveDataSync();
            return;
        }
        final YamlConfiguration y = buildYaml();
        final long seq;
        synchronized (saveLock) {
            seq = ++saveSeq;
        }
        try {
            saveExec.execute(() -> writeYaml(y, seq));
        } catch (java.util.concurrent.RejectedExecutionException ex) {
            writeYaml(y, seq); // executor already shut down: write here
        }
    }

    /** Same snapshot, written on the calling thread. Waits for any in-flight async write first. Used by onDisable. */
    void saveDataSync() {
        final YamlConfiguration y = buildYaml();
        final long seq;
        synchronized (saveLock) {
            seq = ++saveSeq;
        }
        writeYaml(y, seq);
    }

    /** Dump + write. Runs under saveLock so writes never interleave; an older snapshot never overwrites a newer one. */
    private void writeYaml(YamlConfiguration y, long seq) {
        synchronized (saveLock) {
            if (seq < writtenSeq) return;
            try {
                String text = y.saveToString();
                File tmp = new File(dataFile.getPath() + ".tmp");
                java.nio.file.Files.writeString(tmp.toPath(), text, java.nio.charset.StandardCharsets.UTF_8);
                try {
                    java.nio.file.Files.move(tmp.toPath(), dataFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE);
                } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
                    java.nio.file.Files.move(tmp.toPath(), dataFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
                writtenSeq = seq;
                saveFailed = false;
            } catch (IOException | RuntimeException ex) {
                saveFailed = true; // retried by the next 60 s check
                getLogger().severe("Could not save data: " + ex.getMessage());
            }
        }
    }

    /** Main thread: copies everything that gets saved into a fresh YamlConfiguration nobody else touches, and clears the dirty flags. */
    private YamlConfiguration buildYaml() {
        dirty = false;      // anything that changes after this point sets it again
        playDirty = false;
        lastSaveMs = System.currentTimeMillis();
        YamlConfiguration y = new YamlConfiguration();
        y.set("nextSlot", nextSlot);
        y.set("sandPurged", sandPurged);
        for (PD d : players.values()) {
            String k = "players." + d.id + ".";
            y.set(k + "name", d.name);
            y.set(k + "slot", d.slot);
            y.set(k + "extra", d.extra);
            y.set(k + "day", d.day);
            y.set(k + "bestDay", d.bestDay);
            y.set(k + "runBest", d.runBest);
            y.set(k + "timeLeft", d.timeLeft);
            y.set(k + "rewardGrowth", d.rewardGrowth);
            y.set(k + "rewardTime", d.rewardTime);
            y.set(k + "rewardDrop", d.rewardDrop);
            y.set(k + "rewardSell", d.rewardSell);
            y.set(k + "rankTier", d.rankTier);
            y.set(k + "playMs", d.playMs);
            y.set(k + "tokens", d.tokens);
            y.set(k + "owned", new ArrayList<>(d.owned));
            y.set(k + "activeTag", d.activeTag);
            y.set(k + "activeName", d.activeName);
            y.set(k + "activeSellFx", d.activeSellFx);
            y.set(k + "submitted", d.submitted);
            y.set(k + "totalCane", d.totalCane);
            y.set(k + "rebirths", d.rebirths);
            y.set(k + "lastRebirth", d.lastRebirth);
            y.set(k + "fastStreak", d.fastStreak);
            y.set(k + "autoRebirth", d.autoRebirth);
            y.set(k + "wandDepth", d.wandDepth);
            y.set(k + "wandLeft", d.wandLeft);
            y.set(k + "wandRight", d.wandRight);
            y.set(k + "wandLayers", d.wandLayers);
            y.set(k + "wandGap", d.wandGap);
            y.set(k + "wandPreview", d.wandPreview);
            y.set(k + "wandRotate", d.wandRotate);
            y.set(k + "breakerGiven", d.breakerGiven);
            y.set(k + "completed", d.completed);
            y.set(k + "flyOwned", d.flyOwned);
            y.set(k + "flyOn", d.flyOn);
            y.set(k + "autoDayOn", d.autoDayOn);
            y.set(k + "timeMode", d.timeMode);
            y.set(k + "hasSpawn", d.hasSpawn);
            if (d.hasSpawn) {
                y.set(k + "spawnX", d.spawnX);
                y.set(k + "spawnY", d.spawnY);
                y.set(k + "spawnZ", d.spawnZ);
                y.set(k + "spawnYaw", (double) d.spawnYaw);
                y.set(k + "spawnPitch", (double) d.spawnPitch);
            }
            y.set(k + "off", new ArrayList<>(d.off));
            List<String> tl = new ArrayList<>();
            for (UUID tu : d.trusted) tl.add(tu.toString());
            y.set(k + "trusted", tl);
            y.set(k + "coins", d.coins);
            y.set(k + "lastSim", d.lastSim);
            y.set(k + "carry", d.carry);
            y.set(k + "pending", new ArrayList<>(d.pending)); // copy: the async writer must not see a list the main thread still edits
            for (Map.Entry<String, Integer> en : d.bought.entrySet()) y.set(k + "bought." + en.getKey(), en.getValue());
            for (Map.Entry<String, Integer> en : d.priceBase.entrySet()) y.set(k + "priceBase." + en.getKey(), en.getValue());
        }
        List<String> sp = new ArrayList<>();
        for (Special s : specials.values()) sp.add(s.ser());
        y.set("specials", sp);
        return y;
    }

    void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        nextSlot = y.getInt("nextSlot", 0);
        sandPurged = y.getBoolean("sandPurged", false);
        ConfigurationSection ps = y.getConfigurationSection("players");
        if (ps != null) {
            for (String k : ps.getKeys(false)) {
                ConfigurationSection c = ps.getConfigurationSection(k);
                if (c == null) continue;
                PD d;
                try {
                    d = new PD(UUID.fromString(k));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                d.name = c.getString("name", "Unknown");
                d.slot = c.getInt("slot");
                d.extra = c.getInt("extra");
                d.day = Math.max(1, c.getInt("day", 1));
                d.bestDay = c.getInt("bestDay");
                d.runBest = Math.max(1, c.getInt("runBest", d.day));
                d.timeLeft = c.getInt("timeLeft", 1800);
                d.rewardGrowth = c.getInt("rewardGrowth");
                d.rewardTime = c.getInt("rewardTime");
                d.rewardDrop = c.getInt("rewardDrop");
                d.rewardSell = c.getInt("rewardSell");
                d.rankTier = c.getInt("rankTier");
                d.playMs = c.getLong("playMs");
                // players who were already past Day 100 get the tokens they would have earned
                d.tokens = c.contains("tokens") ? c.getInt("tokens") : Math.max(0, d.bestDay - TOKEN_START_DAY + 1);
                d.owned.addAll(c.getStringList("owned"));
                d.activeTag = c.getString("activeTag", "");
                d.owned.removeIf(o -> o.startsWith("trail_")); // trails were removed from the shop
                d.activeName = c.getString("activeName", "");
                d.activeSellFx = c.getString("activeSellFx", "");
                d.submitted = c.getLong("submitted");
                d.totalCane = c.getLong("totalCane");
                d.rebirths = c.getInt("rebirths");
                d.lastRebirth = c.getLong("lastRebirth");
                d.fastStreak = c.getInt("fastStreak");
                d.autoRebirth = c.getBoolean("autoRebirth");
                d.wandDepth = Math.max(1, Math.min(WAND_MAX_DEPTH, c.getInt("wandDepth", 128)));
                d.wandLeft = Math.max(0, Math.min(WAND_MAX_SIDE, c.getInt("wandLeft", 15)));
                d.wandRight = Math.max(0, Math.min(WAND_MAX_SIDE, c.getInt("wandRight", 15)));
                d.wandLayers = Math.max(1, Math.min(WAND_MAX_LAYERS, c.getInt("wandLayers", 2)));
                d.wandGap = Math.max(1, Math.min(WAND_MAX_GAP, c.getInt("wandGap", 1)));
                d.wandPreview = c.getBoolean("wandPreview", true);
                d.wandRotate = c.getBoolean("wandRotate", true);
                d.breakerGiven = c.getBoolean("breakerGiven");
                d.completed = c.getBoolean("completed");
                d.flyOwned = c.getBoolean("flyOwned");
                d.flyOn = c.getBoolean("flyOn");
                d.autoDayOn = c.getBoolean("autoDayOn");
                d.timeMode = c.getInt("timeMode");
                d.hasSpawn = c.getBoolean("hasSpawn");
                d.spawnX = c.getDouble("spawnX");
                d.spawnY = c.getDouble("spawnY");
                d.spawnZ = c.getDouble("spawnZ");
                d.spawnYaw = (float) c.getDouble("spawnYaw");
                d.spawnPitch = (float) c.getDouble("spawnPitch");
                d.off.addAll(c.getStringList("off"));
                for (String ts : c.getStringList("trusted")) {
                    try {
                        d.trusted.add(UUID.fromString(ts));
                    } catch (IllegalArgumentException ignored) {
                    }
                }
                d.coins = c.getDouble("coins");
                d.lastSim = c.getLong("lastSim");
                d.carry = c.getDouble("carry");
                d.pending.addAll(c.getIntegerList("pending"));
                ConfigurationSection b = c.getConfigurationSection("bought");
                if (b != null) for (String id : b.getKeys(false)) d.bought.put(id, b.getInt(id));
                ConfigurationSection pb = c.getConfigurationSection("priceBase");
                if (pb != null) {
                    for (String id : pb.getKeys(false)) d.priceBase.put(id, Math.min(pb.getInt(id), d.lvl(id)));
                } else {
                    // old saves: one global "priceDrop" - turn it into the same per-item prices, which now double on every purchase
                    int legacy = Math.max(0, c.getInt("priceDrop"));
                    if (legacy > 0) for (Map.Entry<String, Integer> en : d.bought.entrySet()) d.priceBase.put(en.getKey(), Math.min(legacy, en.getValue()));
                }
                players.put(d.id, d);
                indexChunks(d);
            }
        }
        int removedInfChests = 0;
        for (String line : y.getStringList("specials")) {
            Special s = Special.parse(line);
            // old Harvesters (and anything else that no longer exists) are simply forgotten
            if (s != null && isSpecialType(s.type)) specials.put(s.key(), s);
            else if (s != null && s.type.equals("infchest")) removedInfChests++; // Infinite Chests are gone: forgotten (the block stays a plain chest)
        }
        if (removedInfChests > 0) {
            getLogger().info("Removed " + removedInfChests + " old Infinite Chest(s) and their stored items.");
            dirty = true; // rewrite the file without them (and without the old infstore section)
        }
    }
}
